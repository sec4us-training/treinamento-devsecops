--
-- PostgreSQL database dump
--

\restrict Xs70qUqBIjTqQA0MuV17khofhAFea3OApykDlTJ4Ykm3OBSrmNrYZZwg8xl6JoA

-- Dumped from database version 13.23
-- Dumped by pg_dump version 13.23

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: access_fnc_allow_read_only(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.access_fnc_allow_read_only() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        RAISE EXCEPTION USING message = 'JFrog migration is running in the background, cannot modify permissions, please wait for the migration to finish', errcode = '20010';
    END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_configs (
    config_name character varying(255) NOT NULL,
    modified bigint NOT NULL,
    data bytea NOT NULL
);


--
-- Name: access_db_check; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_db_check (
    username character varying(15) NOT NULL,
    sorting_order integer NOT NULL
);


--
-- Name: access_distributed_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_distributed_lock (
    lock_name character varying(40) NOT NULL,
    owner character varying(255) NOT NULL,
    modified bigint NOT NULL
)
WITH (fillfactor='80');


--
-- Name: access_emails_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_emails_log (
    email character varying(255) NOT NULL,
    last_sent bigint NOT NULL
);


--
-- Name: access_environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_environments (
    id bigint NOT NULL,
    environment_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1024),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    predefined smallint DEFAULT 0 NOT NULL,
    ordinal integer,
    project_id bigint NOT NULL
);


--
-- Name: access_federation_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_federation_log (
    log_id bigint NOT NULL,
    created bigint NOT NULL,
    message_type character varying(32) NOT NULL,
    message_change_type character varying(32) NOT NULL,
    message_time bigint NOT NULL,
    message_data bytea NOT NULL
);


--
-- Name: access_federation_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_federation_servers (
    server_name character varying(64) NOT NULL,
    last_success bigint NOT NULL
);


--
-- Name: access_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_groups (
    group_id bigint NOT NULL,
    group_name character varying(64) NOT NULL,
    description character varying(1024),
    auto_join smallint NOT NULL,
    realm character varying(255),
    realm_attributes character varying(512),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    lowercase_name character varying(64) NOT NULL,
    external_id character varying(64)
);


--
-- Name: access_groups_custom_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_groups_custom_data (
    group_id bigint NOT NULL,
    prop_key character varying(255) NOT NULL,
    prop_value character varying(2048)
);


--
-- Name: access_master_key_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_master_key_status (
    is_unique_key smallint NOT NULL,
    status character varying(16) NOT NULL,
    set_by_node_id character varying(64) NOT NULL,
    kid character(64) NOT NULL,
    expires bigint NOT NULL
);


--
-- Name: access_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_nodes (
    node_id character varying(255) NOT NULL,
    service_id character varying(255) NOT NULL,
    token_id character varying(255),
    version character varying(128),
    revision character varying(30),
    created bigint
);


--
-- Name: access_permission_action; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permission_action (
    action_id bigint NOT NULL,
    perm_id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    action character varying(64) NOT NULL
);


--
-- Name: access_permission_names_mapper; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permission_names_mapper (
    name_v2 character varying(255) NOT NULL,
    resource_type_v2 character varying(255) NOT NULL,
    name_identifier_v1 character varying(255) NOT NULL
);


--
-- Name: access_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions (
    perm_id bigint NOT NULL,
    perm_name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    service_id character varying(255) NOT NULL,
    resource_type character varying(255) NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    lower_display_name character varying(255) NOT NULL
);


--
-- Name: access_permissions_actions_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions_actions_v2 (
    action_id bigint NOT NULL,
    perm_id bigint NOT NULL,
    resource_type character varying(255) NOT NULL,
    user_id bigint,
    group_id bigint,
    actions bigint NOT NULL
);


--
-- Name: access_permissions_custom_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions_custom_data (
    perm_id bigint NOT NULL,
    data bytea NOT NULL
);


--
-- Name: access_permissions_targets_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions_targets_v2 (
    target_id bigint NOT NULL,
    perm_id bigint NOT NULL,
    resource_type character varying(255) NOT NULL,
    target_name character varying(255) NOT NULL,
    is_target_ant_pattern smallint NOT NULL,
    include_patterns bytea NOT NULL,
    exclude_patterns bytea NOT NULL
);


--
-- Name: access_permissions_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions_v2 (
    perm_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    created_by character varying(255) NOT NULL,
    modified_by character varying(255) NOT NULL,
    lower_name character varying(255) NOT NULL,
    description character varying(1024),
    realm character varying(255) NOT NULL
);


--
-- Name: access_permissions_v2_ref; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_permissions_v2_ref (
    v1_id bigint NOT NULL,
    v2_name character varying(255) NOT NULL
);


--
-- Name: access_platform_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_platform_config (
    config_key character varying(255) NOT NULL,
    revision bigint NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    configuration bytea NOT NULL,
    is_secret smallint DEFAULT 0 NOT NULL
);


--
-- Name: access_project_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_project_groups (
    project_id bigint NOT NULL,
    group_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: access_project_resource_environments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_project_resource_environments (
    resource_id bigint NOT NULL,
    environment_id bigint NOT NULL
);


--
-- Name: access_project_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_project_resources (
    id bigint NOT NULL,
    type character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    project_id bigint NOT NULL,
    auto_share smallint DEFAULT 0,
    read_only_share smallint DEFAULT 0
);


--
-- Name: access_project_shared_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_project_shared_resources (
    resource_id bigint NOT NULL,
    project_id bigint NOT NULL
);


--
-- Name: access_project_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_project_users (
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    role_id bigint NOT NULL
);


--
-- Name: access_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_projects (
    id bigint NOT NULL,
    project_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1024),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    storage_bytes bigint DEFAULT '-1'::integer,
    storage_soft_limit smallint DEFAULT 0,
    storage_email_notification smallint DEFAULT 1,
    predefined smallint DEFAULT 0
);


--
-- Name: access_role_environment_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_role_environment_actions (
    role_id bigint NOT NULL,
    environment_id bigint NOT NULL,
    actions bigint NOT NULL
);


--
-- Name: access_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_roles (
    id bigint NOT NULL,
    role_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1024),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    actions bigint,
    predefined smallint DEFAULT 0,
    project_id bigint
);


--
-- Name: access_schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_schema_version (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: access_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_servers (
    server_id character varying(36) NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    server_name character varying(64) NOT NULL,
    version character varying(128) NOT NULL,
    prvkey_fingerprint character varying(64) NOT NULL,
    prvkey_last_modified bigint NOT NULL,
    last_heartbeat bigint NOT NULL,
    prv_ca_key_fingerprint character varying(64) NOT NULL
);


--
-- Name: access_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_tasks (
    task_name character varying(255) NOT NULL,
    task_instance character varying(255) NOT NULL,
    task_data bytea,
    execution_time bigint,
    picked boolean NOT NULL,
    picked_by character varying(255),
    last_success bigint,
    last_failure bigint,
    consecutive_failures integer,
    last_heartbeat bigint,
    version bigint NOT NULL,
    priority smallint DEFAULT 50 NOT NULL
);


--
-- Name: access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_tokens (
    token_id character varying(36) NOT NULL,
    subject character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    created bigint NOT NULL,
    expiry bigint,
    refresh_token character varying(128),
    scope character varying(255),
    token_type character varying(255),
    username character varying(255),
    description character varying(1024),
    payload character varying(4000),
    hashed_reference character varying(255),
    project_key character varying(128),
    last_used bigint
);


--
-- Name: access_topology; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_topology (
    endpoint_id bigint NOT NULL,
    service_id character varying(255) NOT NULL,
    node_id character varying(255) NOT NULL,
    created bigint NOT NULL,
    ip character varying(64) NOT NULL,
    port integer NOT NULL,
    is_secure smallint NOT NULL,
    paths character varying(4000) NOT NULL,
    state character varying(32) NOT NULL,
    last_updated bigint NOT NULL,
    router_id character varying(255) NOT NULL,
    availability_zone_id character varying(255)
)
WITH (fillfactor='80');


--
-- Name: access_unique_ids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_unique_ids (
    index_type character varying(32) NOT NULL,
    current_id bigint NOT NULL
);


--
-- Name: access_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_users (
    user_id bigint NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(500),
    allowed_ips character varying(255),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    firstname character varying(35),
    lastname character varying(35),
    email character varying(255),
    realm character varying(255),
    status character varying(32) NOT NULL,
    last_login_time bigint NOT NULL,
    last_login_ip character varying(42),
    failed_attempts bigint NOT NULL,
    status_last_modified bigint NOT NULL,
    password_last_modified bigint NOT NULL
);


--
-- Name: access_users_custom_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_users_custom_data (
    user_id bigint NOT NULL,
    prop_key character varying(255) NOT NULL,
    prop_value character varying(2048),
    prop_sensitive smallint NOT NULL,
    prop_cluster_local smallint
);


--
-- Name: access_users_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_users_groups (
    user_id bigint NOT NULL,
    group_id bigint NOT NULL,
    realm character varying(255)
);


--
-- Name: archive_names; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.archive_names (
    name_id bigint NOT NULL,
    entry_name character varying(255)
);


--
-- Name: archive_paths; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.archive_paths (
    path_id bigint NOT NULL,
    entry_path character varying(1024)
);


--
-- Name: artifact_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifact_bundles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(255) NOT NULL,
    status character varying(64) NOT NULL,
    date_created bigint NOT NULL,
    date_distributed bigint,
    signature character varying(1024) NOT NULL,
    type character varying(32) DEFAULT 'TARGET'::character varying NOT NULL,
    storing_repo character varying(64),
    keep smallint,
    source_service_id character varying(255)
);


--
-- Name: artifactory_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.artifactory_servers (
    server_id character varying(128) NOT NULL,
    start_time bigint NOT NULL,
    context_url character varying(255),
    membership_port integer,
    server_state character varying(12) NOT NULL,
    server_role character varying(255) NOT NULL,
    last_heartbeat bigint NOT NULL,
    artifactory_version character varying(128) NOT NULL,
    artifactory_revision integer,
    artifactory_release bigint,
    artifactory_running_mode character varying(12) NOT NULL,
    license_hash character varying(41) NOT NULL
);


--
-- Name: binaries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binaries (
    sha1 character(40) NOT NULL,
    md5 character(32) NOT NULL,
    bin_length bigint NOT NULL,
    sha256 character(64) NOT NULL
);


--
-- Name: binaries_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binaries_tasks (
    id bigint NOT NULL,
    sha1 character varying(40) NOT NULL,
    "time" bigint NOT NULL,
    local_repo_key character varying(64) NOT NULL,
    remote_url_hash integer,
    start_time bigint,
    count integer NOT NULL,
    server_id character varying(128)
);


--
-- Name: binary_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.binary_blobs (
    sha1 character(40) NOT NULL,
    data bytea
);


--
-- Name: build_artifacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_artifacts (
    artifact_id bigint NOT NULL,
    module_id bigint NOT NULL,
    artifact_name character varying(1024) NOT NULL,
    artifact_type character varying(64),
    sha1 character(40),
    md5 character(32)
);


--
-- Name: build_dependencies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_dependencies (
    dependency_id bigint NOT NULL,
    module_id bigint NOT NULL,
    dependency_name_id character varying(1024) NOT NULL,
    dependency_scopes character varying(4000),
    dependency_type character varying(64),
    sha1 character(40),
    md5 character(32)
);


--
-- Name: build_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_modules (
    module_id bigint NOT NULL,
    build_id bigint NOT NULL,
    module_name_id character varying(1024) NOT NULL,
    type character varying(64)
);


--
-- Name: build_promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_promotions (
    build_id bigint NOT NULL,
    created bigint NOT NULL,
    created_by character varying(64),
    status character varying(64) NOT NULL,
    repo character varying(64),
    promotion_comment character varying(1024),
    ci_user character varying(64)
);


--
-- Name: build_props; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_props (
    prop_id bigint NOT NULL,
    build_id bigint NOT NULL,
    prop_key character varying(255),
    prop_value character varying(2048)
);


--
-- Name: build_release_bundles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.build_release_bundles (
    build_rb_id bigint NOT NULL,
    build_id bigint NOT NULL,
    bundle_repository character varying(64) NOT NULL,
    bundle_name character varying(255) NOT NULL,
    bundle_version character varying(255) NOT NULL
);


--
-- Name: builds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.builds (
    build_id bigint NOT NULL,
    build_name character varying(255) NOT NULL,
    build_number character varying(255) NOT NULL,
    build_date bigint NOT NULL,
    ci_url character varying(1024),
    created bigint NOT NULL,
    created_by character varying(64),
    modified bigint,
    modified_by character varying(64),
    repo character varying(64) DEFAULT 'artifactory-build-info'::character varying NOT NULL,
    immutable smallint
);


--
-- Name: bundle_blobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bundle_blobs (
    id bigint NOT NULL,
    data bytea NOT NULL,
    bundle_id bigint NOT NULL
);


--
-- Name: bundle_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bundle_files (
    id bigint NOT NULL,
    node_id bigint NOT NULL,
    bundle_id bigint NOT NULL,
    repo_path character varying(1090) NOT NULL,
    original_component_details character varying(1000)
);


--
-- Name: cleanup_run_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cleanup_run_summary (
    policy_key character varying(255) NOT NULL,
    policy_run_id bigint NOT NULL,
    dry_run smallint DEFAULT 0 NOT NULL,
    started_date bigint NOT NULL,
    finished_date bigint NOT NULL,
    status character varying(64) NOT NULL,
    type character varying(64) NOT NULL,
    temp_nodes_cleaned smallint DEFAULT 0 NOT NULL,
    deleted_packages_count bigint NOT NULL,
    failed_packages_count bigint NOT NULL,
    deleted_artifacts_count bigint NOT NULL,
    failed_artifacts_count bigint NOT NULL,
    original_binary_size bigint NOT NULL,
    estimated_deleted_binary_size bigint NOT NULL,
    triggered_by character varying(64) NOT NULL,
    total_binary_size bigint DEFAULT 0 NOT NULL,
    run_config bytea
);


--
-- Name: config_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_history (
    id bigint NOT NULL,
    config_data bytea NOT NULL,
    repo_config_data bytea NOT NULL,
    log_config_data bytea NOT NULL
);


--
-- Name: config_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_history_id_seq OWNED BY public.config_history.id;


--
-- Name: config_schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_schema_version (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configs (
    config_name character varying(255) NOT NULL,
    last_modified bigint NOT NULL,
    data bytea NOT NULL
);


--
-- Name: db_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.db_properties (
    installation_date bigint NOT NULL,
    artifactory_version character varying(128) NOT NULL,
    artifactory_revision integer,
    artifactory_release bigint,
    artifactory_product_version character varying(128) NOT NULL
);


--
-- Name: distributed_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.distributed_locks (
    category character varying(128) NOT NULL,
    lock_key character varying(255) NOT NULL,
    owner character varying(64) NOT NULL,
    owner_thread bigint NOT NULL,
    owner_thread_name character varying(64) NOT NULL,
    acquire_time bigint NOT NULL
);


--
-- Name: file_list_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_list_tasks (
    repo character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    heartbeat bigint
);


--
-- Name: heavy_query_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.heavy_query_cache (
    id bigint NOT NULL,
    cache_key character varying(255) NOT NULL,
    cache_time bigint NOT NULL,
    expiry_time bigint NOT NULL,
    data bytea NOT NULL
);


--
-- Name: indexed_archives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indexed_archives (
    archive_sha1 character(40) NOT NULL,
    indexed_archives_id bigint NOT NULL
);


--
-- Name: indexed_archives_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indexed_archives_entries (
    indexed_archives_id bigint NOT NULL,
    entry_path_id bigint NOT NULL,
    entry_name_id bigint NOT NULL
);


--
-- Name: jfconfig_platform_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jfconfig_platform_config (
    config_key character varying(255) NOT NULL,
    revision bigint NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    configuration bytea NOT NULL,
    is_secret smallint DEFAULT 0 NOT NULL
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    job_id bigint NOT NULL,
    job_type character varying(32) NOT NULL,
    job_status character varying(32) NOT NULL,
    started bigint NOT NULL,
    finished bigint,
    additional_details character varying(2048)
);


--
-- Name: master_key_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_key_status (
    is_unique_key smallint NOT NULL,
    status character varying(16) NOT NULL,
    set_by_node_id character varying(64) NOT NULL,
    kid character(64) NOT NULL,
    expires bigint NOT NULL
);


--
-- Name: md_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_configs (
    id bigint NOT NULL,
    config_name character varying(255) NOT NULL,
    modified bigint NOT NULL,
    data bytea
);


--
-- Name: md_contributors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_contributors (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    email character varying(255),
    url character varying(255)
);


--
-- Name: md_database_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_database_migrations (
    id character varying(255) NOT NULL,
    applied_at bigint,
    allow_to_rollback smallint,
    rollbacked smallint
);


--
-- Name: md_fil_qualifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_fil_qualifiers (
    id bigint NOT NULL,
    file_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


--
-- Name: md_fil_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_fil_targets (
    id bigint NOT NULL,
    arch character varying(255),
    dist character varying(255),
    compiler character varying(255),
    compiler_version character varying(255)
);


--
-- Name: md_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_files (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    sha256 character varying(64) NOT NULL,
    sha1 character varying(40) NOT NULL,
    md5 character varying(32) NOT NULL,
    is_lead smallint NOT NULL,
    length bigint,
    arch character varying(255),
    dist character varying(255),
    mime_type character varying(255),
    file_target_id bigint
);


--
-- Name: md_files_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_files_versions (
    id bigint NOT NULL,
    file_id bigint NOT NULL,
    version_id bigint NOT NULL
);


--
-- Name: md_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_licenses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    url character varying(255)
);


--
-- Name: md_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_lock (
    lock_name character varying(255) NOT NULL,
    lock_owner character varying(255) NOT NULL,
    acquired_at bigint NOT NULL
);


--
-- Name: md_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_repos (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(255),
    type character varying(20) NOT NULL
);


--
-- Name: md_ver_repos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_repos (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    repo_id bigint NOT NULL,
    lead_file_path character varying(2048),
    lead_hash character varying(64)
);


--
-- Name: md_package_version_location; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.md_package_version_location AS
 SELECT mvr.id,
    mvr.version_id,
    mvr.repo_id,
    mr.name AS repository_key,
    mvr.lead_file_path
   FROM (public.md_ver_repos mvr
     JOIN public.md_repos mr ON ((mvr.repo_id = mr.id)));


--
-- Name: md_version_repo_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_version_repo_stats (
    repo_id bigint NOT NULL,
    version_id bigint NOT NULL,
    download_count bigint NOT NULL,
    last_downloaded bigint NOT NULL,
    remote_last_downloaded bigint NOT NULL
);


--
-- Name: md_package_version_location_stats; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.md_package_version_location_stats AS
 SELECT mvr.id,
    mvr.id AS version_repo_id,
    mvrs.download_count,
    mvrs.last_downloaded,
    mvrs.remote_last_downloaded
   FROM (public.md_ver_repos mvr
     LEFT JOIN public.md_version_repo_stats mvrs ON (((mvr.version_id = mvrs.version_id) AND (mvr.repo_id = mvrs.repo_id))));


--
-- Name: md_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_packages (
    id bigint NOT NULL,
    pkgid character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    lowercase_name character varying(255) NOT NULL,
    repo_package_type character varying(255) NOT NULL,
    website character varying(255),
    vcs_url character varying(255),
    issues_url character varying(255),
    trimmed_description character varying(1024),
    created bigint NOT NULL,
    modified bigint NOT NULL,
    edited bigint,
    respects_semver smallint NOT NULL,
    min_write_level bigint NOT NULL,
    latest_version_name character varying(255),
    base_model_complete smallint DEFAULT 0 NOT NULL,
    stored_package_type character varying(255) DEFAULT 'na'::character varying NOT NULL
);


--
-- Name: md_pkg_descriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_descriptions (
    package_id bigint NOT NULL,
    description bytea
);


--
-- Name: md_pkg_info_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_info_sources (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    source_id bigint NOT NULL,
    modified bigint NOT NULL
);


--
-- Name: md_pkg_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_licenses (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    source character varying(20),
    modified bigint NOT NULL
);


--
-- Name: md_pkg_op_risk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_op_risk (
    package_id bigint NOT NULL,
    risk_level bigint NOT NULL,
    cadence numeric NOT NULL,
    commits bigint NOT NULL,
    contributors bigint NOT NULL
);


--
-- Name: md_pkg_qualifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_qualifiers (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


--
-- Name: md_pkg_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_stats (
    package_id bigint NOT NULL,
    follower_count bigint NOT NULL,
    download_count bigint NOT NULL
);


--
-- Name: md_pkg_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_tags (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    value character varying(4000) NOT NULL
);


--
-- Name: md_pkg_user_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_user_properties (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


--
-- Name: md_pkg_vulns_sum; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_pkg_vulns_sum (
    package_id bigint NOT NULL,
    high bigint,
    medium bigint,
    low bigint,
    info bigint,
    unknown bigint,
    skipped bigint,
    critical bigint
);


--
-- Name: md_servers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_servers (
    id character varying(255) NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    version character varying(255),
    last_heartbeat bigint NOT NULL,
    base_url character varying(255) NOT NULL,
    node_unique_id bigint NOT NULL
);


--
-- Name: md_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_sources (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    url character varying(255) NOT NULL
);


--
-- Name: md_task_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_task_batches (
    task_key character varying(255) NOT NULL,
    progress character varying(30) NOT NULL,
    modified bigint NOT NULL,
    batch_start_key bigint NOT NULL,
    batch_end_key bigint NOT NULL
);


--
-- Name: md_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_tasks (
    task_key character varying(255) NOT NULL,
    execution_interval_millis bigint NOT NULL,
    progress character varying(30) NOT NULL,
    modified bigint NOT NULL,
    task_start_key bigint NOT NULL,
    task_end_key bigint NOT NULL,
    depends_on character varying(255)
);


--
-- Name: md_temp_prerelease_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_temp_prerelease_groups (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    ordinal_no_prerelease bigint NOT NULL,
    group_size bigint NOT NULL
);


--
-- Name: md_ver_contributors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_contributors (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    contributor_id bigint NOT NULL
);


--
-- Name: md_ver_licenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_licenses (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    source character varying(20),
    modified bigint NOT NULL
);


--
-- Name: md_ver_op_risk; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_op_risk (
    version_id bigint NOT NULL,
    risk_level bigint NOT NULL
);


--
-- Name: md_ver_qualifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_qualifiers (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


--
-- Name: md_ver_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_stats (
    version_id bigint NOT NULL,
    download_count bigint NOT NULL
);


--
-- Name: md_ver_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_tags (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    value character varying(4000) NOT NULL
);


--
-- Name: md_ver_user_properties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_user_properties (
    id bigint NOT NULL,
    version_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(4000)
);


--
-- Name: md_ver_vulns_sum; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_ver_vulns_sum (
    version_id bigint NOT NULL,
    high bigint,
    medium bigint,
    low bigint,
    info bigint,
    unknown bigint,
    skipped bigint,
    critical bigint
);


--
-- Name: md_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.md_versions (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    lowercase_name character varying(255) NOT NULL,
    created bigint NOT NULL,
    ordinal bigint NOT NULL,
    min_write_level bigint NOT NULL,
    version_size bigint,
    modified bigint NOT NULL,
    base_model_complete smallint DEFAULT 0 NOT NULL,
    marked_for_deletion smallint DEFAULT 0 NOT NULL,
    last_edited bigint DEFAULT 0 NOT NULL
);


--
-- Name: migration_status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_status (
    identifier character varying(255) NOT NULL,
    started bigint NOT NULL,
    finished bigint NOT NULL,
    migration_info_blob bytea
);


--
-- Name: mirrors_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mirrors_metadata (
    metadata_type character varying(64) NOT NULL,
    member_url character varying(500) NOT NULL,
    cache_time bigint NOT NULL,
    metadata_blob bytea
);


--
-- Name: module_props; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.module_props (
    prop_id bigint NOT NULL,
    module_id bigint NOT NULL,
    prop_key character varying(255),
    prop_value character varying(2048)
);


--
-- Name: node_event_cursor; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_event_cursor (
    operator_id character varying(255) NOT NULL,
    event_marker bigint NOT NULL,
    type character varying(255) NOT NULL,
    status character varying(255),
    last_updated bigint
);


--
-- Name: node_event_priorities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_event_priorities (
    priority_id bigint NOT NULL,
    path character varying(1344) NOT NULL,
    type character varying(1024) NOT NULL,
    operator_id character varying(255) NOT NULL,
    priority smallint NOT NULL,
    "timestamp" bigint NOT NULL,
    retry_count smallint NOT NULL
);


--
-- Name: node_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events (
    event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096),
    repo character varying(64)
);


--
-- Name: node_events_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_errors (
    error_id bigint NOT NULL,
    operation_key character varying(255),
    event_category character varying(255),
    first_error_time bigint NOT NULL,
    last_error_time bigint NOT NULL,
    error_count smallint NOT NULL,
    error_message character varying(4000) NOT NULL,
    event_id bigint,
    event_time bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL
);


--
-- Name: node_events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.node_events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: node_events_tmp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_tmp (
    tmp_event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096)
)
PARTITION BY LIST (((("timestamp" % ((24 * 3600000))::bigint) / 3600000)));


--
-- Name: node_events_tmp_p0_5; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_tmp_p0_5 (
    tmp_event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096)
);
ALTER TABLE ONLY public.node_events_tmp ATTACH PARTITION public.node_events_tmp_p0_5 FOR VALUES IN ('0', '1', '2', '3', '4', '5');


--
-- Name: node_events_tmp_p12_17; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_tmp_p12_17 (
    tmp_event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096)
);
ALTER TABLE ONLY public.node_events_tmp ATTACH PARTITION public.node_events_tmp_p12_17 FOR VALUES IN ('12', '13', '14', '15', '16', '17');


--
-- Name: node_events_tmp_p18_23; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_tmp_p18_23 (
    tmp_event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096)
);
ALTER TABLE ONLY public.node_events_tmp ATTACH PARTITION public.node_events_tmp_p18_23 FOR VALUES IN ('18', '19', '20', '21', '22', '23');


--
-- Name: node_events_tmp_p6_11; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_events_tmp_p6_11 (
    tmp_event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    path character varying(1344) NOT NULL,
    hints character varying(4096)
);
ALTER TABLE ONLY public.node_events_tmp ATTACH PARTITION public.node_events_tmp_p6_11 FOR VALUES IN ('6', '7', '8', '9', '10', '11');


--
-- Name: node_meta_infos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_meta_infos (
    node_id bigint NOT NULL,
    props_modified bigint,
    props_modified_by character varying(64),
    props_md5 character(32)
);


--
-- Name: node_props; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.node_props (
    prop_id bigint NOT NULL,
    node_id bigint NOT NULL,
    prop_key character varying(255),
    prop_value character varying(4000)
);
ALTER TABLE ONLY public.node_props ALTER COLUMN prop_key SET STATISTICS 1000;
ALTER TABLE ONLY public.node_props ALTER COLUMN prop_value SET STATISTICS 1000;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes (
    node_id bigint NOT NULL,
    node_type smallint NOT NULL,
    repo character varying(64) NOT NULL,
    node_path character varying(1024) NOT NULL,
    node_name character varying(255) NOT NULL,
    depth smallint NOT NULL,
    created bigint NOT NULL,
    created_by character varying(64),
    modified bigint NOT NULL,
    modified_by character varying(64),
    updated bigint,
    bin_length bigint,
    sha1_actual character(40),
    sha1_original character varying(1024),
    md5_actual character(32),
    md5_original character varying(1024),
    sha256 character(64),
    repo_path_checksum character(40)
);


--
-- Name: nodes_cleaned; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodes_cleaned (
    id bigint NOT NULL,
    policy_key character varying(255) NOT NULL,
    policy_run_id bigint NOT NULL,
    repo character varying(64) NOT NULL,
    node_path character varying(1024) NOT NULL,
    node_name character varying(255) NOT NULL,
    bin_length bigint NOT NULL,
    sha1 character(40) NOT NULL,
    status smallint NOT NULL,
    lead_artifact smallint DEFAULT 0 NOT NULL,
    package_name character varying(255),
    package_version character varying(255),
    message character varying(1024)
);


--
-- Name: nodes_cleaned_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nodes_cleaned_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nodes_cleaned_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nodes_cleaned_id_seq OWNED BY public.nodes_cleaned.id;


--
-- Name: policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policy (
    policy_key character varying(255) NOT NULL,
    policy_type character varying(64) NOT NULL,
    item_type character varying(64) NOT NULL,
    enabled smallint DEFAULT 0 NOT NULL,
    created bigint NOT NULL,
    created_by character varying(64) NOT NULL,
    config bytea NOT NULL,
    modified bigint,
    modified_by character varying(64),
    cronexp character varying(64),
    description character varying(1024)
);


--
-- Name: quartz_task_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quartz_task_history (
    run_id bigint NOT NULL,
    external_id character varying(255),
    task_type character varying(255) NOT NULL,
    started_date bigint,
    finished_date bigint,
    last_modified_date bigint NOT NULL,
    status character varying(64) NOT NULL,
    status_message character varying(1024),
    deleted smallint DEFAULT 0,
    task_id character varying(255) NOT NULL,
    server_id character varying(64) NOT NULL,
    manual_trigger smallint DEFAULT 0,
    username character varying(64) NOT NULL
);


--
-- Name: quartz_task_history_run_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quartz_task_history_run_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quartz_task_history_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quartz_task_history_run_id_seq OWNED BY public.quartz_task_history.run_id;


--
-- Name: repository_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repository_config (
    repository_key character varying(64) NOT NULL,
    type character varying(32) NOT NULL,
    package_type character varying(32) NOT NULL,
    revision bigint NOT NULL,
    created bigint NOT NULL,
    modified bigint NOT NULL,
    config_blob bytea
);


--
-- Name: retention_run_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retention_run_summary (
    id bigint NOT NULL,
    policy_key character varying(255) NOT NULL,
    run_id bigint NOT NULL,
    dry_run smallint DEFAULT 0 NOT NULL,
    started_date bigint NOT NULL,
    finished_date bigint NOT NULL,
    retention_type character varying(64) NOT NULL,
    status character varying(64) NOT NULL,
    item_type character varying(64) NOT NULL,
    temp_nodes_cleaned smallint DEFAULT 0 NOT NULL,
    processed_items_count bigint DEFAULT 0 NOT NULL,
    failed_items_count bigint DEFAULT 0 NOT NULL,
    total_items_count bigint DEFAULT 0 NOT NULL,
    processed_physical_binary_size bigint DEFAULT 0 NOT NULL,
    processed_virtual_binary_size bigint DEFAULT 0 NOT NULL,
    total_binary_size bigint DEFAULT 0 NOT NULL,
    triggered_by character varying(64) NOT NULL,
    run_config bytea
);


--
-- Name: retention_run_summary_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.retention_run_summary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: retention_run_summary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.retention_run_summary_id_seq OWNED BY public.retention_run_summary.id;


--
-- Name: schema_change_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_change_log (
    version character varying(32) NOT NULL,
    description character varying(1024) NOT NULL,
    start_time bigint NOT NULL,
    update_time bigint NOT NULL,
    status character varying(32) NOT NULL,
    exec_type character varying(32) NOT NULL,
    product_version character varying(256),
    initial_version character varying(256),
    server_id character varying(256) NOT NULL,
    error_message character varying(1024)
);


--
-- Name: stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stats (
    node_id bigint NOT NULL,
    download_count bigint,
    last_downloaded bigint,
    last_downloaded_by character varying(64)
);


--
-- Name: stats_remote; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stats_remote (
    node_id bigint NOT NULL,
    origin character varying(64) NOT NULL,
    download_count bigint,
    last_downloaded bigint,
    last_downloaded_by character varying(64),
    path character varying(1024)
);


--
-- Name: storage_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_events (
    event_id bigint NOT NULL,
    "timestamp" bigint NOT NULL,
    event_type smallint NOT NULL,
    sha1 character(40) NOT NULL,
    sha256 character(64) NOT NULL,
    bin_length bigint NOT NULL,
    data character varying(1024)
);


--
-- Name: storage_events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storage_events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storage_multipart_uploads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_multipart_uploads (
    upload_id character varying(255) NOT NULL,
    created_date bigint NOT NULL,
    temp_path character varying(255) NOT NULL,
    status character varying(20) NOT NULL,
    modified_date bigint NOT NULL,
    data json
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    task_type character varying(32) NOT NULL,
    task_context character varying(2048) NOT NULL,
    created bigint,
    task_id bigint NOT NULL
);


--
-- Name: tasks_task_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_task_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_task_id_seq OWNED BY public.tasks.task_id;


--
-- Name: tpl_configuration; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tpl_configuration (
    property_key character varying(100) NOT NULL,
    property_value character varying(1000) NOT NULL
);


--
-- Name: tpl_schema_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tpl_schema_version (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- Name: tpl_topology; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tpl_topology (
    id character(36) NOT NULL,
    service_id character varying(255) NOT NULL,
    node_id character varying(255) NOT NULL,
    created bigint NOT NULL,
    ip character varying(64) NOT NULL,
    port integer NOT NULL,
    secure smallint NOT NULL,
    paths character varying(4000) NOT NULL,
    state character varying(32) NOT NULL,
    last_updated bigint NOT NULL,
    router_id character varying(255) NOT NULL,
    version character varying(255),
    revision character varying(255),
    availability_zone_id character varying(255)
);


--
-- Name: trusted_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.trusted_keys (
    kid character varying(6) NOT NULL,
    trusted_key character varying(4000) NOT NULL,
    fingerprint character varying(255) NOT NULL,
    key_type character varying(255) DEFAULT 'PGP'::character varying NOT NULL,
    alias character varying(255) NOT NULL,
    issued bigint,
    issued_by character varying(255),
    expiry bigint
);


--
-- Name: ui_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ui_session (
    session_id character(36) NOT NULL,
    creation_time bigint NOT NULL,
    last_access_time bigint NOT NULL,
    max_inactive_interval integer NOT NULL,
    principal_name character varying(100)
);


--
-- Name: ui_session_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ui_session_attributes (
    session_id character(36) NOT NULL,
    attribute_name character varying(200) NOT NULL,
    attribute_bytes bytea
);


--
-- Name: ui_session_v2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ui_session_v2 (
    primary_id character(36) NOT NULL,
    session_id character(36),
    creation_time bigint NOT NULL,
    last_access_time bigint NOT NULL,
    max_inactive_interval integer NOT NULL,
    expiry_time bigint NOT NULL,
    principal_name character varying(100)
);


--
-- Name: ui_session_v2_attributes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ui_session_v2_attributes (
    session_primary_id character(36) NOT NULL,
    attribute_name character varying(200) NOT NULL,
    attribute_bytes bytea
);


--
-- Name: unique_ids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unique_ids (
    index_type character varying(32) NOT NULL,
    current_id bigint NOT NULL
);


--
-- Name: version_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_history (
    id bigint NOT NULL,
    version character varying(255) NOT NULL,
    config_version_id bigint NOT NULL,
    backward_compatible smallint DEFAULT 0,
    active smallint DEFAULT 1,
    created bigint NOT NULL
);


--
-- Name: version_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.version_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: version_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.version_history_id_seq OWNED BY public.version_history.id;


--
-- Name: watches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watches (
    watch_id bigint NOT NULL,
    node_id bigint NOT NULL,
    username character varying(255) NOT NULL,
    since bigint NOT NULL
);


--
-- Name: config_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_history ALTER COLUMN id SET DEFAULT nextval('public.config_history_id_seq'::regclass);


--
-- Name: nodes_cleaned id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes_cleaned ALTER COLUMN id SET DEFAULT nextval('public.nodes_cleaned_id_seq'::regclass);


--
-- Name: quartz_task_history run_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_task_history ALTER COLUMN run_id SET DEFAULT nextval('public.quartz_task_history_run_id_seq'::regclass);


--
-- Name: retention_run_summary id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retention_run_summary ALTER COLUMN id SET DEFAULT nextval('public.retention_run_summary_id_seq'::regclass);


--
-- Name: tasks task_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN task_id SET DEFAULT nextval('public.tasks_task_id_seq'::regclass);


--
-- Name: version_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_history ALTER COLUMN id SET DEFAULT nextval('public.version_history_id_seq'::regclass);


--
-- Data for Name: access_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_configs (config_name, modified, data) FROM stdin;
shared.security.joinKey	1778535814736	\\x4a455638584b67366979675361595a487277664d484656454b78575a745542384b626d7059374d4a6a59483958366552485178324c586d4272444d517a6f575478555348444442376773514c486e523659354a69325a375468564e3779
serviceId	1778535816791	\\x6a6661634030316b72636678716a7178643979317876336862736530773236
access.keys	1778535822687	\\x4a45795052427a425879345474376e48636565554659384c504c564c7348676f556444384b317057754e51444c4b674d427362314b58644b746e4e7471565a4a6d6d467332424b3843506e75623357595538517476373479627646587238536a7474757155314d35513945703856576666753742366f37774e6174747a73687477336b515a3933356d313433647555726d507852336b7274394c52636d335466327350517632583259766b79314d45436e684267553536457a71417a6a4c4c4c424b503154435339783461696b4e4144643567414e6831485664466d4c4343427a66426961685777396756377271324d5a4b3953696e4b34564d77546458344577437a663744586f333451767055566b4e6372314756556f7645394d4a36786f475267725569455966316a5a58314a676a344d516f485048317454384332776f52673158576d71796459507633573634374b6d4850365a646357316231627a665a525335555547624878467a475248435a4b6b4a45534d486f4d4b39614a6a61766955535539506d663258766a6f566a776474537746487750524d325a433436384761396f4562453764743453615a4e4a596e746a734a4c583432634a4d5736786176686368506770553448624c5a7250564161336a71394a63383533596e42346e777738555839584b66797650353273346146386e6e6f614672373463446e31616e53703636726452586f61724a417756326d38344e51565a57384e4d6155655358544758677148756a4d6a787234576556436e724642617a7557593171546d7257474c756646624b6266655970664c346a72455052487661315a4a565144416b7662696446396566475753457770744c5759467533644a72434e773772683266444d646d6b6e5254774546744d5272736b7475354b776d7876797a68597332426333734474374b6742663834396a423155443266414d38484c535563356b5856656e31634d56466f4b524c5738314165686364657767507368424c6f7a47716934674a63544643665471386455626b53396d623765705241356a34727061526a67786732724758666238624435435a473644714a4a6952664e366f647279756e416646387145524a3238434e4378616754756b433444766a487739387374716a6a564c767a58646a6a727a665853657734635945726e6372784a754c7061736a52685531665743337a6d344c3334745a61797a6e3265626b337a5878444d63584e4e64577347746e3141647747527953797755386a514750524c5031675556586a78794d3841756758484c6e536f74726235346846346142467768546878426146527a35346f6f376172467545693163463443764d5866746a5741774a677063377178694b4757337a5041753638636b706d53766e444d624e56457873575131634a627833374644383353685a6352557452595771334d4836663750366a4e586b7357524361744a473234336548416d52506a616774487454436854724d6f6854584c4c486158456b6b53506856314776674b4b426d55376e314d504d413744415853517a336772773648786e705a315734554557546e3869725354596a6231646f6a4c4267536d69764161767a726d4d4d5a4d6541636f686273347244614c69394c6b766e59513854364a5651376455674e45765048596f557453583943454b616e59394e46466e5a39663659745544365a526e773836635041465554513251554154564e545a626857414d53524d52705a55324d77726a783661503468537059663334384264326b66794a676537704c357367334b55653769466d7762695a4e4d44555763415a35725263437a474875387147366f586e55375a42714d48774a72447a346d5657757578366177797452725646456279474870714c5072356835533841525836465a5439587248767766464c676f4654627637716d476e51384c767074503473476a4866347a3739466a78427768555150484e54457748554d62576d783365356265584e3266744276634141576163776566764773363345317437695338684a5464726a3942556643667474476268567a37396570364153324731517a3675437737736f327577775a6f6475796f484a675846467245776b74767732634e396d396b37753451366f4b5745793542756733676763737078726a7762545a396333707a6b59475777695965386455634d784d614d63435a78705135516f754e66536b536332414361674775713736386e51503333676d3751686b4555747266426f6e7155594b5850753277616553444a643964357574363968634e474a6e5658526e7955514135747a505653746b326b3945554552466e363237555058386152576244556a4a3761765a6f7946384b697379515543427239326f73414e376752434a6d703461486e44777368355750585658757a7041794d37466433627879424a6f43384a5a725a4e4a625553364d59556373785a417850594e6d54715351784a6f385a336279713242364a5a4d65644e57516366704561376558764b596d4252484a76575237324169626b586a676f465454766652416731395755584b6b6b3534416659546e5677394174596468615852316f726e6d6576326544437365384b784d6836736b76526e336e637a7a6e7957637a6353793977584e634852775a32456f4566467346484545446e734a5777676e576956454e6b39784c365474584d6f45556e52566f534e344c3535506b415a48336258346d776a61324c7976774e516e7073393358364a6d6546676b6741666f5a68336e504b6d68427235477676545961506b426f4a647045377a77517252535169485367504a53653169584e6d69765843763850746974484e6f4c3443734c313775317a4c4d6f4c4266344668594147713731554a4256396f425676717943384a6466774465766f653958435447426961716675754b55717a4a55584e624465757252634e4d5251504a724539553571455937357a6f536a363835346b35543553714d456a38765668536666614455444c6b476e757351787643696353577177317351546f4e4853777745557674707a76744b345566384a44526b73686a346f4d57694e565a74786d66464365344e335a3538757a38696a7961694d37736b4a4e707972464a513933626f72665941694d42577734724d70624b5172795769646d667278546d474e53347953397574796541347a70386a78343746746335575343634b6b525031644a78336e445571456b5a54626a7248437a686a7751797766735162354e6864437a587a5657704d64427275777054566538585564626638423648395738375943344374774343514b746168337a676e5536784138486579476b5653783273714778354b436d4a774537566543394564426262536674657a383774744a4d66734c744c556a315576764476325244727134655937656a46717967484434764c6b77746e386b31534b686f7777704a6870456236644a65654733737861344a69544879635841657074687139554642794d516e69316a4d46623356425255767731714a48383678784a7165617241784c3576614e6332356a70634563467071713945367a4a715437486a5831727550564d514356646138514e635941774862336a504d77576e6453596b42585a4d33527a3650336d44667246446763463761355872716d664a5877426d536a514650655a6375454a776857335353765539796245524364506f5a424244474a506670447263464c63736e416a7941786e59554a6579544d7139385a33396131544c79764b794e77667744726b46674576645050477579787939316e6d516f5950794e677a36535a5836724a366545566e7736685652364438654175333445324d4c51666a544d4a78324d37716b4d7353646a393177345537686b6974686f546b71377178426f6d584c42477a444a734a7152554a67575635336243436270664b78756e726a4b6259507346667a45314e617065336979694e386f68376a65354e625a726738366255775371654536336f4c727239713665456b7a545048787079583439413670677a4d47785446736f75726b647034596a5672374e6872427442616e5735665341366775717836656564454e334b356243526a425a637674655242693167776d7236463752346b674b4d7a44664539387357425a78394a5a43573566394c71344c474a6b6572317a336f6f774d65536134394d6b7754326373454a544b785145763744387066335933434a6577766d64355542767537326452686a6d78556a4d61576f7869555342666569586364657674343531625550386259516f586a43416e6f4653547077546e476d563446704e593458346563574574796f336f69695831624e6b57585a7961646b3842395831436a75644736634d5953776b4e4779327a354a79616b736b4137526e57734c334a33795a79364445643750374d35764a46454a624e555a774a42684b724e364374366976444e597433373436635463564131334d6e737138647748316b6e76637441526e69516b465654754d38326145543252547548373841734273676771564d6e6e447538525639794a57454743644c4135617858655643394454613651417a555a5973436a736e446d42655536765a714e6b367772583857616f515538776557597a33574c6e65335055416e6259574334564d4350585556644e676252784e4b7458456d4832756374684a45536257375635713759774c5556467869714c36584d63354c4b6b31754250647a787855334b68376b7a4b775268586b4d63744c76574d4577484451443641397672545742337a766e3152644b7547636378633659437377436853545268316964356e327455796569534438627752564755646e4e6978736f327338707847756b32706f54614e433476786b7651705935767032616266787875734250443666486551697166454338725550366638343636536f5a5734567352574533507372385867594a7a686a6766565a61683579384172556f704d4a373766617259506b6277546373376541664d473137694754466e4834386738327958745055376b4837373772746174504b7578386d77476264755938764165535958456b794e384a5677695958465662756a487138324c5078663648364a61533733356e4c714d76617a3562414c6e67674548324444686a6654464a64624e4d724d7961594a3969386f7866524866336943796870585761356a4c6a746155437877435168484a376d61504169327a71546b78366f626878596e50415753487a597357486f50486e706351316e4c4454365447373558507034756475596945674c57357054584b386a566a34797451544559394a536f6d345047717a5a7066634e4e5575625056795532734a5674617945385978465557634a354e6b423978476d3250646e54365738366475374547325763644273357770736472517a705770534c335557514d5a536b733758716b445655637a41437271664b68444a7a75706a6668354b76557a5678634c72524d77667a7963356f4c5143387968694257677070683738696672644d70314362414c37474d6e5976535a744a4e61774b587342574b32356174436a645358534b6743697031336634525a6f7a4a574b317151705a526a7242653531594448314156776d32334a6e5732746152437379784a55365071704176716265667874565a6f52453952377a364a76517779334d46574a566e5444546f42384e4d75546a695a3666657a6267546b315a706a506947456d4c5a4175687143364252714a6d44476e364647326f76446243457a38595539566e62546d45444646514d74425a4a58766b67794b32394244387474726b55656579504e70524e7856686e367068747633354d73416357743872706e42664e5137566769624d586a795433366e4a5976397152584d68525a4d746b6a7064784538634e73513951326167614855446d6b476442757645587753536b6f42594d683839676a3673457442426a455833534e366e72437733687743324357346e5a6438344e77326f414e564e76686536385062656d51376d325571357a78694c43633967575a5657713174316337646550584a6f58464678385a324171724c585942654a63596d4464686d6f7a69725957697759475a4d5463546a526955654b7336316977544b4e753241374a704d456e4c37763551555675564b7a6d646644695667766f3257594663674b413971644737514345703645464a776e7a393872764d4c6e515966767334704c31647444375139463663416d734c566848556733687270333954384539325338416f7674695837325774614768536471744d6d4a547975534b583169334668573559445565346b34554159353478594662644173366b6b694b7361556d5375516575374d3856514c556b5374553954757a64706d58346b4370455248425153624164574741347538446372794d5248714767684448425a78795373415a467941643751616b726152364544584c55644e48724554675646553637683445637171786d4356736a516d39426d434d336a707638543246466b773868396d434245364d6b5051377138784c61385947625333525336474a46354b34624655696b6b477164713150635966794b687269636448315436324a586a464434676d71613831427435394147556344774c6f69416f73733945586b42765157654350685a4245686a507a6a656e47634e425278367376615a6a34595072476b57733837746239504d48443852534c6a623848577179787a61435a63666636744a54684b3871384c5867445350664b796b4b4653393956477747674563595278343847364b6b344a5738526e42395539426b62464452534a503636726e62675a4e687946414a59646e6a723378454a4d48736a55727856786f624b7347713443667737466f424b3272627456327939544646336d64575331647044506e4754466e477162524d326d48465a4a325231683875345272746f396e5a3433657277443835397847396258336d4b6e3264775465316846715746684e554b7a6e696e6b6d397a3758665759354166784c323551736e7546344b5763394a48365a7a6237615037597952755a527548624136674b3867345231664e6f587979615065657876693232454c36666931376464767763676871
ca.keys	1778535822985	\\x4a45415a6141356641646650554b5753674e56634d723841447964417a503548485a4e6756337a5551735665703965574e776870525778454635396e5744626167327a387843483342566757336572747937585159637a675758385079776a6369766f4e54325a6571586541633633756e3338384a6677397a38556f64485a3732384a394d434e44656b427a7a57706569357343446e663656546b7a71474d465266776436746a36744a517556675243795456754c77464475617032616a4a344558387847645172783741736971794e42787263316a636a67765478444379634e726a55614d376264507472477841447a4269474c5a74326b396b6932396b4879656e76584165736653696d7a6331657148486f7848785554524a4c4d65484d696f77704a6b77694a72614a4a6f5053456933534e4a54647172475a6368477a6434376848316a68754d4256586a4e446f79446e6e7935565a7445747947364c4639556a73546752694c505337766e77734e6466707937684e6648774d68394e6d70393861783631756e506f7959716445566b43525a6466594659753158794c54513444474a4164583238376e70415964595859784e7368694444796a3659706f77653974695a4b3356546e445a393746487262327368355354466e6f67376a3937524b3263635a7044686f4d52346169755073593431594770475466643133365442414179445042583377395932794d666f50766543726f456d5457324c763870535579695777554476774766484844384570636944557575447332446e736a714d365663755178626f474d795a6263554e413354755a766272714d697443696b46386234433677444e444c4c57434635736134443359695941654e444a4a317746555379445532486255667637776d43567847646a507a6b574a794a707a78516d424d57597671367135326b34597a676d437048477141524379644b4a59396f78763366584d7038785663486a51716753776b635672777735485a326f6f7761335a6368444633706a52466b75717050755275614c4242547a416348354144436a45414c644645414b47436e356147656673696b6159425866383565356e54505831414166394d4b45326e41507a5862795573384c4b4c597a464d47456f647862727256766d4a64334b435151487a657479556f5932584d7746755331435035584552396f6265726670377857524755346532474551414141363159486655367a4d773248464d6b48687a6b6a45426a56345668695747686f7755734b576276554c4e417a507257756f556153785442355358447153726857555673446b67474e4b515755647a41665a44356a7475526151624545506b6e4d7737724e6151395a744337597241766f753673517853457133454c714b5432504e384a376470465a326938374542753474633455326e3875756d44694544514a41433561394374667068633144784647715846645931796733716b347a4a43314b436e755254476f4b384d6d5a51414e65707352614d4e7131394e5348626e387a4b424c69374e3239546969376d69364d3741444355773351537a4c74314648737845784c447454765343687437435a31474173736a4c737258337a634c435438714c4a36434a3444355a6347794a446a5a397a7a48735a5a744a77506655434353486e634b384a6d6f4844715a7270376e397a4d3265436b74456f4636786e7a7147394d4c747741376a5538746f4d7146465642324b54446b38744e57426946696f59343157677458536d6d42625579737342705641465370454a4d663878416255695956547058507168587a6b4c544636716a39324c766e4d676a76596f5036676872334c677536424e7369327842335a68316d346f484e4547377977465831537669325a53514d3632375451417441516931564b6f664c6f65456873393279556b3832554d4e426d523872396361666879595863736e716542445545505035396e33724779705231425038687641505642546d6264793165467669486275564e414853706e5746683751746b394358585039726d336b7864475639616a47373966746a42324c7562787455674b546d515354375775526e6839786671446a6a775969774a5463385463454a52367a566a6d336e4b7439526a6b72675658546e697133794b6339324c703131747a3368707245424637774a6648324a795875546e7a77474c314a4d4c7136716f76785153525a3943544a4d62466e4a707a38487144795168384e6e706e4e4c32396e73325a506e3568784d624268746d7133786e7a7a344570457438477479534c736b55634144477335394e6868706f79397a4a63753656316345557275384d35433466615576325168395659413573585446343352684a705763755448736a5153684c4b4769555971357432784e48376d4e487954464578415831446676665148564a78655a58313639704d4463734c414e58464c484a334d62673638435536364443624243384c794e5462434b397867364e48585a4e37485131533133554c6856525736613350444873486273455733774474434d634d444434723662763779446a64364134756f384b435059536572643455715a5957594c58786e59686b51616446316d487854766b6170416a4872546e466e47554d364741574d595656537345474a473876316356546f6a4b5968694a426b6e7a324e4e4c715a433351574d786a7a7775564e6f5573706732356e4769446b7078396846674650425664646a6b4e504c565876384e57576e5733476b3556717a3765545348506b64337448506258387a775167767742516d476661697653434b44633353333558396f44476848615961586873726b6170734d6e544555313333765341746e36446868775a56643456516776696e645375644b446d797751387463556469356672556a5a386b5175346978553554744c675343695769744b4e70327a553267713261593379446b6b765a46414d365a375562687178486e7433684b6e6b324b64555a42484e76396137465467327966334a66696972767162615a373435634256427463536279506f3978326e71644b3279534c7873717a37557a526b4255396d4d5876344d7473516a6e676765595a35364d71694c38625132464a6346797a48466e64457658597765564e64367170486b63544273316a6e34644e763165345a633254716373757776315a6d707943677856777a73584b4335644a75324350763459583935486e4c4862754a5768583561344a46547757746e7a314241735553697162334d78684a76683858374772593573746931505a616f32536a314572576f377a73616b755a67316d59783941504172366574377037583475775a6f3843446736464e5a70545a385546544866764d43556e503553586f355934435171745538796d326e37726e4339314b474843785654657539726a4470444b5a33387441584d6570335639644e79474552515942517a7378744c71756d766158474a4d763151474546464b34353851764a39715056417533706b354b70346b77527a7a6f5979424c624868486e4642533232585562726a4e54353234746a4873667670744d38676465596d7252624d394478354d68586a7843375470666a786e63447057725852344b3378374355526e4e64726347784c787454336f557679626e693966674e546e7835344a54326237364663574a75654a4534724e336867686a5876464e476d386f6d5a487148354c3431774a613531324e6d3152544a674b554e4a4357787a7448617a434565507665704e327451473973616b3179376138704a794d7356774b7565654b545464547343654b395747314879583575313146336d5048686445746d567a414c4e7057414173755668756b57445957465574774237586b766664504a5a737a747a45476246345670476e537a4535586261504b4a73444b71757843546b53703138636e5438525143697a614c36455568504c4d344b6b594a4844654e7946444d353747395a5a785233747a59414a6d45546e6a5832765567315a5152793561666f6f6552504652316438794245353251796776686633746a5177417244656339526474566746614a3271373972324e506d46747977724c48374268514a686a545137676e48684c69506467734641414d705344584a5970516d627238416e64566b327233396966356b636f767678513444724b4b73375157435742687968444b4e42615a4d4744576f7a6a3146665037364a6174453438554b7470474531663943754b38685a4c444363583863767150573544473341516f584a54434658785a6e775a505a4a694141366b50535a63624c476b68444338455a313957593678507942316f6e546f574a466b37485a41655432346d674370467637755839465a63686879765436524d3335764865774d35586b674556374731764744785a6135786242557037396d485458546f6a735a50674d5a7869344c7a4e6833314667376b5835423171656465514e786366754446627348523158794c5948454677514648576375315659416b48666f463475673270627a44435a55775638543365743961376a4876384270557431524e424e436352355a31514d4255515334765758785466515344594c314e336d7070697a426778474c366b5a39356d6e344643426768314e63326a76725a3433654169485734697847746e7074413253463338325a455a576754435a6a416832615968785541734b6a594d46654e73614a457947724136426d65355950335758385468353746696e773674517275594d6f4b557562446a4a353848655a696b6e505a73755870534770746742395a585a794c70344c6d7a444c425737785132575757765973507873414a6f6b65516d316a534c326b663762706444366a58324d6a656762364a7068624d734454465862735761367a6578377457443936346b59444c4856416a357539355471366b4253596a48784e735a6a454a766f74326359394b6e556179785774675833637148593139624162466f6f62623276656153737068587958676a7436543156564e35367354456563506b6345576e44565a4d31564b4233693839366d7839706f7553594c6e547474414a4d77696653774e6742414b555a4d764b767a62757273624b647572394b626a6e67737752633332614d54634a574d5a66437366503841626e56764b624e6955675935654b774d544e68344e736e5738546559563861665958485a6a4d4c484436374864516f62515271395543536a7a4350756a684247477158714b39484a6b3852556235734d5539375a6a6b7a7a686966505a7a3161564557755a436142577859317979457555596e467a684b64796e534c6a594d4556454b33436a6d754b6a67726a476a57795534644b4238713436666f6b4b7075444b6952706a58334762514a444a65413663696d777155344b714b566d646b673369454c4545664b6e476d7232335459536f75556d4b584c594b7555716a76636e6e33334137736847616965586659365444696751703758456d61473258457265796b5572706b6b5559396a59617a4b32337341755975635475464e5168624d636a58424766456275737134384d6f6935456e71467035724474446a6b6f6a6f386564734c394e4c7541423865784434504a666f51786f617a71313151694c75614437784a4d5a556553626a4b66634658744c614273595a54735371534b467138486a465956724e666f6b315165313434457a4a6d76696d5a42596a5a61384b455a6a714d7a654c766a6248666d52597653726f546d4e71585045735a5a654e677957334677694255617233344c7068536262574c61337371644a594c38483946373354456f735a694c46685738783269476e625a4c4b353453696f7847337779396762776739364c437250334a6f6f364739564c42586a62326336656946756673686f6b53446642624156513764386a433769684672444d5861386e42515638384d55456378354d4b6b6b61526a44336a4c79507059644a466162356f4c53384233554b384c4839774861374d62335933733478367570685164476e5937377451586a6b394135646d596b74644468313150734b4d34456d664761526a4373695476616678344d69566577737433384b6d4856576d676744414c5272635669565546666947476146746b6f6d79516955676754474d57333331345a6d67727957526a663661674d4571704135664c46425869793755687857714a75485762556a6276714b4846367568506a505758746e7735326a7a39394c63346851676d66394c5133633848435156597471446b69477751793268746832344b3671626663486d7a6e31424a69395a6b574a696332444d44673334336636444358786f6a78644b7246626b324348646e3154756869366b71594452453448585874726b794a544653466f3935515832356179614468337574756f77564d7471786e55775a344e715365614566626b38727731747544543635336669657757377a637a74427662325044324c56394852384b3765636e5a736b4b4656503933467a75796647344d4b69425048525362475753656a6d45634c537858783271746761695658447163676676766a5050746b473778526b393433426e6d796474536150393344794b4872646673535a5867776e6168774e78674269336d43594c7755614c70364e76716e75414c7036557544617768595478314a6654464c516169366e4133626769554a6671446232736f4341516a637165436e6a57454a595053646b327448626d7931744243434c435644686178436d456667585759776576593439356e693772437375334a68466e6d756a4770654a424a72705036684b6d643376647844434a35327437646b4139384e6e374c643874554d31564a70356967667a423571474b50716e636e7a4547436a794878366a54633967666f555052735a6652514e6456335967595434455131713475576f7a78375742516b4138486f4d6537644561464c3779656542746e594633617152385141735773744161704850787477337467754871756a737a6279544765626b474a6375707273326e6438526d6a34337048377848517231716d507037353935384e7446576573665747594766537272644344693850565170356d71393542696a68704d4466485163694c436b31473572536e3859706d72674876596352635733354b325a716f3634325369327046397163776947345144646462374c7557726144665277564c6d77547766
access	1778536125764	\\x2d2d2d0a73656375726974793a0a2020746f6b656e2d6578706972792d6e6f74696669636174696f6e3a0a202020207363686564756c65642d74696d653a202230383a3030220a20202020656e61626c65643a2066616c73650a202020206e6f746963652d706572696f642d696e2d646179733a20310a2020616e6f6e796d6f75732d6163636573732d656e61626c65643a20747275650a66656465726174696f6e3a0a2020696e626f756e643a0a20202020736572766963652d69642d6d617070696e673a0a202020202d2066726f6d3a20226a666d64402a220a202020202020746f3a20226a666d644030316b7263667738336478626668343362667a63373136316473220a202020202d2066726f6d3a20226a667274402a220a202020202020746f3a20226a6672744030316b726366786339336762626530663938746766663033366d220a202020202d2066726f6d3a20226a66657674402a220a202020202020746f3a20226a666576744030316b72636678716a7178643979317876336862736530773236220a202020202d2066726f6d3a20226a66636667402a220a202020202020746f3a20226a666366674030316b72636678716a7178643979317876336862736530773236220a202020202d2066726f6d3a20226a666f62402a220a202020202020746f3a20226a666f624030316b726366786339336762626530663938746766663033366d220a202020202d2066726f6d3a20226a666665402a220a202020202020746f3a20226a6666654030316b72636678716a7178643979317876336862736530773236220a736368656d612d76657273696f6e3a20320a
\.


--
-- Data for Name: access_db_check; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_db_check (username, sorting_order) FROM stdin;
"0102"	1
0102	2
\.


--
-- Data for Name: access_distributed_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_distributed_lock (lock_name, owner, modified) FROM stdin;
\.


--
-- Data for Name: access_emails_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_emails_log (email, last_sent) FROM stdin;
\.


--
-- Data for Name: access_environments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_environments (id, environment_key, name, description, created, modified, predefined, ordinal, project_id) FROM stdin;
1	DEV	DEV	\N	1778535811944	1778535811944	1	0	1
2	PROD	PROD	\N	1778535811957	1778535811957	1	1	1
\.


--
-- Data for Name: access_federation_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_federation_log (log_id, created, message_type, message_change_type, message_time, message_data) FROM stdin;
\.


--
-- Data for Name: access_federation_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_federation_servers (server_name, last_success) FROM stdin;
\.


--
-- Data for Name: access_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_groups (group_id, group_name, description, auto_join, realm, realm_attributes, created, modified, lowercase_name, external_id) FROM stdin;
1	readers	A group for read-only users	1	internal	\N	1778535812197	1778536238230	readers	\N
\.


--
-- Data for Name: access_groups_custom_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_groups_custom_data (group_id, prop_key, prop_value) FROM stdin;
\.


--
-- Data for Name: access_master_key_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_master_key_status (is_unique_key, status, set_by_node_id, kid, expires) FROM stdin;
1	on	3ef7c81c2124	99548acaeff8a5962597351f2b702735627dcfb7612caa57fa7e506503343282	0
\.


--
-- Data for Name: access_nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_nodes (node_id, service_id, token_id, version, revision, created) FROM stdin;
3ef7c81c2124	jfrou@01krcfw6r58c01p44sxvg3wqa4	94837e23-3d80-41e3-af67-9d02c5801184	\N	\N	1778535822735
3ef7c81c2124	jfac@01krcfxqjqxd9y1xv3hbse0w26	\N	7.141.12	84112900	1778535827615
3ef7c81c2124	jfmd@01krcfw83dxbfh43bfzc7161ds	2f432e5a-d380-43d8-bcc2-16bac949d842	7.155.2	f08600cb80a	1778535828659
3ef7c81c2124	jfrt@01krcfxc93gbbe0f98tgff036m	82882f10-d577-4435-9579-0208ee8566f0	7.111.8	81108900	1778535828954
3ef7c81c2124	jfevt@01krcfxqjqxd9y1xv3hbse0w26	22e44be1-36b2-4e57-bb96-afd97d964916	7.169.2	84f024f1b1	1778535829035
3ef7c81c2124	jfcfg@01krcfxqjqxd9y1xv3hbse0w26	411c54cc-0f24-439f-b9dd-aef9630de397	1.60.4	16004900	1778535837114
3ef7c81c2124	jfob@01krcfxc93gbbe0f98tgff036m	3669bac5-5c0a-4718-a33d-391632c6516e	2.2.5	32a7df0e03	1778535837143
3ef7c81c2124	jffe@01krcfxqjqxd9y1xv3hbse0w26	ddfc7ef0-95d4-4362-a6d1-878d97064edf	1.175.3	10000003	1778535847126
\.


--
-- Data for Name: access_permission_action; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permission_action (action_id, perm_id, user_id, group_id, action) FROM stdin;
\.


--
-- Data for Name: access_permission_names_mapper; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permission_names_mapper (name_v2, resource_type_v2, name_identifier_v1) FROM stdin;
\.


--
-- Data for Name: access_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions (perm_id, perm_name, display_name, service_id, resource_type, created, modified, lower_display_name) FROM stdin;
\.


--
-- Data for Name: access_permissions_actions_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions_actions_v2 (action_id, perm_id, resource_type, user_id, group_id, actions) FROM stdin;
2	1	build	\N	1	1
1	1	artifact	\N	1	1
3	1	artifact	3	\N	1
4	1	build	3	\N	1
\.


--
-- Data for Name: access_permissions_custom_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions_custom_data (perm_id, data) FROM stdin;
\.


--
-- Data for Name: access_permissions_targets_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions_targets_v2 (target_id, perm_id, resource_type, target_name, is_target_ant_pattern, include_patterns, exclude_patterns) FROM stdin;
2	1	build	artifactory-build-info	0	\\x5b222a2a225d	\\x5b5d
3	2	artifact	ANY REMOTE	0	\\x5b222a2a225d	\\x5b5d
5	1	artifact	sec4us	0	\\x5b222a2a225d	\\x5b5d
6	1	artifact	ANY DISTRIBUTION	0	\\x5b222a2a225d	\\x5b5d
4	1	artifact	ANY LOCAL	0	\\x5b222a2a225d	\\x5b5d
7	1	artifact	ANY REMOTE	0	\\x5b222a2a225d	\\x5b5d
\.


--
-- Data for Name: access_permissions_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions_v2 (perm_id, name, created, modified, created_by, modified_by, lower_name, description, realm) FROM stdin;
2	Any Remote	1778535812346	1778535812346	anonymous	anonymous	any remote	Default any remote permission	INTERNAL
1	Anything	1778535812234	1778536221614	anonymous	admin	anything	Default read permissions	INTERNAL
\.


--
-- Data for Name: access_permissions_v2_ref; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_permissions_v2_ref (v1_id, v2_name) FROM stdin;
\.


--
-- Data for Name: access_platform_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_platform_config (config_key, revision, created, modified, configuration, is_secret) FROM stdin;
roles.v2.global.configuration	1	1778535811772	1778535811772	\\x7b22726f6c6573223a5b7b226e616d65223a22446576656c6f706572222c226465736372697074696f6e223a22446576656c6f70657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303735323837397d5d2c226d61736b223a307d2c7b226e616d65223a22436f6e7472696275746f72222c226465736372697074696f6e223a22436f6e7472696275746f7220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303630343930337d5d2c226d61736b223a307d2c7b226e616d65223a22566965776572222c226465736372697074696f6e223a2256696577657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303539323431377d5d2c226d61736b223a307d2c7b226e616d65223a2252656c65617365204d616e61676572222c226465736372697074696f6e223a2252656c65617365204d616e6167657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a3330393833323138383136307d5d2c226d61736b223a307d2c7b226e616d65223a225365637572697479204d616e61676572222c226465736372697074696f6e223a225365637572697479204d616e6167657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33393731323535383132397d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a33393731323535383132397d5d2c226d61736b223a307d2c7b226e616d65223a2250726f6a6563742041646d696e222c226465736372697074696f6e223a2250726f6a6563742041646d696e20526f6c65222c2274797065223a2241444d494e222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a343631313638363031353139373737333832337d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a343631313638363031353139373737333832337d5d2c226d61736b223a307d2c7b226e616d65223a224170706c69636174696f6e2041646d696e222c226465736372697074696f6e223a224170706c69636174696f6e2061646d696e20526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a313036353135313838393430387d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a313036353135313838393430387d5d2c226d61736b223a307d5d7d	0
adoption.config	1	1778535841267	1778535841267	\\x7b2264697361626c6564223a66616c73657d	0
saml.general.settings	2	1778535985009	1778535985009	\\x7b22656e61626c65223a66616c73657d	0
projects.default.configuration	2	1778535811830	1778536070952	\\x7b226e616d65223a2264656661756c74222c226465736372697074696f6e223a225669727475616c2070726f6a656374207769746820616c6c207265736f7572636573222c22726f6c6573223a7b2252656c65617365204d616e61676572223a7b226e616d65223a2252656c65617365204d616e61676572222c226465736372697074696f6e223a2252656c65617365204d616e6167657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a3330393833323138383136307d5d2c226d61736b223a307d2c22446576656c6f706572223a7b226e616d65223a22446576656c6f706572222c226465736372697074696f6e223a22446576656c6f70657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303735323837397d5d2c226d61736b223a307d2c22436f6e7472696275746f72223a7b226e616d65223a22436f6e7472696275746f72222c226465736372697074696f6e223a22436f6e7472696275746f7220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303630343930337d5d2c226d61736b223a307d2c22566965776572223a7b226e616d65223a22566965776572222c226465736372697074696f6e223a2256696577657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33343336303539323431377d5d2c226d61736b223a307d2c2250726f6a6563742041646d696e223a7b226e616d65223a2250726f6a6563742041646d696e222c226465736372697074696f6e223a2250726f6a6563742041646d696e20526f6c65222c2274797065223a2241444d494e222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a343631313638363031353139373737333832337d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a343631313638363031353139373737333832337d5d2c226d61736b223a333232393631343038307d2c224170706c69636174696f6e2041646d696e223a7b226e616d65223a224170706c69636174696f6e2041646d696e222c226465736372697074696f6e223a224170706c69636174696f6e2061646d696e20526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a313036353135313838393430387d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a313036353135313838393430387d5d2c226d61736b223a307d2c225365637572697479204d616e61676572223a7b226e616d65223a225365637572697479204d616e61676572222c226465736372697074696f6e223a225365637572697479204d616e6167657220526f6c65222c2274797065223a22505245444546494e4544222c22656e7669726f6e6d656e74416374696f6e73223a5b7b226964223a22444556222c226e616d65223a22444556222c226d61736b223a33393731323535383132397d2c7b226964223a2250524f44222c226e616d65223a2250524f44222c226d61736b223a33393731323535383132397d5d2c226d61736b223a307d7d2c227573657273223a7b7d2c2267726f757073223a7b7d2c227265736f7572636573223a7b227265706f223a7b227265736f7572636573223a7b22736563347573223a7b227265736f757263654e616d65223a22736563347573222c22656e7669726f6e6d656e7473223a5b2250524f44222c22444556225d2c227368617265645769746850726f6a65637473223a5b5d2c2273686172656457697468416c6c50726f6a65637473223a66616c73652c227368617265546172676574223a66616c73652c22736861726564526561644f6e6c79223a66616c73657d7d7d7d2c22656e7669726f6e6d656e7473223a7b2250524f44223a7b226964223a2250524f44222c226e616d65223a2250524f44222c226f72646572223a317d2c22444556223a7b226964223a22444556222c226e616d65223a22444556222c226f72646572223a307d7d2c2270726f6a65637441646d696e43616e4d616e6167654d656d62657273223a747275652c2270726f6a65637441646d696e43616e4d616e6167655265736f7572636573223a747275652c2270726f6a65637441646d696e43616e496e6465785265736f7572636573223a747275652c2270726f6a6563744b6579223a2264656661756c74227d	0
frontend.session.timeMinutes	1	1778536125124	1778536125124	\\x3330	0
crowd.proxy.setting	3	1778535843253	1778536125421	\\x7b22706f7274223a302c22706c6174666f726d44656661756c74223a66616c73657d	0
\.


--
-- Data for Name: access_project_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_project_groups (project_id, group_id, role_id) FROM stdin;
\.


--
-- Data for Name: access_project_resource_environments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_project_resource_environments (resource_id, environment_id) FROM stdin;
1	2
1	1
\.


--
-- Data for Name: access_project_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_project_resources (id, type, name, project_id, auto_share, read_only_share) FROM stdin;
1	repo	sec4us	1	0	0
\.


--
-- Data for Name: access_project_shared_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_project_shared_resources (resource_id, project_id) FROM stdin;
\.


--
-- Data for Name: access_project_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_project_users (project_id, user_id, role_id) FROM stdin;
\.


--
-- Data for Name: access_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_projects (id, project_key, name, description, created, modified, storage_bytes, storage_soft_limit, storage_email_notification, predefined) FROM stdin;
1	default	default	Virtual project with all resources	1778535811892	1778535811892	-1	0	1	1
\.


--
-- Data for Name: access_role_environment_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_role_environment_actions (role_id, environment_id, actions) FROM stdin;
1001	1	34360752879
1002	1	34360604903
1003	1	34360592417
1004	1	309832188160
1005	1	39712558129
1005	2	39712558129
1006	1	4611686015197773823
1006	2	4611686015197773823
1007	1	1065151889408
1007	2	1065151889408
\.


--
-- Data for Name: access_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_roles (id, role_key, name, description, created, modified, actions, predefined, project_id) FROM stdin;
1001	developer	Developer	Developer Role	1778535811981	1778535811981	0	1	1
1002	contributor	Contributor	Contributor Role	1778535811994	1778535811994	0	1	1
1003	viewer	Viewer	Viewer Role	1778535812001	1778535812001	0	1	1
1004	release_manager	Release Manager	Release Manager Role	1778535812008	1778535812008	0	1	1
1005	security_manager	Security Manager	Security Manager Role	1778535812013	1778535812013	0	1	1
1006	project_admin	Project Admin	Project Admin Role	1778535812018	1778535812018	3229614080	1	1
1007	application_admin	Application Admin	Application admin Role	1778535812022	1778535812022	0	1	1
\.


--
-- Data for Name: access_schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_schema_version (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	artifactory	2026-05-11 18:43:19.984995	0	t
2	1.1	Baseline Schema	SQL	V1_1__Baseline_Schema.sql	908622514	artifactory	2026-05-11 18:43:20.134515	60	t
3	2	Initial Schema Update	SQL	V2__Initial_Schema_Update.sql	-326655470	artifactory	2026-05-11 18:43:20.252035	27	t
4	3.0	ChangeUserIdToBigIntAddBcryptPassword	JDBC	org.jfrog.access.server.db.migration.postgresql.V3_0__ChangeUserIdToBigIntAddBcryptPassword	\N	artifactory	2026-05-11 18:43:20.314596	71	t
5	3.1	Add Extended User Data	SQL	V3_1__Add_Extended_User_Data.sql	1768993512	artifactory	2026-05-11 18:43:20.400249	173	t
6	3.2	Add Grpc Info	SQL	V3_2__Add_Grpc_Info.sql	-1556763320	artifactory	2026-05-11 18:43:20.616965	13	t
7	3.3	Add Master Key Status Table	SQL	V3_3__Add_Master_Key_Status_Table.sql	501138547	artifactory	2026-05-11 18:43:20.64994	16	t
8	3.4	Add Federation	SQL	V3_4__Add_Federation.sql	-2049707775	artifactory	2026-05-11 18:43:20.691094	25	t
9	3.5	Encryption Support	SQL	V3_5__Encryption_Support.sql	-1839667810	artifactory	2026-05-11 18:43:20.738755	13	t
10	3.6	Add Federation Created Index	SQL	V3_6__Add_Federation_Created_Index.sql	1563469582	artifactory	2026-05-11 18:43:20.766308	10	t
11	3.7	LowercaseAllUsers	JDBC	org.jfrog.access.server.db.migration.postgresql.V3_7__LowercaseAllUsers	\N	artifactory	2026-05-11 18:43:20.801014	18	t
12	3.8	Add Action Perm Id Index	SQL	V3_8__Add_Action_Perm_Id_Index.sql	-1780190710	artifactory	2026-05-11 18:43:20.83788	14	t
13	3.10	Add Scope Param Tokens Table	SQL	V3_10__Add_Scope_Param_Tokens_Table.sql	1171782071	artifactory	2026-05-11 18:43:20.869699	3	t
14	3.11	DedupPermissionNames	JDBC	org.jfrog.access.server.db.migration.postgresql.V3_11__DedupPermissionNames	\N	artifactory	2026-05-11 18:43:20.889827	12	t
15	3.12	Add perm display name Index	SQL	V3_12__Add_perm_display_name_Index.sql	-2109173972	artifactory	2026-05-11 18:43:20.916447	12	t
16	3.13	Add Access Nodes	SQL	V3_13__Add_Access_Nodes.sql	-1452039535	artifactory	2026-05-11 18:43:20.94093	15	t
17	3.14	Add Access Topology	SQL	V3_14__Add_Access_Topology.sql	-852887228	artifactory	2026-05-11 18:43:20.973651	21	t
18	3.15	Topology add router id	SQL	V3_15__Topology_add_router_id.sql	1901187802	artifactory	2026-05-11 18:43:21.010427	4	t
19	3.16	AddUserNameTypeToToken	JDBC	org.jfrog.access.server.db.migration.postgresql.V3_16__AddUserNameTypeToToken	\N	artifactory	2026-05-11 18:43:21.032025	31	t
20	4.0	UpdatePermissionCustomData	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_0__UpdatePermissionCustomData	\N	artifactory	2026-05-11 18:43:21.073724	54	t
21	4.1	RenameDbJoinKey	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_1__RenameDbJoinKey	\N	artifactory	2026-05-11 18:43:21.140942	12	t
22	4.2	Fix Access Nodes PK	SQL	V4_2__Fix_Access_Nodes_PK.sql	-1444493122	artifactory	2026-05-11 18:43:21.162807	20	t
23	4.3	Add perm search name	SQL	V4_3__Add_perm_search_name.sql	1533425612	artifactory	2026-05-11 18:43:21.201555	23	t
24	4.4	Remove context url	SQL	V4_4__Remove_context_url.sql	-1172303134	artifactory	2026-05-11 18:43:21.249629	8	t
25	4.5	Add ca fingerprint	SQL	V4_5__Add_ca_fingerprint.sql	-1250299485	artifactory	2026-05-11 18:43:21.281427	8	t
26	4.7	Add topology router id Index	SQL	V4_7__Add_topology_router_id_Index.sql	-1359287939	artifactory	2026-05-11 18:43:21.305815	6	t
27	4.8	Add version access nodes	SQL	V4_8__Add_version_access_nodes.sql	-130334727	artifactory	2026-05-11 18:43:21.324346	4	t
28	4.9	Add platform config	SQL	V4_9__Add_platform_config.sql	-1670488496	artifactory	2026-05-11 18:43:21.340481	19	t
29	4.10	Change version length	SQL	V4_10__Change_version_length.sql	-468267817	artifactory	2026-05-11 18:43:21.378202	3	t
30	4.11	TlsMinimalVersion	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_11__TlsMinimalVersion	\N	artifactory	2026-05-11 18:43:21.392891	8	t
31	4.12	RenameDefaultProjectConfiguration	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_12__RenameDefaultProjectConfiguration	\N	artifactory	2026-05-11 18:43:21.4176	9	t
32	4.13	InjectMinRevocableExpiryOldDefaultValue	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_13__InjectMinRevocableExpiryOldDefaultValue	\N	artifactory	2026-05-11 18:43:21.445699	6	t
33	4.14	DefaultProjectConfigurationDefaultValues	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_14__DefaultProjectConfigurationDefaultValues	\N	artifactory	2026-05-11 18:43:21.462523	13	t
34	4.15	ProjectRolesAction	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_15__ProjectRolesAction	\N	artifactory	2026-05-11 18:43:21.490935	11	t
35	4.16	Add Federate User Custom Data Table	SQL	V4_16__Add_Federate_User_Custom_Data_Table.sql	-924250911	artifactory	2026-05-11 18:43:21.521724	16	t
36	4.17	ProjectUsersToLowerCase	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_17__ProjectUsersToLowerCase	\N	artifactory	2026-05-11 18:43:21.558468	11	t
37	4.18	ProjectRolesAdvancedAction	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_18__ProjectRolesAdvancedAction	\N	artifactory	2026-05-11 18:43:21.583925	29	t
38	4.19	ProjectResourceDefaultEnv	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_19__ProjectResourceDefaultEnv	\N	artifactory	2026-05-11 18:43:21.62419	12	t
39	4.20	DefaultRoleEnvironment	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_20__DefaultRoleEnvironment	\N	artifactory	2026-05-11 18:43:21.652349	7	t
40	4.21	PasswordPolicy	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_21__PasswordPolicy	\N	artifactory	2026-05-11 18:43:21.670502	7	t
41	4.23	ProjectRolesPipelinesAction	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_23__ProjectRolesPipelinesAction	\N	artifactory	2026-05-11 18:43:21.697106	11	t
42	4.24	ProjectRolesPerEnv	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_24__ProjectRolesPerEnv	\N	artifactory	2026-05-11 18:43:21.717929	5	t
43	4.25	AddGlobalRolesMask	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_25__AddGlobalRolesMask	\N	artifactory	2026-05-11 18:43:21.732283	5	t
44	4.26	CovertProjectAdminToRole	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_26__CovertProjectAdminToRole	\N	artifactory	2026-05-11 18:43:21.746068	3	t
45	4.27	ProjectReleaseManagerRole	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_27__ProjectReleaseManagerRole	\N	artifactory	2026-05-11 18:43:21.757579	6	t
46	4.28	ProjectStorageQuotaSoftLimit	JDBC	org.jfrog.access.server.db.migration.postgresql.V4_28__ProjectStorageQuotaSoftLimit	\N	artifactory	2026-05-11 18:43:21.774028	4	t
47	7.12	Alter username lengh	SQL	V7_12__Alter_username_lengh.sql	-168312380	artifactory	2026-05-11 18:43:21.786198	5	t
48	7.13.0.1	ProjectResourcesMap	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_13_0_1__ProjectResourcesMap	\N	artifactory	2026-05-11 18:43:21.803226	5	t
49	7.14.0.1	UseProjectKeyInsteadOfProjectName	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_14_0_1__UseProjectKeyInsteadOfProjectName	\N	artifactory	2026-05-11 18:43:21.818156	5	t
50	7.15.0.1	AddProjectAdminCanDoDefaultValues	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_15_0_1__AddProjectAdminCanDoDefaultValues	\N	artifactory	2026-05-11 18:43:21.835158	7	t
51	7.17	Add secret	SQL	V7_17__Add_secret.sql	-1711109882	artifactory	2026-05-11 18:43:21.850703	3	t
52	7.18	Add group lowercase name	SQL	V7_18__Add_group_lowercase_name.sql	-209832841	artifactory	2026-05-11 18:43:21.865572	10	t
53	7.19.0.0	ProjectSecurityManagerRole	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_19_0_0__ProjectSecurityManagerRole	\N	artifactory	2026-05-11 18:43:21.888539	7	t
54	7.19.0.1	RemoveXrayAdminPrivileges	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_19_0_1__RemoveXrayAdminPrivileges	\N	artifactory	2026-05-11 18:43:21.90387	14	t
55	7.20	Add description access tokens	SQL	V7_20__Add_description_access_tokens.sql	-1406151517	artifactory	2026-05-11 18:43:21.92795	7	t
56	7.22	TopologyFillFactor	SQL	V7_22__TopologyFillFactor.sql	-1603463202	artifactory	2026-05-11 18:43:21.96128	5	t
57	7.23	Extend token description field	SQL	V7_23__Extend_token_description_field.sql	267031070	artifactory	2026-05-11 18:43:21.993918	2	t
58	7.24	Add distributed lock table	SQL	V7_24__Add_distributed_lock_table.sql	249916326	artifactory	2026-05-11 18:43:22.015483	13	t
59	7.25	DbCheck	SQL	V7_25__DbCheck.sql	-718446999	artifactory	2026-05-11 18:43:22.042704	10	t
60	7.26	GroupExternalId	SQL	V7_26__GroupExternalId.sql	-1716095819	artifactory	2026-05-11 18:43:22.080219	2	t
61	7.29.0.0	AddCheckDBPrimaryKey	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_29_0_0__AddCheckDBPrimaryKey	\N	artifactory	2026-05-11 18:43:22.104649	27	t
62	7.35	EmailsLog	SQL	V7_35__EmailsLog.sql	1343834497	artifactory	2026-05-11 18:43:22.154192	17	t
63	7.35.0.1	ProjectMissingRoles	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_35_0_1__ProjectMissingRoles	\N	artifactory	2026-05-11 18:43:22.19127	7	t
64	7.39.0.0	SpecialCharPasswordPolicyDefault	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_39_0_0__SpecialCharPasswordPolicyDefault	\N	artifactory	2026-05-11 18:43:22.207473	6	t
65	7.40	AddPayloadAndReferenceToTokensTable	SQL	V7_40__AddPayloadAndReferenceToTokensTable.sql	2112969187	artifactory	2026-05-11 18:43:22.224957	9	t
66	7.40.1.0	ReadPolicyRoleAction	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_40_1_0__ReadPolicyRoleAction	\N	artifactory	2026-05-11 18:43:22.244947	10	t
67	7.41	Alter index access users username	SQL	V7_41__Alter_index_access_users_username.sql	-1355318378	artifactory	2026-05-11 18:43:22.263245	7	t
68	7.42	Alter and remove index access tokens table	SQL	V7_42__Alter_and_remove_index_access_tokens_table.sql	-607694927	artifactory	2026-05-11 18:43:22.287151	13	t
69	7.43	Delete replicator and system internal tokens	SQL	V7_43__Delete_replicator_and_system_internal_tokens.sql	2073057642	artifactory	2026-05-11 18:43:22.341955	9	t
70	7.44	Add access permission v2 ref	SQL	V7_44__Add_access_permission_v2_ref.sql	-1720438316	artifactory	2026-05-11 18:43:22.37107	22	t
71	7.56.0.0	ProjectDefaultEnvironment	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_56_0_0__ProjectDefaultEnvironment	\N	artifactory	2026-05-11 18:43:22.409433	8	t
72	7.59.0.0	EnvironmentRoleEntityNameToId	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_59_0_0__EnvironmentRoleEntityNameToId	\N	artifactory	2026-05-11 18:43:22.428932	6	t
73	7.60.0.0	EnvironmentRoleEntityBothNameAndId	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_60_0_0__EnvironmentRoleEntityBothNameAndId	\N	artifactory	2026-05-11 18:43:22.44859	2	t
74	7.62.0.0	RemoveNonAdminEntitiesFromDefaultProject	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_62_0_0__RemoveNonAdminEntitiesFromDefaultProject	\N	artifactory	2026-05-11 18:43:22.458365	8	t
75	7.78.0.0	AddPermissionActionIndexes	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_78_0_0__AddPermissionActionIndexes	\N	artifactory	2026-05-11 18:43:22.479406	26	t
76	7.80	Add Project Key Param Tokens Table	SQL	V7_80__Add_Project_Key_Param_Tokens_Table.sql	-1183853308	artifactory	2026-05-11 18:43:22.519353	34	t
77	7.81	Clean users password from MD5 leftovers	SQL	V7_81__Clean_users_password_from_MD5_leftovers.sql	1968411910	artifactory	2026-05-11 18:43:22.573596	8	t
78	7.82	Create permissions v2 tables	SQL	V7_82__Create_permissions_v2_tables.sql	1447581106	artifactory	2026-05-11 18:43:22.605703	122	t
79	7.82.0.1	PermissionsV2DataMigration	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_82_0_1__PermissionsV2DataMigration	\N	artifactory	2026-05-11 18:43:22.764345	63	t
80	7.99.0.0	RemoveExecuteActionFromIrrelevantPermissionResources	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_99_0_0__RemoveExecuteActionFromIrrelevantPermissionResources	\N	artifactory	2026-05-11 18:43:22.835075	1	t
81	7.103.1	Create projects v2 table	SQL	V7_103_1__Create_projects_v2_table.sql	1296347988	artifactory	2026-05-11 18:43:22.842756	24	t
82	7.104.0	Add Topology Availability Zone	SQL	V7_104_0__Add_Topology_Availability_Zone.sql	463540911	artifactory	2026-05-11 18:43:22.879587	3	t
83	7.104.1	Alter projects v2 table	SQL	V7_104_1__Alter_projects_v2_table.sql	-1665498249	artifactory	2026-05-11 18:43:22.897647	26	t
84	7.104.2	CreateProjectsTableAndCopyProjects	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_104_2__CreateProjectsTableAndCopyProjects	\N	artifactory	2026-05-11 18:43:22.936053	1	t
85	7.104.3	Environments table	SQL	V7_104_3__Environments_table.sql	206098783	artifactory	2026-05-11 18:43:22.945054	27	t
86	7.105.0.0	Add PK To Access Permission Names Mapper	SQL	V7_105_0_0__Add_PK_To_Access_Permission_Names_Mapper.sql	947589724	artifactory	2026-05-11 18:43:22.983176	15	t
87	7.105.1	Projects resources table	SQL	V7_105_1__Projects_resources_table.sql	-1183314580	artifactory	2026-05-11 18:43:23.00952	37	t
88	7.105.1.1	Create roles and environment actions tables	SQL	V7_105_1_1__Create_roles_and_environment_actions_tables.sql	-812385520	artifactory	2026-05-11 18:43:23.061269	35	t
89	7.105.1.2	MigrateEnvironments	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_105_1_2__MigrateEnvironments	\N	artifactory	2026-05-11 18:43:23.111429	1	t
90	7.105.2.0	RemoveAnonymousFromDefaultPermissions	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_105_2_0__RemoveAnonymousFromDefaultPermissions	\N	artifactory	2026-05-11 18:43:23.120714	6	t
91	7.105.3	CopyRolesToRolesTable	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_105_3__CopyRolesToRolesTable	\N	artifactory	2026-05-11 18:43:23.136538	1	t
92	7.105.4	RemoveRouterServiceIdMappings	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_105_4__RemoveRouterServiceIdMappings	\N	artifactory	2026-05-11 18:43:23.144467	3	t
93	7.106.0	Create projects users table	SQL	V7_106_0__Create_projects_users_table.sql	-1161509007	artifactory	2026-05-11 18:43:23.15894	13	t
94	7.106.1	Access project groups	SQL	V7_106_1__Access_project_groups.sql	1344529926	artifactory	2026-05-11 18:43:23.186938	23	t
95	7.106.2	Extend projects description field	SQL	V7_106_2__Extend_projects_description_field.sql	1380380509	artifactory	2026-05-11 18:43:23.233107	6	t
96	7.106.3	Projects shared resources table	SQL	V7_106_3__Projects_shared_resources_table.sql	999976145	artifactory	2026-05-11 18:43:23.251527	12	t
97	7.106.4	CopyResourcesToResourcesTable	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_106_4__CopyResourcesToResourcesTable	\N	artifactory	2026-05-11 18:43:23.2756	1	t
98	7.107.0	CopyUsersAndGroupsToNewProjectsTables	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_107_0__CopyUsersAndGroupsToNewProjectsTables	\N	artifactory	2026-05-11 18:43:23.285577	1	t
99	7.108.0	MigrateProjectsOnceAgain	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_108_0__MigrateProjectsOnceAgain	\N	artifactory	2026-05-11 18:43:23.292557	13	t
100	7.108.1	MigrateEnvironmentsOnceAgain	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_108_1__MigrateEnvironmentsOnceAgain	\N	artifactory	2026-05-11 18:43:23.315476	6	t
101	7.108.2	MigrateGlobalRoles	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_108_2__MigrateGlobalRoles	\N	artifactory	2026-05-11 18:43:23.3331	4	t
102	7.108.3	MigrateProjectEnvironments	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_108_3__MigrateProjectEnvironments	\N	artifactory	2026-05-11 18:43:23.348441	6	t
103	7.1120	MigrateProjectRoles	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1120__MigrateProjectRoles	\N	artifactory	2026-05-11 18:43:23.371601	3	t
104	7.1121.0.0	AddDestinationActionsToProjectAdmin	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1121_0_0__AddDestinationActionsToProjectAdmin	\N	artifactory	2026-05-11 18:43:23.382145	3	t
105	7.1122.0.0	MigrateProjectRolesOnceAgain	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1122_0_0__MigrateProjectRolesOnceAgain	\N	artifactory	2026-05-11 18:43:23.393843	3	t
106	7.1128.0	Change user password length	SQL	V7_1128_0__Change_user_password_length.sql	1116221275	artifactory	2026-05-11 18:43:23.402982	2	t
107	7.1129.0	MigrateProjectResources	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1129_0__MigrateProjectResources	\N	artifactory	2026-05-11 18:43:23.414031	4	t
108	7.1130.0.0	AddDestinationActionsToProjectAdminOnceAgain	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1130_0_0__AddDestinationActionsToProjectAdminOnceAgain	\N	artifactory	2026-05-11 18:43:23.427524	6	t
109	7.1130.0.1	MigrateProjectGroups	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1130_0_1__MigrateProjectGroups	\N	artifactory	2026-05-11 18:43:23.445107	12	t
110	7.1130.0.2	MigrateProjectUsers	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1130_0_2__MigrateProjectUsers	\N	artifactory	2026-05-11 18:43:23.475214	7	t
111	7.1130.1	Add scheduled tasks	SQL	V7_1130_1__Add_scheduled_tasks.sql	1067654463	artifactory	2026-05-11 18:43:23.500156	37	t
112	7.1133.0.0	RemoveDuplicatesV1Resources	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1133_0_0__RemoveDuplicatesV1Resources	\N	artifactory	2026-05-11 18:43:23.557967	6	t
113	7.1133.1	Add Priority scheduled tasks	SQL	V7_1133_1__Add_Priority_scheduled_tasks.sql	634228122	artifactory	2026-05-11 18:43:23.578534	12	t
114	7.1134.0.0	AddProjectNameConstraint	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1134_0_0__AddProjectNameConstraint	\N	artifactory	2026-05-11 18:43:23.611373	10	t
115	7.1134.1.0	RemoveAutoSharedResources	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1134_1_0__RemoveAutoSharedResources	\N	artifactory	2026-05-11 18:43:23.632526	8	t
116	7.1136.0.0	AddGroupDnToCustomData	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1136_0_0__AddGroupDnToCustomData	\N	artifactory	2026-05-11 18:43:23.652618	5	t
117	7.1136.1	Add last used to access tokens	SQL	V7_1136_1__Add_last_used_to_access_tokens.sql	456445935	artifactory	2026-05-11 18:43:23.668487	6	t
118	7.1136.2.0	AddApplicationAdminRole	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1136_2_0__AddApplicationAdminRole	\N	artifactory	2026-05-11 18:43:23.69171	30	t
119	7.1136.3	0  AddMlActionsToProjectAdmin	JDBC	org.jfrog.access.server.db.migration.postgresql.V7_1136_3__0__AddMlActionsToProjectAdmin	\N	artifactory	2026-05-11 18:43:23.733706	14	t
\.


--
-- Data for Name: access_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_servers (server_id, created, modified, server_name, version, prvkey_fingerprint, prvkey_last_modified, last_heartbeat, prv_ca_key_fingerprint) FROM stdin;
9d57cabd-7b9f-408b-8161-6db18e9b8fc5	1778535827610	1778535827610	3ef7c81c2124	7.141.12	89799af7591a85a7b636be50ce6bdbe7b20a62a9839bc0390b573d86abe2ff78	1778535827609	1778536413164	2d429603d1c4ca3dc292e31d0ffe80ae0e62310fbd8901f1d9725fd4a5440abf
\.


--
-- Data for Name: access_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_tasks (task_name, task_instance, task_data, execution_time, picked, picked_by, last_success, last_failure, consecutive_failures, last_heartbeat, version, priority) FROM stdin;
\.


--
-- Data for Name: access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_tokens (token_id, subject, owner, created, expiry, refresh_token, scope, token_type, username, description, payload, hashed_reference, project_key, last_used) FROM stdin;
94837e23-3d80-41e3-af67-9d02c5801184	jfrou@01krcfw6r58c01p44sxvg3wqa4	jfrou@01krcfw6r58c01p44sxvg3wqa4	1778535821849	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"94837e23-3d80-41e3-af67-9d02c5801184","subject":"jfrou@01krcfw6r58c01p44sxvg3wqa4","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfrou@01krcfw6r58c01p44sxvg3wqa4","issuedAt":1778535821849}	\N	\N	0
2f432e5a-d380-43d8-bcc2-16bac949d842	jfmd@01krcfw83dxbfh43bfzc7161ds	jfmd@01krcfw83dxbfh43bfzc7161ds	1778535828623	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"2f432e5a-d380-43d8-bcc2-16bac949d842","subject":"jfmd@01krcfw83dxbfh43bfzc7161ds","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfmd@01krcfw83dxbfh43bfzc7161ds","issuedAt":1778535828623}	\N	\N	0
82882f10-d577-4435-9579-0208ee8566f0	jfrt@01krcfxc93gbbe0f98tgff036m	jfrt@01krcfxc93gbbe0f98tgff036m	1778535828937	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"82882f10-d577-4435-9579-0208ee8566f0","subject":"jfrt@01krcfxc93gbbe0f98tgff036m","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfrt@01krcfxc93gbbe0f98tgff036m","issuedAt":1778535828937}	\N	\N	0
22e44be1-36b2-4e57-bb96-afd97d964916	jfevt@01krcfxqjqxd9y1xv3hbse0w26	jfevt@01krcfxqjqxd9y1xv3hbse0w26	1778535829018	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"22e44be1-36b2-4e57-bb96-afd97d964916","subject":"jfevt@01krcfxqjqxd9y1xv3hbse0w26","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfevt@01krcfxqjqxd9y1xv3hbse0w26","issuedAt":1778535829018}	\N	\N	0
d5831bd6-78b1-4ed7-a376-c5e29a230665	jftpl@01krcfwtqhjjbz1pf84re41xhr	jftpl@01krcfwtqhjjbz1pf84re41xhr	1778535832554	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"d5831bd6-78b1-4ed7-a376-c5e29a230665","subject":"jftpl@01krcfwtqhjjbz1pf84re41xhr","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jftpl@01krcfwtqhjjbz1pf84re41xhr","issuedAt":1778535832554}	\N	\N	0
411c54cc-0f24-439f-b9dd-aef9630de397	jfcfg@01krcfxqjqxd9y1xv3hbse0w26	jfcfg@01krcfxqjqxd9y1xv3hbse0w26	1778535837106	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"411c54cc-0f24-439f-b9dd-aef9630de397","subject":"jfcfg@01krcfxqjqxd9y1xv3hbse0w26","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfcfg@01krcfxqjqxd9y1xv3hbse0w26","issuedAt":1778535837106}	\N	\N	0
3669bac5-5c0a-4718-a33d-391632c6516e	jfob@01krcfxc93gbbe0f98tgff036m	jfob@01krcfxc93gbbe0f98tgff036m	1778535837135	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"3669bac5-5c0a-4718-a33d-391632c6516e","subject":"jfob@01krcfxc93gbbe0f98tgff036m","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jfob@01krcfxc93gbbe0f98tgff036m","issuedAt":1778535837135}	\N	\N	0
961bf181-a50f-4bfe-b699-20fc43d17fff	jfrt@01krcfxc93gbbe0f98tgff036m	jfrt@01krcfxc93gbbe0f98tgff036m	1778535844222	2724615844222	\N	HASHED:f3c12b40fa0d4c2ddd2c8705a33590c13531d2fcfa19b3e356e4db61fb8288b7	generic	\N		{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"961bf181-a50f-4bfe-b699-20fc43d17fff","subject":"jfrt@01krcfxc93gbbe0f98tgff036m","scope":"applied-permissions/admin","audience":"jfmd@01krcfw83dxbfh43bfzc7161ds","version":"2","expiry":946080000,"issuer":"jfrt@01krcfxc93gbbe0f98tgff036m","issuedAt":1778535844222}	\N	\N	0
ddfc7ef0-95d4-4362-a6d1-878d97064edf	jffe@01krcfxqjqxd9y1xv3hbse0w26	jffe@01krcfxqjqxd9y1xv3hbse0w26	1778535847097	0	\N	HASHED:dd474e450473186ec733689b549a94a54a96f276dba76b29138c57b6afe15bf7	generic	\N	\N	{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"ddfc7ef0-95d4-4362-a6d1-878d97064edf","subject":"jffe@01krcfxqjqxd9y1xv3hbse0w26","scope":"admin","audience":"jfac@01krcfxqjqxd9y1xv3hbse0w26","version":"2","expiry":0,"issuer":"jffe@01krcfxqjqxd9y1xv3hbse0w26","issuedAt":1778535847097}	\N	\N	0
2a7ba69f-459b-4b7b-bcc7-f1c564d53b8b	jfrt@01krcfxc93gbbe0f98tgff036m/users/admin	jfrt@01krcfxc93gbbe0f98tgff036m/users/admin	1778535889952	0	\N	HASHED:d82aa950d32ca6ad63a95b77914c32ae87850e43e42a7ef157959a30e8028497	generic	admin		{"kid":"UdEvIQVLRxxhn9IJgq9l-iWcPjSdgRpXfhCMJ2LC224","tokenId":"2a7ba69f-459b-4b7b-bcc7-f1c564d53b8b","subject":"jfrt@01krcfxc93gbbe0f98tgff036m/users/admin","scope":"member-of-groups:admin","audience":"jfrt@01krcfxc93gbbe0f98tgff036m","version":"2","expiry":0,"issuer":"jfrt@01krcfxc93gbbe0f98tgff036m/users/admin","issuedAt":1778535889952}	\N	\N	0
\.


--
-- Data for Name: access_topology; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_topology (endpoint_id, service_id, node_id, created, ip, port, is_secure, paths, state, last_updated, router_id, availability_zone_id) FROM stdin;
\.


--
-- Data for Name: access_unique_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_unique_ids (index_type, current_id) FROM stdin;
permission_actions	0
users	1001
projects	1000
environments	1000
roles	2000
groups	1000
permissions	1000
permissions_targets	1000
permissions_actions	1000
project_resources	1000
\.


--
-- Data for Name: access_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_users (user_id, username, password, allowed_ips, created, modified, firstname, lastname, email, realm, status, last_login_time, last_login_ip, failed_attempts, status_last_modified, password_last_modified) FROM stdin;
3	anonymous	\N	*	1778535812224	1778536238213	\N	\N	\N	internal	enabled	0	\N	0	1778535812224	0
2	admin	argon$$argon2id$v=19$m=512,t=16,p=1$A6y1dg+BwPZxAg3lpLF+Uw$Y2kEBX8j4WNksjiAccfsOo4RsftOOzf+5+yZhtP07v0	127.0.0.1	1778535811601	1778536335029	\N	\N	helvio@labs.sec4us.com.br	internal	enabled	1778535995039	172.21.0.1	0	1778535995039	1778536335026
\.


--
-- Data for Name: access_users_custom_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_users_custom_data (user_id, prop_key, prop_value, prop_sensitive, prop_cluster_local) FROM stdin;
3	disabled_password	true	0	0
2	updatable_profile	true	0	0
2	artifactory_admin	true	0	0
2	private_key	JRMP38RoQxYq6m8DL5aZejrTNjiYVNxeWUqcEPh2UTxGHrxNmT5ydSv9x4UV8HmxwbXEQPEcnLedpQsGuJfwBV13zVSKCnhaEQ1pnHmoHp9De17MyQVXhPXLpJETagEBwHkGt9j2NaWZdZuDvsqiH3vQ3WeAQWnZsUjzHkrsTimtiWekckuN9LbSPcV7EnkYuHUuYMtv6Pnf5qai7aqjAwfiuGBk2WGzR8hcf8DS3QTd6EWNDy8hJNvRcWGUrp7usAGTjHDKGTFF4rFdcRJ8mWf8FZmThPStdwoRuxhwc5FnE2jes4Sw5sVcRZNwWqimpSiJoZLUhYXfaUH7t7TA9zcNB3is5zS4n6Bx9wQ8k9BjX2pzr8A7vBRQexdAYgYXkG7KmhdmbXk1UNzeJv4KXrvJqgu6YsNjMzJAtRgG3rX8xaBgb2KZV6uU9eanSFnaHdhy64nTw3PYEuevzhvTvycfK	0	0
2	public_key	JUHfDLxBPMe4YZbWLKdbams2ZTPq3rmG1zxgRgZ7VjtWAUkL35Btby8uKN1uDAvvUiuRTD4bH7nMu5s44uGvgcNje1GocvetsdqX4q7but4mcSy6PYh4dhJUyU12kmoBr1WBc	0	0
2	userCustomData	{"onboardingSteps":{"artifactory":{"index":1,"isDone":false,"children":[{"id":"create_repositories","isDone":true},{"id":"create_users","isDone":false},{"id":"create_groups","isDone":false},{"id":"set_permissions","isDone":false},{"id":"deploy_artifacts","isDone":false}]}},"userSkippedOnboarding":false,"wizardIsClosed":false,"createdPrevRepo":false,"userDismissedDeployBubble":false,"userSeenGuide":false,"userSeenGettingStarted":false,"projectsGettingStartedProgress":{"isNewNotificationVisible":true,"isNotificationBubbleActive":false,"shouldShowAnimationBubble":true,"isAnimationBubbleActive":false,"shouldShowSpecialTile":true,"shouldShowWhatsNextBubble":true,"isWhatsNextBubbleActive":false},"showPersonalization":null,"isNavigationTourDismissed":false,"isTopBarV3Enabled":null}	0	0
2	email_verified	false	0	0
\.


--
-- Data for Name: access_users_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_users_groups (user_id, group_id, realm) FROM stdin;
3	1	internal
\.


--
-- Data for Name: archive_names; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.archive_names (name_id, entry_name) FROM stdin;
\.


--
-- Data for Name: archive_paths; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.archive_paths (path_id, entry_path) FROM stdin;
\.


--
-- Data for Name: artifact_bundles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.artifact_bundles (id, name, version, status, date_created, date_distributed, signature, type, storing_repo, keep, source_service_id) FROM stdin;
\.


--
-- Data for Name: artifactory_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.artifactory_servers (server_id, start_time, context_url, membership_port, server_state, server_role, last_heartbeat, artifactory_version, artifactory_revision, artifactory_release, artifactory_running_mode, license_hash) FROM stdin;
3ef7c81c2124	1778535845433	0.0.0.0:8082/artifactory	0	RUNNING	STANDALONE	1778536415942	7.111.8	81108900	1167040800000	OSS	Artifactory OSS
\.


--
-- Data for Name: binaries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.binaries (sha1, md5, bin_length, sha256) FROM stdin;
\.


--
-- Data for Name: binaries_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.binaries_tasks (id, sha1, "time", local_repo_key, remote_url_hash, start_time, count, server_id) FROM stdin;
\.


--
-- Data for Name: binary_blobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.binary_blobs (sha1, data) FROM stdin;
\.


--
-- Data for Name: build_artifacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_artifacts (artifact_id, module_id, artifact_name, artifact_type, sha1, md5) FROM stdin;
\.


--
-- Data for Name: build_dependencies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_dependencies (dependency_id, module_id, dependency_name_id, dependency_scopes, dependency_type, sha1, md5) FROM stdin;
\.


--
-- Data for Name: build_modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_modules (module_id, build_id, module_name_id, type) FROM stdin;
\.


--
-- Data for Name: build_promotions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_promotions (build_id, created, created_by, status, repo, promotion_comment, ci_user) FROM stdin;
\.


--
-- Data for Name: build_props; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_props (prop_id, build_id, prop_key, prop_value) FROM stdin;
\.


--
-- Data for Name: build_release_bundles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.build_release_bundles (build_rb_id, build_id, bundle_repository, bundle_name, bundle_version) FROM stdin;
\.


--
-- Data for Name: builds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.builds (build_id, build_name, build_number, build_date, ci_url, created, created_by, modified, modified_by, repo, immutable) FROM stdin;
\.


--
-- Data for Name: bundle_blobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bundle_blobs (id, data, bundle_id) FROM stdin;
\.


--
-- Data for Name: bundle_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bundle_files (id, node_id, bundle_id, repo_path, original_component_details) FROM stdin;
\.


--
-- Data for Name: cleanup_run_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cleanup_run_summary (policy_key, policy_run_id, dry_run, started_date, finished_date, status, type, temp_nodes_cleaned, deleted_packages_count, failed_packages_count, deleted_artifacts_count, failed_artifacts_count, original_binary_size, estimated_deleted_binary_size, triggered_by, total_binary_size, run_config) FROM stdin;
\.


--
-- Data for Name: config_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_history (id, config_data, repo_config_data, log_config_data) FROM stdin;
\.


--
-- Data for Name: config_schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_schema_version (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	0	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	artifactory	2026-05-11 18:43:56.386302	0	t
2	1.0	initial schema	SQL	V1_0__initial_schema.sql	-1574285132	artifactory	2026-05-11 18:43:56.498234	24	t
\.


--
-- Data for Name: configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configs (config_name, last_modified, data) FROM stdin;
artifactory/config/artifactory.system.properties	1778535775086	\\x230a230a232041727469666163746f727920697320612062696e6172696573207265706f7369746f7279206d616e616765722e0a2320436f70797269676874202843292032303139204a46726f67204c74642e0a230a232041727469666163746f7279206973206672656520736f6674776172653a20796f752063616e2072656469737472696275746520697420616e642f6f72206d6f646966790a2320697420756e64657220746865207465726d73206f662074686520474e552041666665726f2047656e6572616c205075626c6963204c6963656e7365206173207075626c69736865642062790a2320746865204672656520536f66747761726520466f756e646174696f6e2c206569746865722076657273696f6e2033206f6620746865204c6963656e73652c206f720a23202028617420796f7572206f7074696f6e2920616e79206c617465722076657273696f6e2e0a230a232041727469666163746f727920697320646973747269627574656420696e2074686520686f706520746861742069742077696c6c2062652075736566756c2c0a232062757420574954484f555420414e592057415252414e54593b20776974686f7574206576656e2074686520696d706c6965642077617272616e7479206f660a23204d45524348414e544142494c495459206f72204649544e45535320464f52204120504152544943554c415220505552504f53452e2020536565207468650a2320474e552041666665726f2047656e6572616c205075626c6963204c6963656e736520666f72206d6f72652064657461696c732e0a230a2320596f752073686f756c642068617665207265636569766564206120636f7079206f662074686520474e552041666665726f2047656e6572616c205075626c6963204c6963656e73650a2320616c6f6e6720776974682041727469666163746f72792e20204966206e6f742c20736565203c687474703a2f2f7777772e676e752e6f72672f6c6963656e7365732f3e2e0a230a230a0a232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323230a23202055736520746869732066696c6520746f206f766572726964652073797374656d2d6c6576656c2070726f7065727469657320757365642062792061727469666163746f72792e2020202020230a23202041727469666163746f72792d73706563696669632070726f7065727469657320626567696e6e696e67207769746820746865202261727469666163746f72792e2220707265666978202020230a23202077696c6c2062652068616e646c656420696e7465726e616c6c792062792061727469666163746f7279202d20796f752073686f756c64206368616e6765207468656d206f6e6c7920696620230a232020796f75206b6e6f77207768617420796f752061726520646f696e672e2020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020230a232020416c6c206f746865722070726f706572746965732077696c6c206265636f6d65206e6f726d616c20286a766d2d77696465292073797374656d2070726f706572746965732c20736f202020230a232020746869732066696c652063616e206265207573656420617320616e20616c7465726e617469766520666f722073706563696679696e6720636f6d6d616e642d6c696e65202020202020202020230a2320202d44706172616d3d76616c20706172616d65746572732e20202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020230a232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323232323230a0a232320436f6d6d6120736570617261746564206c697374206f662064697361626c6564206164646f6e730a2361727469666163746f72792e6164646f6e732e64697361626c65643d0a0a2323204e616d65206f6620616c7465726e617465206170706c69636174696f6e20636f6e7465787420636c61737320746f207573650a2361727469666163746f72792e6170706c69636174696f6e436f6e74657874436c6173733d6e756c6c0a0a2320456e61626c6520616464696e67207468652073657373696f6e20696420746f207468652055524c0a2361727469666163746f72792e736572766c65742e737570706f727455726c53657373696f6e547261636b696e673d66616c73650a0a232320496e646963617465732077686574686572206120646966666572656e7420696e7374616e6365206f662041727469666163746f72792063616e20726571756573742072656d6f7465206172746966616374732066726f6d207468697320696e7374616e63650a2361727469666163746f72792e61727469666163746f72795265717565737473546f476c6f62616c43616e526574726965766552656d6f74654172746966616374733d66616c73650a0a23232044697361626c652074686520646f776e6c6f61642061636365737320746f2074686520676c6f62616c20277265706f270a61727469666163746f72792e7265706f2e676c6f62616c2e64697361626c65643d747275650a0a2323204e756d626572206f66207365636f6e647320666f72206673206974656d7320746f2069646c6520696e207468652063616368650a2361727469666163746f72792e66736974656d2e63616368652e69646c6554696d65536563733d313230300a0a2323204e756d626572206f66207365636f6e647320746f2077616974206265747765656e2072756e6e696e67207468652073746f72616765206761726261676520636f6c6c6563746f722e205573652074686520554920746f20636f6e6669677572652061732063726f6e206578700a2361727469666163746f72792e67632e696e74657276616c536563733d31343430300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746865206761726261676520636f6c6c6563746f722073686f756c642077616974206265747765656e20746865207363616e6e696e67206f662065616368206e6f64650a2361727469666163746f72792e67632e736c6565704265747765656e4e6f6465734d696c6c69733d32300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f2077616974206265666f7265207374617274696e6720746f20736c656570206265747765656e206761726261676520636f6c6c6563746f72206e6f6465207363616e6e696e6720697465726174696f6e730a2361727469666163746f72792e67632e7363616e5374617274536c656570696e675468726573686f6c644d696c6c69733d32303030300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f20736c656570206265747765656e206761726261676520636f6c6c6563746f72206e6f6465207363616e6e696e6720697465726174696f6e730a2361727469666163746f72792e67632e7363616e536c6565704265747765656e497465726174696f6e734d696c6c69733d3230300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f20776f726b206265747765656e206761726261676520636f6c6c6563746f72206461746173746f72652066696c65207363616e6e696e6720736c65657020696e766f636174696f6e730a2361727469666163746f72792e67632e66696c655363616e536c656570497465726174696f6e4d696c6c69733d313030300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f20736c65657020647572696e67206c656e67746879206761726261676520636f6c6c6563746f72206461746173746f72652066696c65207363616e6e696e670a2361727469666163746f72792e67632e66696c655363616e536c6565704d696c6c69733d3235300a0a232320546865206d6178696d756d2062696e617279207265636f726420636163686520656e74726965732e2041706c6c696361626c65206f6e6c7920666f722076322067630a2361727469666163746f72792e67632e6d61784361636865456e74726965733d31303030300a0a2323204e756d626572206f66207365636f6e647320746f207761697420756e74696c2074696d696e67206f7574207768696c652077616974696e6720666f7220616e206974656d206c6f636b20746f2062652061637175697265640a2361727469666163746f72792e6c6f636b732e74696d656f7574536563733d3132300a0a2323205768657468657220746f207072696e742064657461696c656420646562756720696e666f726d6174696f6e206f6e206c6f636b2074696d656f7574730a2361727469666163746f72792e6c6f636b732e646562756754696d656f7574733d66616c73650a0a2323204e756d626572206f66207365636f6e647320746f2077616974206265747765656e20656163682072656672657368206f66207468652073797374656d206c6f6773207669657765720a2361727469666163746f72792e6c6f67732e766965775265667265736852617465536563733d31300a0a232320546865206d6178696d756d206e756d626572206f66207365636f6e647320746f2077616974207768656e20626c6f636b696e67206f6e206120636f6e63757272656e7420646f776e6c6f61642066726f6d207468652073616d65207265706f7369746f72792c206265666f72650a2323207374617274696e67206120706172616c6c656c20646f776e6c6f61640a232061727469666163746f72792e7265706f2e636f6e63757272656e74446f776e6c6f616453796e6354696d656f7574536563733d3930300a0a232320496e6469636174657320696620616c6c2073746f7265642061726368697665732073686f756c6420626520696e646578656420286576656e20696620616c726561647920646f6e65292075706f6e2073797374656d20737461727475700a2361727469666163746f72792e7365617263682e636f6e74656e742e666f72636541726368697665496e646578696e673d66616c73650a0a2323204d6178696d756d206e756d626572206f66206578636572707420667261676d656e747320746f2072657475726e20666f72206561636820726573756c74207768656e20736561726368696e67206172636869766520636f6e74656e74207468726f756768207468652055490a2361727469666163746f72792e7365617263682e636f6e74656e742e6d6178467261676d656e74733d3530300a0a2323204d6178696d756d206e756d626572206f66206368617261637465727320666f72206561636820667261676d656e740a2361727469666163746f72792e7365617263682e636f6e74656e742e6d6178467261676d656e747353697a653d353030300a0a2323204d6178696d756d206e756d626572206f6620726573756c747320746f2072657475726e207768656e20736561726368696e67207468726f756768207468652055490a2361727469666163746f72792e7365617263682e6d6178526573756c74733d3530300a0a232320546865206261636b656e64206c696d6974206f66206d6178696d756d20726573756c747320746f2072657475726e2066726f6d2073716c2071756572696573206973737565642062792075736572732e2053686f756c6420626520686967686572207468616e206d6178526573756c74732e0a2361727469666163746f72792e7365617263682e7573657251756572794c696d69743d313030300a0a232320546865206d696e696d756d206e756d626572206f66206368617261637465727320616c6c6f77656420666f7220616e206172636869766520636f6e74656e742071756572792e0a2361727469666163746f72792e7365617263682e617263686976652e6d696e51756572794c656e6774683d330a0a232320546865206d6178696d756d206e756d626572206f66207365636f6e647320746861742073686f756c64206265207370656e74206f6e2061207061747465726e207365617263680a2361727469666163746f72792e7365617263682e7061747465726e2e74696d656f7574536563733d33300a0a2323204e756d626572206f66207365636f6e647320666f722061757468656e7469636174696f6e7320746f2069646c6520696e207468652063616368650a2361727469666163746f72792e73656375726974792e61757468656e7469636174696f6e2e63616368652e69646c6554696d65536563733d3330300a0a2323204d696e696d616c206e756d626572206f66207365636f6e647320746861742073686f756c642062652074686520646966666572656e6365206265747765656e20656163682075736572206c617374206163636573732074696d657374616d70200a2361727469666163746f72792e73656375726974792e757365724c617374416363657373557064617465735265736f6c7574696f6e536563733d36300a0a2323204966204c6f67696e2052656d656d626572204d652073686f756c642062652064697361626c656420616e642075736572732077696c6c206861766520746f20696e7075742074686569722063726564656e7469616c73206f6e2065616368206c6f67696e2e0a2361727469666163746f72792e73656375726974792e64697361626c6552656d656d6265724d653d66616c73650a0a2323204c6966657370616e206f66207468652072656d656d626572206d6520636f6f6b69650a2361727469666163746f72792e73656375726974792e72656d656d6265724d652e6c69666574696d65536563733d313230393630300a0a23232043616368657320626c6f636b6564207573657220696e2073616b65206f6620706572666f726d616e636520696d70726f76656d656e740a232320616e642074616b6573206c6f6164206f66662061757468656e7469636174696f6e206d656368616e69736d2f64620a2361727469666163746f72792e73656375726974792e75736546726f6e744361636865466f72426c6f636b656455736572733d747275650a0a2323204c6f67696e2064796e616d6963616c6c7920626c6f636b656420666f7220696e6372656173696e6720616d6f756e74206f662074696d650a23232073696e636520746869726420696e636f7272656374206c6f67696e2c20616c676f726974686d2069733a0a23232028494e434f52524543545f415454454d5054532d3329202a206c6f67696e426c6f636b44656c617920286d696c6c6973290a23230a2323206e6f74653a2064656c6179206d6179206e6f74206578636565642035303030202835207365636f6e6473290a23230a2361727469666163746f72792e73656375726974792e6c6f67696e426c6f636b44656c61793d3530300a0a2323205061746820746f20616c7465726e61746520537072696e6720636f6e66696775726174696f6e2066696c650a2361727469666163746f72792e737072696e672e636f6e6669674469723d6e756c6c0a0a2323204e756d626572206f66206c6f636b2074696d656f75747320746f207265747279207768696c652077616974696e6720666f722061207461736b20746f20636f6d706c6574650a2361727469666163746f72792e7461736b2e636f6d706c6574696f6e4c6f636b54696d656f7574526574726965733d3130300a0a23232057686574686572206c6f6767696e6720616e642070726f63657373696e67206f6620747261666669632069732061637469766520200a2361727469666163746f72792e747261666669632e636f6c6c656374696f6e4163746976653d66616c73650a0a2323204e756d626572206f66207365636f6e647320746f2077616974206265747765656e20656163682076657273696f6e20696e666f726d6174696f6e207570646174652071756572790a2361727469666163746f72792e76657273696f6e696e675175657279496e74657276616c536563733d34333230300a0a23232054686520737562737472696e6720627920776869636820612072656d6f746520686f7374206973206964656e746966696564206173204d6176656e2727732063656e7472616c20686f73740a2361727469666163746f72792e6d766e2e63656e7472616c2e686f73745061747465726e3d2e6d6176656e2e6f72670a0a232320546865206d6178696d756d206672657175656e637920696e207365636f6e6473207468617420612072656d6f746520696e646578206f6e204d6176656e2063656e7472616c20686f73742063616e206265207175657269656420666f7220757064617465730a2361727469666163746f72792e6d766e2e63656e7472616c2e696e64657865724d61785175657279496e74657276616c536563733d38363430300a2323204d6178696d756d20636f6e63757272656e7420776f726b65727320746f2063616c63756c617465206d6176656e206d657461646174610a2361727469666163746f72792e6d766e2e6d657461646174612e63616c63756c6174696f6e2e776f726b6572733d380a0a23232046756c6c79207175616c6966696564206e616d65206f662061206d6176656e206d657461646174612076657273696f6e20636f6d70617261746f7220746f2064657465726d696e6520746865206c617465737420616e642072656c656173652076657273696f6e730a2361727469666163746f72792e6d766e2e6d6574616461746156657273696f6e73436f6d70617261746f7246716e3d6f72672e61727469666163746f72792e6d6176656e2e76657273696f6e696e672e56657273696f6e4e616d654d6176656e4d6574616461746156657273696f6e436f6d70617261746f720a0a23232046756c6c79207175616c6966696564206e616d65206f662061206d6176656e206d657461646174612074696d657374616d7020636f6d70617261746f7220746f2064657465726d696e6520746865206c617465737420736e617073686f742076657273696f6e730a2361727469666163746f72792e6d766e2e6d65746164617461536e617073686f74436f6d70617261746f7246716e3d6f72672e61727469666163746f72792e6d6176656e2e736e617073686f742e54696d657374616d70536e617073686f74436f6d70617261746f720a0a23232044697361626c6520726571756573747320776974682076657273696f6e20746f6b656e732028534e415053484f542c205b52454c454153455d2c205b494e544547524154494f4e5d2077686963682072657472696576657320746865206c617465737420756e69717565206966206578697374730a2361727469666163746f72792e726571756573742e64697361626c6556657273696f6e546f6b656e733d66616c73650a0a23232044657465726d696e652069662073686f756c6420736f727420616e6420726574726965766520746865206c6174657374205b52454c454153455d2076657273696f6e2062792066696c657320646174652063726561746564202864656661756c742069732062792076657273696f6e20737472696e6720636f6d70617261746f72290a2361727469666163746f72792e726571756573742e7365617263684c617465737452656c65617365427944617465437265617465643d66616c73650a0a232320416464206164646974696f6e616c20786d6c206d696d6520747970652066696c6520657874656e73696f6e7320282a2e6d79657874656e73696f6e292e2053657061726174656420627920222c220a2361727469666163746f72792e786d6c4164646974696f6e616c4d696d6554797065457874656e73696f6e733d6d79657874656e73696f6e312c6d79657874656e73696f6e320a0a2323204d6178206e756d626572206f6620666f6c6465727320746f207363616e20646565706c7920666f72206974656d732075736564206173206275696c64206172746966616374206f7220646570656e64656e63696573206265666f72652064656c6574696e6720746f207761726e206f660a2361727469666163746f72792e6275696c642e6d6178466f6c64657273546f5363616e466f7244656c6574696f6e5761726e696e67733d320a0a23232053697a6520666f722074686520646572627920706167652063616368650a64657262792e73746f726167652e70616765436163686553697a653d3530300a0a23232044697361626c6520746865204465726279204a4d58206d616e6167656d656e7420736572766963650a64657262792e6d6f64756c652e6d676d742e6a6d783d6f72672e6170616368652e64657262792e696d706c2e73657276696365732e6a6d786e6f6e652e4e6f4d616e6167656d656e74536572766963650a0a2323204c6f6720616c6c206572726f72732f6d65737361676573206578636570742073796e746178206572726f727320616e6420636f6e73747261696e742076696f6c6174696f6e730a64657262792e73747265616d2e6572726f722e6c6f6753657665726974794c6576656c3d34303030300a0a2323204c6f6720616c6c2065786563757465642073746174656d656e747320616c6f6e67207769746820746865697220747869640a64657262792e6c616e67756167652e6c6f6753746174656d656e74546578743d66616c73650a0a2323204c6f6720616c6c20646561646c6f636b730a2364657262792e6c6f636b732e6d6f6e69746f723d747275650a0a232320577269746573206120737461636b207472616365206f6620616c6c207468726561647320696e766f6c76656420696e206c6f636b2070726f626c656d732023202d2d20286e6f74206a757374207468652076696374696d732920746f20746865206c6f670a2364657262792e6c6f636b732e646561646c6f636b54726163653d747275650a0a2323205468726573686f6c6420666f7220746865206e756d62657220726f777320746f75636865642061626f766520776869636820746f206175746f2d657363616c61746520746f207461626c652d6c6576656c206c6f636b696e672066726f6d20726f772d6c6576656c206c6f636b696e670a2364657262792e6c6f636b732e657363616c6174696f6e5468726573686f6c643d353030300a0a232320446566696e657320746865206d6178696d756d2073697a65206f66207465787420746f207061727365207468726f75676820746865207465787420686967686c69676874696e67207363726970740a2361727469666163746f72792e75692e73796e746178436f6c6f72696e674d61785465787453697a6542797465733d3531323030300a0a232320446566696e6573207468652064656661756c74206368726f6f7420666f722055492066696c655c6469722073656c6563746f727320746861742062726f777365206d616368696e652041727469666163746f72792077617320696e7374616c6c6564206f6e0a2361727469666163746f72792e75692e6368726f6f743d2f686f6d652f626f620a0a232320446566696e657320746865206d6178696d756d206e756d626572206f662066696c657320746f2072657461696e207768656e206d61696e7461696e696e67206120726f6c6c696e672066696c6520706f6c6963790a2361727469666163746f72792e66696c652e726f6c6c65722e6d617846696c65546f52657461696e3d31300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f20776f726b206265747765656e2073797374656d206261636b75702066696c65206578706f727420736c65657020696e766f636174696f6e730a2361727469666163746f72792e6261636b75702e66696c654578706f7274536c656570497465726174696f6e4d696c6c69733d323030300a0a2323204e756d626572206f66206d696c6c697365636f6e647320746f20736c65657020647572696e67206c656e677468792073797374656d206261636b75702066696c65206578706f7274730a2361727469666163746f72792e6261636b75702e66696c654578706f7274536c6565704d696c6c69733d3235300a0a2323204e756d626572206f66207365636f6e647320746f20636865636b20666f722075706461746573206f6620706c7567696e207363726970742066696c6573202830202d20646f206e6f74207265667265736820757064617465732073637269707473290a2361727469666163746f72792e706c7567696e2e736372697074732e72656672657368496e74657276616c536563733d300a0a23232053656e6420746865204163636570742d456e636f64696e673a677a69702068656164657220746f2072656d6f7465207265706f7369746f7269657320616e642068616e646c6520677a69702073747265616d20726573706f6e7365730a2361727469666163746f72792e687474702e616363657074456e636f64696e672e677a69703d747275650a0a2320757365207468652045787065637420636f6e74696e7565206469726563746976650a2361727469666163746f72792e687474702e757365457870656374436f6e74696e75653d66616c73650a0a2320546865206c6f7765722d6c696d6974206f6620612066696c7465726564207265736f757263652073697a6520666f72207768696368206120706572666f726d616e6365207761726e696e672077696c6c20626520646973706c617965640a2366696c746572696e672e7265736f7572636553697a654b623d36340a0a23205768657468657220746f2073656172636820666f7220616e20616e206578697374696e67207265736f7572636520756e646572206120646966666572656e74206e616d65206265666f72652072657175657374696e6720612072656d6f74652061727469666163740a2361727469666163746f72792e7265706f2e72656d6f74652e636865636b466f724578697374696e675265736f757263654f6e526571756573743d747275650a0a2320436f6d6d6120736570617261746564206c697374206f6620676c6f62616c206578636c7564657320746f206170706c79206f6e20616c6c207265706f7369746f726965730a2361727469666163746f72792e7265706f2e696e636c7564654578636c7564652e676c6f62616c4578636c756465733d2a2a2f2a7e2c2a2a2f232a232c2a2a2f2e232a2c2a2a2f252a252c2a2a2f2e5f2a2c2a2a2f4356532c2a2a2f4356532f2a2a2c2a2a2f2e63767369676e6f72652c2a2a2f534343532c2a2a2f534343532f2a2a2c2a2a2f7673737665722e7363632c2a2a2f2e73766e2c2a2a2f2e73766e2f2a2a2c2a2a2f2e44535f53746f72650a0a23232041206c697374206f6620617263686976652066696c65206e616d65732074686174206d617920636f6e7461696e207465787475616c206c6963656e736520696e666f726d6174696f6e2e5c0a2361727469666163746f72792e617263686976652e6c6963656e736546696c652e6e616d65733d6c6963656e73652c4c4943454e53452c6c6963656e73652e7478742c4c4943454e53452e7478742c4c4943454e53452e5458540a0a2323204e756d626572206f66207365636f6e647320666f722064796e616d6963206d6574616461746120746f206265206361636865640a2361727469666163746f72792e6d766e2e64796e616d69634d657461646174612e6361636865526574656e74696f6e536563733d31300a0a23232041206c697374206f6620637573746f6d2074797065732028637573746f6d2066696c6520657874656e73696f6e732920746f20757365207768656e207265736f6c76696e67206d6176656e206172746966616374730a2361727469666163746f72792e6d766e2e637573746f6d2e74797065733d7461722e677a2c7461722e627a320a0a23232044657465726d696e657320746865206d6178696d756d206e756d626572206f6620726f777320746f20646973706c61792070657220726573756c7420706167650a2361727469666163746f72792e75692e7365617263682e6d6178526f7773506572506167653d32300a0a2323204d6178696d756d206e756d626572206f6620726573756c747320746f2072657475726e207768656e20706572666f726d696e67204e7547657420736561726368657320776974686f75742073706563696679696e672061206c696d69740a2361727469666163746f72792e6e756765742e7365617263682e6d6178526573756c74733d3130300a0a232320496620747275652c20616c6c20726571756573747320746f20746865204e754765742041504920726571756972652061757468656e7469636174696f6e206576656e20696620616e6f6e796d6f75732061636365737320697320656e61626c65642e0a2361727469666163746f72792e6e756765742e666f72636541757468656e7469636174696f6e3d66616c73650a0a23232044697361626c652066696c656e616d6520746f6b656e20696e20726573706f6e736520436f6e74656e742d446973706f736974696f6e206865616465720a2361727469666163746f72792e726573706f6e73652e64697361626c65436f6e74656e74446973706f736974696f6e46696c656e616d653d66616c73650a0a232320436f6d6d6120736570617261746564206c697374206f6620737570706f72746564206172636869766520657874656e73696f6e7320666f7220617263686976652062756e646c6564206465706c6f790a2361727469666163746f72792e726571756573742e6578706c6f64656441726368697665457874656e73696f6e733d7a69702c7461722c7461722e677a2c74677a0a0a23232044697361626c65205c20656e61626c652074686520757365726e616d65206175746f20636f6d706c65746520696e20746865206c6f67696e207061676520202876616c756573203a20226f66662220226f6e22292e0a2361727469666163746f72792e757365557365724e616d654175746f436f6d706c6574654f6e4c6f67696e3d6f6e0a0a23232054686520696e74657276616c2c20696e207365636f6e64732c20666f7220666c757368696e672061676772656761746564207374617469737469637320746f207468652073746f726167650a2361727469666163746f72792e73746174732e666c757368496e74657276616c536563733d33300a0a23232054686520616d6f756e74206f6620696e646963657320746f2070726520666574636820627920496447656e657261746f720a2361727469666163746f72792e64622e696447656e657261746f722e66657463682e616d6f756e743d313030300a0a2323205768656e207365742c207468652042696e747261792053657474696e67732073656374696f6e20696e2074686520557365722050726f66696c65207061676520696e207468652055492077696c6c2062652068696464656e2e0a2361727469666163746f72792e62696e747261792e75692e6869646555706c6f6164733d747275650a0a23232048696465732074686520656e637279707465642070617373776f7264206669656c6420616e6420746865206d6176656e2073657474696e677320736e69707065742066726f6d207468652070726f66696c6520706167650a2361727469666163746f72792e75692e68696465456e6372797074656450617373776f72643d747275650a0a232320486964657320636865636b73756d2066696c657320696e2073696d706c6520616e64206c6973742062726f7773696e670a2361727469666163746f72792e75692e68696465436865636b73756d733d747275650a0a2323204d6178696d756d206e756d626572207265706f7369746f7269657320746f20696d706f727420696e20706172616c6c656c202864656661756c74206973206f6e65206c657373207468616e2074686520617661696c61626c652070726f636573736f7273290a2361727469666163746f72792e696d706f72742e6d61782e706172616c6c656c5265706f730a0a23232049646c6520636f6e6e656374696f6e206d6f6e69746f7220696e74657276616c2028696e207365636f6e6473290a2361727469666163746f72792e7265706f2e687474702e69646c65436f6e6e656374696f6e4d6f6e69746f72496e74657276616c3d31300a0a23232044697361626c65732069646c65204854545020636f6e6e656374696f6e73206d6f6e69746f72696e67202869646c6520636f6e6e656374696f6e732061726520636c6f736564206175746f6d61746963616c6c79207768656e202369646c65436f6e6e656374696f6e4d6f6e69746f72496e74657276616c2065787069726573290a2361727469666163746f72792e7265706f2e687474702e64697361626c6549646c65436f6e6e656374696f6e4d6f6e69746f72696e673d66616c73650a0a23232054696d6520746f207761697420666f7220636f6e74656e7420636f6c6c656374696f6e206163636f6d706c697368696e672028696e206d696e75746573290a2361727469666163746f72792e737570706f72742e636f72652e62756e646c652e636f6e74656e74436f6c6c656374696f6e417761697454696d656f75743d36300a0a23232041727469666163746f72792062792064656661756c7420626c6f636b7320636f6e63757272656e7420657865637574696f6e206f6620537570706f727420636f6e74656e7420636f6c6c656374696f6e2c0a232320686f7765766572206f6e652063616e20636f6e6669677572652074696d6520746f207761697420666f72206e65787420617661696c61626c6520657865637574696f6e20736c6f74206265666f72650a23232077697468647261772028696e207365636f6e6473290a2361727469666163746f72792e737570706f72742e636f72652e62756e646c652e77616974466f72536c6f744265666f726557697468647261773d3630300a0a2323204d6178202870726576696f75736c792063726561746564292062756e646c657320746f206b6565700a2361727469666163746f72792e737570706f72742e636f72652e62756e646c652e6d617842756e646c65733d350a0a232320546865206c6174657374206465706c6f796564206e706d207061636b6167652077696c6c2062652074616720776974682074686520276c617465737427207461670a2361727469666163746f72792e6e706d2e7461672e7461674c617465737442795075626c6973683d747275650a0a232320416464207061636b616765204d443520636865636b73756d20746f2044656269616e205061636b616765732066696c650a2361727469666163746f72792e64656269616e2e6d657461646174612e63616c63756c6174654d6435496e5061636b6167657346696c65733d747275650a0a23232057686974656c697374206c6f6f706261636b2070726566697865732055524c20617320612072656d6f7465207265706f7369746f72792055524c2028652e672e206c6f63616c686f7374292073657061726174656420627920272c272e2064656661756c7420616c6c206c6f6f706261636b2055524c732061726520626c6f636b65640a2361727469666163746f72792e72656d6f74652e7265706f2e75726c2e77686974656c6973742e7072656669783d6e756c6c0a0a232320426c6f636b20616e7920736974652f6c696e6b206c6f63616c202831302f387c3137322e31362f31327c3139322e3136382f31367c3136392e3235342f31362070726566697829206f7220756e7265736f6c7661626c652055524c20617320612072656d6f7465207265706f7369746f72792055524c202864656661756c743a2066616c7365290a2361727469666163746f72792e72656d6f74652e7265706f2e75726c2e7374726963742e706f6c6963793d66616c73650a0a232320517569636b20736561726368206f6620617274696661637473207573696e6720554920636173652073656e736974697669747920696e64696361746f720a2375692e7365617263682e6172746966616374732e63617365496e73656e7369746976653d747275650a0a232320456e61626c652f44697361626c652073797374656d20696d706f72742e20456e61626c65642062792064656661756c742e0a2361727469666163746f72792e73797374656d2e696d706f72742e656e61626c65643d747275650a232320456e61626c652f44697361626c65207265706f7369746f727920696d706f72742e20456e61626c65642062792064656661756c742e0a2361727469666163746f72792e7265706f7369746f72792e696d706f72742e656e61626c65643d747275650a
artifactory/config/mimetypes.xml	1778535775089	\\x3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d38223f3e0a3c212d2d0a20207e2041727469666163746f727920697320612062696e6172696573207265706f7369746f7279206d616e616765722e0a20207e20436f70797269676874202843292032303139204a46726f67204c74642e0a20207e0a20207e2041727469666163746f7279206973206672656520736f6674776172653a20796f752063616e2072656469737472696275746520697420616e642f6f72206d6f646966790a20207e20697420756e64657220746865207465726d73206f662074686520474e552041666665726f2047656e6572616c205075626c6963204c6963656e7365206173207075626c69736865642062790a20207e20746865204672656520536f66747761726520466f756e646174696f6e2c206569746865722076657273696f6e2033206f6620746865204c6963656e73652c206f720a20207e2028617420796f7572206f7074696f6e2920616e79206c617465722076657273696f6e2e0a20207e0a20207e2041727469666163746f727920697320646973747269627574656420696e2074686520686f706520746861742069742077696c6c2062652075736566756c2c0a20207e2062757420574954484f555420414e592057415252414e54593b20776974686f7574206576656e2074686520696d706c6965642077617272616e7479206f660a20207e204d45524348414e544142494c495459206f72204649544e45535320464f52204120504152544943554c415220505552504f53452e2020536565207468650a20207e20474e552041666665726f2047656e6572616c205075626c6963204c6963656e736520666f72206d6f72652064657461696c732e0a20207e0a20207e20596f752073686f756c642068617665207265636569766564206120636f7079206f662074686520474e552041666665726f2047656e6572616c205075626c6963204c6963656e73650a20207e20616c6f6e6720776974682041727469666163746f72792e20204966206e6f742c20736565203c687474703a2f2f7777772e676e752e6f72672f6c6963656e7365732f3e2e0a20202d2d3e0a3c212d2d0a20202020546869732066696c6520636f6e666967757265732041727469666163746f72792773206b6e6f776e206d696d652074797065732e2041206c697374206f6620726567697374657265640a202020206d656469612074797065732063616e20626520666f756e6420696e20687474703a2f2f7777772e69616e612e6f72672f61737369676e6d656e74732f6d656469612d74797065732f20616e6420636f6d6d6f6e206f6e657320696e0a20202020687474703a2f2f7777772e7765626d61737465722d746f6f6c6b69742e636f6d2f6d696d652d74797065732e7368746d6c0a2020202045616368206d696d652074797065206d617920686176652074686520666f6c6c6f77696e6720617474726962757465733a0a202020202020202074797065202d20546865206d696d6520656e74727920756e69717565206e616d6520286d616e6461746f7279290a2020202020202020657874656e73696f6e73202d20436f6d6d6120736570617261746564206c697374206f662066696c6520657874656e73696f6e73206d617070656420746f2074686973206d696d65207479706520286d616e6461746f7279290a2020202020202020696e646578202d20547275652069662074686973206d696d6520747970652073686f756c6420626520696e646578656420666f7220736561726368696e67202876616c6964206f6e6c7920666f7220737570706f7274656420617263686976652066696c6573290a202020202020202061726368697665202d20547275652069662074686973206d696d65207479706520697320612062726f777361626c6520617263686976650a20202020202020207669657761626c65202d20547275652069662074686973206d696d6520747970652063616e2062652076696577656420617320746578742066696c650a202020202020202073796e746178202d2054686520554920686967686c6967687465722073796e74617820746f20666f722074686973206d696d65207479706520286f6e6c792072656c6576616e7420696620746869732069732061207669657761626c652074797065290a2020202020202020637373202d205468652063737320636c617373206f66206120646973706c61792069636f6e20666f722074686973206d696d6520747970650a2d2d3e0a3c6d696d6574797065732076657273696f6e3d223135223e0a0a202020203c6d696d657479706520747970653d22746578742f706c61696e2220657874656e73696f6e733d227478742c2070726f706572746965732c206d662c206173632c206c6f672c20796d6c2c2079616d6c2c20746622207669657761626c653d2274727565220a202020202020202020202020202073796e7461783d22706c61696e222f3e0a202020203c6d696d657479706520747970653d22746578742f68746d6c2220657874656e73696f6e733d2268746d2c2068746d6c22207669657761626c653d2274727565222073796e7461783d22786d6c222f3e0a202020203c6d696d657479706520747970653d22746578742f6373732220657874656e73696f6e733d2263737322207669657761626c653d2274727565222073796e7461783d22637373222f3e0a202020203c6d696d657479706520747970653d22746578742f78736c2220657874656e73696f6e733d2278736c22207669657761626c653d2274727565222073796e7461783d22786d6c222f3e0a202020203c6d696d657479706520747970653d22746578742f78736c742220657874656e73696f6e733d2278736c7422207669657761626c653d2274727565222073796e7461783d22786d6c222f3e0a202020203c6d696d657479706520747970653d22746578742f782d6a6176612d736f757263652220657874656e73696f6e733d226a61766122207669657761626c653d2274727565222073796e7461783d226a617661222f3e0a202020203c6d696d657479706520747970653d22746578742f782d6a61766166782d736f757263652220657874656e73696f6e733d22667822207669657761626c653d2274727565222073796e7461783d226a6176616678222f3e0a202020203c6d696d657479706520747970653d22746578742f782d67726f6f76792d736f757263652220657874656e73696f6e733d2267726f6f76792c20677261646c6522207669657761626c653d2274727565222073796e7461783d2267726f6f7679222f3e0a202020203c6d696d657479706520747970653d22746578742f782d632220657874656e73696f6e733d22682c20632c2063632c2063707022207669657761626c653d2274727565222073796e7461783d22637070222f3e0a0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f786d6c2d6474642220657874656e73696f6e733d2264746422207669657761626c653d2274727565222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f786d6c2d736368656d612220657874656e73696f6e733d2278736422207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d22786d6c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f786d6c2d65787465726e616c2d7061727365642d656e746974792220657874656e73696f6e733d22656e7422207669657761626c653d2274727565222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f7868746d6c2b786d6c2220657874656e73696f6e733d227868746d6c22207669657761626c653d2274727565222073796e7461783d22786d6c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f6a736f6e2220657874656e73696f6e733d226a736f6e22207669657761626c653d2274727565222073796e7461783d226a617661736372697074222f3e0a202020203c6d696d657479706520747970653d22746578742f782d707974686f6e2220657874656e73696f6e733d22707922207669657761626c653d2274727565222073796e7461783d22707974686f6e22206373733d22707974686f6e222f3e0a0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6a6176612d7061636b3230302220657874656e73696f6e733d226a61722e7061636b2e677a2220617263686976653d22747275652220696e6465783d227472756522206373733d226a6172222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6a6176612d617263686976652d646966662220657874656e73696f6e733d226a6172646966662220617263686976653d2266616c7365222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f7a69702220657874656e73696f6e733d227a69702220617263686976653d22747275652220696e6465783d227472756522206373733d226a6172222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d7461722220657874656e73696f6e733d227461722220617263686976653d22747275652220696e6465783d2266616c7365222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d677a69702220657874656e73696f6e733d2274677a2c207461722e677a2c20677a2220617263686976653d22747275652220696e6465783d2266616c7365222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d627a6970322220657874656e73696f6e733d22627a322c207461722e627a322220617263686976653d22747275652220696e6465783d2266616c7365222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d377a2d636f6d707265737365642220657874656e73696f6e733d22377a2220617263686976653d22747275652220696e6465783d2266616c7365222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6e75706b672220657874656e73696f6e733d226e75706b672220617263686976653d22747275652220696e6465783d227472756522206373733d226e75706b67222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d636f6e64612220657874656e73696f6e733d22636f6e64612220617263686976653d22747275652220696e6465783d227472756522206373733d22636f6e6461222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d7261722d636f6d707265737365642220657874656e73696f6e733d227261722220617263686976653d2266616c736522206373733d226a6172222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f766e642e616e64726f69642e7061636b6167652d617263686976652220657874656e73696f6e733d2261706b2220617263686976653d22747275652220696e6465783d227472756522206373733d2261706b222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d72706d2220657874656e73696f6e733d2272706d22206373733d2272706d222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d7275627967656d732220657874656e73696f6e733d2267656d22206373733d2267656d222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d727562792d6d61727368616c2220657874656e73696f6e733d22727a22206373733d22727562792d6d61727368616c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d64656269616e2d7061636b6167652220657874656e73696f6e733d226465622c206464656222206373733d22646562222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d76616772616e742d626f782220657874656e73696f6e733d22626f7822206373733d22626f78222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f6a736f6e2b696e666f2220657874656e73696f6e733d22696e666f22207669657761626c653d2274727565222073796e7461783d226a736f6e222f3e0a202020203c6d696d657479706520747970653d22746578742f706c61696e2b6d6f642220657874656e73696f6e733d226d6f6422207669657761626c653d2274727565222073796e7461783d22706c61696e222f3e0a202020203c6d696d657479706520747970653d22746578742f782d7377696674202220657874656e73696f6e733d22737769667422207669657761626c653d2274727565222073796e7461783d22706c61696e2220696e6465783d2266616c7365222f3e0a0a202020203c212d2d206e6f742072656769737465726564202d2d3e0a202020203c6d696d657479706520747970653d22746578742f782d7363616c612d736f757263652220657874656e73696f6e733d227363616c6122207669657761626c653d2274727565222073796e7461783d227363616c61222f3e0a202020203c6d696d657479706520747970653d22746578742f782d727562792d736f757263652220657874656e73696f6e733d22726222207669657761626c653d2274727565222073796e7461783d2272756279222f3e0a202020203c6d696d657479706520747970653d22746578742f782d7363726970742e73682220657874656e73696f6e733d22736822207669657761626c653d2274727565222073796e7461783d227368656c6c222f3e0a202020203c6d696d657479706520747970653d22746578742f782d6373686172702e73682220657874656e73696f6e733d22637322207669657761626c653d2274727565222073796e7461783d22637368617270222f3e0a0a202020203c212d2d0a20202020202020204e4f54453a2054686520666f6c6c6f77696e67206d696d652074797065732061726520726571756972656420666f7220612070726f7065722066756e6374696f6e696e67206f66206365727461696e20666561747572657320696e2041727469666163746f7279200a202020202020202020444f204e4f54206368616e6765207468656d20756e6c65737320796f75207265616c6c79206b6e6f77207768617420796f752061726520646f696e670a202020202d2d3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f786d6c2220657874656e73696f6e733d22786d6c2c2078736c2c2078736922207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d22786d6c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6d6176656e2d706f6d2b786d6c2220657874656e73696f6e733d22706f6d22207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d22706f6d222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6976792b786d6c2220657874656e73696f6e733d2269767922207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d22786d6c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6e75737065632b786d6c2220657874656e73696f6e733d226e757370656322207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d22786d6c222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d6a6176612d6a6e6c702d66696c652220657874656e73696f6e733d226a6e6c7022207669657761626c653d2274727565222073796e7461783d22786d6c22206373733d226a6e6c70222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f782d636865636b73756d2220657874656e73696f6e733d22736861312c207368613235362c206d643522207669657761626c653d2274727565222073796e7461783d22706c61696e222f3e0a202020203c6d696d657479706520747970653d226170706c69636174696f6e2f6a6176612d617263686976652220657874656e73696f6e733d226a61722c207761722c206561722c207361722c206861722c206870692c206a70692220617263686976653d22747275652220696e6465783d2274727565220a20202020202020202020202020206373733d226a6172222f3e0a0a3c2f6d696d6574797065733e0a
artifactory/config/binarystore.xml	1778535775092	\\x4a453873734468646863796441533174357a796748466f325a596d61354550504a6141525958597335516232556437434e686f714c62554d455970694a42314b7a7348684152754e66386d47674659475242716f4c79704a56415742507932657954744e484e4a43774b4d76653353467843537939337655384e386f41507467533546686d41653176476a48686d4d54586a436f437937527755613556356f795077444d7561693271634151724a4379716f535a46734154686f3439416a545a504867735573714a41486b7a345a717a437973556f58755159387378616e74425174644c617a4e324d5a415845356e4a35366f33424b56485959797a763554384b46747a58665a436a6e646e43383264346f36747365445448537865376e777a37564c716d57414a546a676e655244635153775731546755456d414d433948744c75335577617065635639354b556d58355951573751584e793363616673426633354650653447616367515a7753596564523336617172394650504b5a54636f433844436174484d66646f51346165505258376939694e48644c3435426e4a74556763644c6254754574616f7a3632425234375a6b4146387258434a4c7048763439694d677a526159537238794371676977643248746f5a34795165457053514e4d57634e3177684a78455350785354626d38483666764334557774694c67374d39437869725266664c7041376535787643454c6e476736353864505758756d7059754e7644725559656d6d55504c4c50384c4d35786659504c37437661746157715541373973674d38764e3558664c7a78625a7255443372356f554a334661525a507154354b35417a714e365366704c616574434e6a69676f344362477832547356316b534c7145316a71543870316a446d5376714e78426b6b6a31785a576e4671713268445776707677537856763870434c73636448314772637065416b75667a744d7465767979365373434d3179634b74616a324a6d733933336a4c53574d36387859645846313661737357574769756e4542366e6374725939556a75464133474c7838424e63734c61754c47524c4736544536776a57443943767953636e784d4d7548776771644d686e546d535a74527838585438684e44346675587472316f425a336d79734b516a6a574567454862557772443963595a614b576e624c6e3957364e72434834367a4e63366f4e654b466b70437a53503861393259316d467a326b384d61744d6456574c486d46384d6b6a334a574a4c584276716a65464e344345567269487535344e377338796b48424272335461686f476b706135584b4b6f433957355258736b786d34744e5a4e55387838546e4b76713443634b76344c5151766e414d486d47476251517a7a386f6b6e4835346370424c50676f62723751687459584d73545565486a48325746506953425831717169323553316765676f6a7764576a68366b64785a565a64387663336d504633587551744a763974394c37475831385a5a54716e6368745052623266334e714643773766657a654a65714e7947704a4d794b424e4546364454336e65704e56324443334b554651694a3732573561754c4a4d5477486f486b5a4854517a6e687a6442575973794342654747437562553537586a6163464d5473574d34454a35726d5a6d4e56486878637537576b77636669574652414c4c55377271596133676b4d427468366e66566f317367784a394d554d57344e4d633953753675786676544a4d37453462706539314d4b6f4a566b58564e47643972776239353955746a6933636d624d51456e556b6a6f6a644450727334326d34785178415532423447665075795042614b7a616b61617a744371424a37336364355636517a477373694b4c6f784d6f545844704b5336796d4276486b766779704c5967475977556a68584e503435567431506459636d6d6470486768524e444e72716e4e4664486d337a37397548517a626256464b383244464d5735664243794a34687a353273596d443159386a6f6e326b6966663941334d424e4a41796f7477444572503637536b32526d7a626566364e63787337387543417732537335624b567a476d35507956507477504d69674672464271394675424b314b5647766a74784b7066384d4d7077784d6a4a706555424e457344597464583450574e706e6d5458463231504c34414e614a714839
artifactory.service_id	1778535805220	\\x6a6672744030316b726366786339336762626530663938746766663033366d
artifactory.security.url.signing.key	1778535844807	\\x4a45396544555153327578646d664b5a764c6b37756f6a624379474c4d4b79716f70323231713137446a6463354e6779427873384844316d75426f66594232597a4d6545554159744854587042364e4550567161666d416848376a4c54656d484c534269576f756d556e615770375a55784b6d5a7956783956506d3666516f58753658737757523236
artifactory/config/security/artifactory.key	1778535845686	\\x4a453963586d4661424c4a397132356d714d4550463839616f74514c3836447641526a3150664a58474a425046427759315251627935473955657a5333384e444736654c4e75466772395a4678783435586e46723978624a4e415767466652796f6d314163697a4e765174426f63795774506335473459484d44646245694b6b417345626557417973
storage.usage.json	1	\\x7b227265766973696f6e223a312c227265706f53746f7261676553756d223a7b226578616d706c652d7265706f2d6c6f63616c223a302c226175746f2d747261736863616e223a302c2261727469666163746f72792d6275696c642d696e666f223a307d2c2270726f6a6563747353746f7261676553756d223a7b2264656661756c74223a307d2c2270726f6a656374734c6173744e6f7469666965644f6e53746f7261676551756f7461223a7b7d7d
artifactory/config/security/access/access.admin.token	1778535829024	\\x4a45414c386d34433856437566445a653568616841483269546f51593661466e636f7939706145676978685469347645317447595739544c7a6d4b33364a5166774b674d42315947534d41654b42524637673964685a3655616250554847716d436739554379734778766d4136456434426b755a51594c796f705732783539556a44354b72344455673361414d7a446a397536727452623351584e765641783548576b576e3777316e7a7248584d725741765768656d596654313961627838484832574842487a34595a5342327a4e3870756e54377257587a475255684c5754676f386a4a313454794e4c4b31617a74766f796b51637551737376436e5437694d33724836354379516e46667a694372466a52684c6b6a64696f575435584d62565955776874376a6d6d3675587474613453707a56616231355465543342694e6f564d3877505036444473436371774e3741383966327a4e763768624750794258376f5a58346d4d66557259333736514d7855745a5a4c586f704556525a706646557778313568703445615169345236734c58557377616f3636774c31546a7135623241794d39436a4c547769527950713951763457577767506d676f573666794131724e6354437245476a6a6f4c4d75694e674d4453696735514559434c564d44446a6e4a676e3431764d434e614131734e5a507931545043377748477847667843356f474c444e586a5866676f7939474a324257596536627a6e6f50706944486d786f6f4535566d6d55793175686f574e686a554e6b6e746d354e446a5467534a38703778346f59476d6b543776634c68747a7151453355576a724d7235326e7555784c6d5774666a675a624e6f376e573842583357736a45486a5166745537557a6765584863716a54717456675a654637357534336e776b63456463326f6f396a35474e6b5a367037326e675975543331415177715262545862454c6538755a576b78364c6743334a6e524b37696d35504b42743674335565484654624536574e6647756f796246774b7270345957724276674239723148576f704c4e435957695a6b3565704252647951734a6f3348504576475654723653577065696e416e464136696f39536571573833586e63717554544454654a48477731375045666e396b6e38724b73564653574b594479516f58544879354637415453704c4c4a6262545275617963384e52533179364d673248364e414d76444d4d47474e32624358595739546255736d536576744a426955796238776b48694a69504741413266374e5a4c535644777a476d6b3950776d4245416e655472446d3266684e53316236346e57784b5556357654413668684d474d773861703457596d70733479744436647a775278546342747a3532515558763858454767787174387075694462664d4163385066634a5255643537535a6977547442457a7865624e54346e4474613177776b6776625848424a4c58576666744d724c3470706b746a6d5163616f4c6f6b585259684737384a6252333770357454565176657a6d5a586a78506b444d75313735566e79736b444543335856636e337552615248546369417055565073315a4e6552434a524e515671656e65594b714774664b597672344c72776d78336e59653861484a3854777854774178767774446f756b357371774365327169435a7576364574707938577739614a48396d4333615034566b4a356548364c3351467a503148593847397944683257775664386e4e624d694e4c6950793972357735514237427042616141446e70747741416e777a507965466b4d66724a6e5252436938737632483877584a6e50574452777441525851336831526d7a776172486a7235464444586a4c626662484c347439457572487437595458784a4532776177317559504645333350386e39626d6f336756537838473478646d6368597947616d786470346831713636724b6b4478504474775948754c3235627a6147646a6452333177
artifactory/config/artifactory.repository.config.latest.json	1778535845502	\\x7b226c6f63616c5265706f436f6e66696773223a5b7b2274797065223a226c6f63616c222c226b6579223a226578616d706c652d7265706f2d6c6f63616c222c227061636b61676554797065223a2267656e65726963222c2262617365436f6e666967223a7b226d6f64656c56657273696f6e223a322c226465736372697074696f6e223a224578616d706c652061727469666163746f7279207265706f7369746f7279222c227265706f4c61796f7574526566223a2273696d706c652d64656661756c74222c22696e636c756465735061747465726e223a222a2a2f2a227d2c227265706f54797065436f6e666967223a7b226172636869766542726f7773696e67456e61626c6564223a66616c73652c22626c61636b65644f7574223a66616c73652c22646f776e6c6f61645265646972656374436f6e666967223a7b22656e61626c6564223a66616c73657d2c2270726f706572747953657452656673223a5b5d2c22636865636b73756d506f6c69637954797065223a22636c69656e742d636865636b73756d73222c227072696f726974795265736f6c7574696f6e223a66616c73652c226d6178556e69717565536e617073686f7473223a302c2268616e646c6552656c6561736573223a747275652c2268616e646c65536e617073686f7473223a747275652c22736e617073686f7456657273696f6e4265686176696f72223a22756e69717565227d2c227061636b61676554797065436f6e666967223a7b7d2c227365637572697479436f6e666967223a7b2268696465556e617574686f72697a65645265736f7572636573223a66616c73652c227369676e656455726c54746c223a39307d2c227265706f54797065223a224c4f43414c227d2c7b2274797065223a226c6f63616c222c226b6579223a2261727469666163746f72792d6275696c642d696e666f222c227061636b61676554797065223a226275696c64696e666f222c2262617365436f6e666967223a7b226d6f64656c56657273696f6e223a322c227265706f4c61796f7574526566223a2273696d706c652d64656661756c74222c22696e636c756465735061747465726e223a222a2a2f2a227d2c227265706f54797065436f6e666967223a7b226172636869766542726f7773696e67456e61626c6564223a66616c73652c22626c61636b65644f7574223a66616c73652c22646f776e6c6f61645265646972656374436f6e666967223a7b22656e61626c6564223a66616c73657d2c2270726f706572747953657452656673223a5b5d2c22636865636b73756d506f6c69637954797065223a22636c69656e742d636865636b73756d73222c227072696f726974795265736f6c7574696f6e223a66616c73652c226d6178556e69717565536e617073686f7473223a302c2268616e646c6552656c6561736573223a747275652c2268616e646c65536e617073686f7473223a747275652c22736e617073686f7456657273696f6e4265686176696f72223a22756e69717565227d2c227061636b61676554797065436f6e666967223a7b7d2c227365637572697479436f6e666967223a7b2268696465556e617574686f72697a65645265736f7572636573223a66616c73652c227369676e656455726c54746c223a39307d2c227265706f54797065223a224c4f43414c227d5d2c226665646572617465645265706f436f6e66696773223a5b5d2c2272656c6561736542756e646c655265706f436f6e66696773223a5b5d2c2272656d6f74655265706f436f6e66696773223a5b5d2c227669727475616c5265706f436f6e66696773223a5b5d7d
artifactory.config.xml	2	\\x3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d3822207374616e64616c6f6e653d22796573223f3e0a3c636f6e66696720786d6c6e733d22687474703a2f2f61727469666163746f72792e6a66726f672e6f72672f7873642f332e342e352220786d6c6e733a7873693d22687474703a2f2f7777772e77332e6f72672f323030312f584d4c536368656d612d696e7374616e636522207873693a736368656d614c6f636174696f6e3d2268747470733a2f2f72656c65617365732e6a66726f672e696f2f61727469666163746f72792f7374617469632d72656c656173652d7669727475616c2f7873642f61727469666163746f72792f61727469666163746f72792d76335f345f352e787364223e0a202020203c7265706f7369746f7269657347656e6572616c436f6e6669673e0a20202020202020203c68656c6d3e0a2020202020202020202020203c666f7263654f636946697273745569466c6f773e747275653c2f666f7263654f636946697273745569466c6f773e0a2020202020202020202020203c666f7263654d657461646174614e616d6556657273696f6e3e66616c73653c2f666f7263654d657461646174614e616d6556657273696f6e3e0a2020202020202020202020203c666f7263654e6f6e4475706c696361746543686172743e66616c73653c2f666f7263654e6f6e4475706c696361746543686172743e0a20202020202020203c2f68656c6d3e0a20202020202020203c6e756765743e0a2020202020202020202020203c656e61626c65476c6f62616c4e6f726d616c697a6174696f6e3e66616c73653c2f656e61626c65476c6f62616c4e6f726d616c697a6174696f6e3e0a20202020202020203c2f6e756765743e0a202020203c2f7265706f7369746f7269657347656e6572616c436f6e6669673e0a202020203c666f7263654e617469766544624c6f636b734d656368616e69736d496e4175746f4d6f64653e66616c73653c2f666f7263654e617469766544624c6f636b734d656368616e69736d496e4175746f4d6f64653e0a202020203c7573654f6e6c79546f6b656e466f724964656e74696679696e6758726179557365723e747275653c2f7573654f6e6c79546f6b656e466f724964656e74696679696e6758726179557365723e0a202020203c6f66666c696e654d6f64653e66616c73653c2f6f66666c696e654d6f64653e0a202020203c66696c6555706c6f61644d617853697a654d623e3130303c2f66696c6555706c6f61644d617853697a654d623e0a202020203c7265766973696f6e3e323c2f7265766973696f6e3e0a202020203c6164646f6e733e0a20202020202020203c73686f774164646f6e73496e666f3e747275653c2f73686f774164646f6e73496e666f3e0a20202020202020203c73686f774164646f6e73496e666f436f6f6b69653e313737383533353834323632393c2f73686f774164646f6e73496e666f436f6f6b69653e0a202020203c2f6164646f6e733e0a202020203c73656375726974793e0a20202020202020203c68696465556e617574686f72697a65645265736f75726365733e66616c73653c2f68696465556e617574686f72697a65645265736f75726365733e0a20202020202020203c70617373776f726453657474696e67733e0a2020202020202020202020203c65787069726174696f6e506f6c6963793e0a202020202020202020202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a202020202020202020202020202020203c70617373776f72644d61784167653e313c2f70617373776f72644d61784167653e0a202020202020202020202020202020203c6e6f746966794279456d61696c3e747275653c2f6e6f746966794279456d61696c3e0a2020202020202020202020203c2f65787069726174696f6e506f6c6963793e0a2020202020202020202020203c7265736574506f6c6963793e0a202020202020202020202020202020203c656e61626c65643e747275653c2f656e61626c65643e0a202020202020202020202020202020203c6d6178417474656d707473506572416464726573733e333c2f6d6178417474656d707473506572416464726573733e0a202020202020202020202020202020203c74696d65546f426c6f636b496e4d696e757465733e36303c2f74696d65546f426c6f636b496e4d696e757465733e0a2020202020202020202020203c2f7265736574506f6c6963793e0a20202020202020203c2f70617373776f726453657474696e67733e0a20202020202020203c6f6175746853657474696e67733e0a2020202020202020202020203c656e61626c65496e746567726174696f6e3e66616c73653c2f656e61626c65496e746567726174696f6e3e0a2020202020202020202020203c616c6c6f7755736572546f41636365737350726f66696c653e66616c73653c2f616c6c6f7755736572546f41636365737350726f66696c653e0a2020202020202020202020203c7065727369737455736572733e66616c73653c2f7065727369737455736572733e0a2020202020202020202020203c6f6175746850726f76696465727353657474696e67732f3e0a20202020202020203c2f6f6175746853657474696e67733e0a20202020202020203c63656e7472616c4f4175746850726f7669646572733e0a2020202020202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a20202020202020203c2f63656e7472616c4f4175746850726f7669646572733e0a20202020202020203c6275696c64476c6f62616c426173696352656164416c6c6f7765643e66616c73653c2f6275696c64476c6f62616c426173696352656164416c6c6f7765643e0a20202020202020203c6275696c64476c6f62616c426173696352656164466f72416e6f6e796d6f75733e66616c73653c2f6275696c64476c6f62616c426173696352656164466f72416e6f6e796d6f75733e0a202020203c2f73656375726974793e0a202020203c6261636b7570733e0a20202020202020203c6261636b75703e0a2020202020202020202020203c6b65793e6261636b75702d6461696c793c2f6b65793e0a2020202020202020202020203c656e61626c65643e747275653c2f656e61626c65643e0a2020202020202020202020203c63726f6e4578703e3020302032203f202a204d4f4e2d4652493c2f63726f6e4578703e0a2020202020202020202020203c726574656e74696f6e506572696f64486f7572733e303c2f726574656e74696f6e506572696f64486f7572733e0a2020202020202020202020203c637265617465417263686976653e66616c73653c2f637265617465417263686976653e0a2020202020202020202020203c6578636c756465645265706f7369746f726965732f3e0a2020202020202020202020203c73656e644d61696c4f6e4572726f723e747275653c2f73656e644d61696c4f6e4572726f723e0a2020202020202020202020203c6578636c7564654e65775265706f7369746f726965733e66616c73653c2f6578636c7564654e65775265706f7369746f726965733e0a2020202020202020202020203c70726563616c63756c6174653e66616c73653c2f70726563616c63756c6174653e0a2020202020202020202020203c6578706f72744d697373696f6e436f6e74726f6c3e66616c73653c2f6578706f72744d697373696f6e436f6e74726f6c3e0a20202020202020203c2f6261636b75703e0a20202020202020203c6261636b75703e0a2020202020202020202020203c6b65793e6261636b75702d7765656b6c793c2f6b65793e0a2020202020202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a2020202020202020202020203c63726f6e4578703e3020302032203f202a205341543c2f63726f6e4578703e0a2020202020202020202020203c726574656e74696f6e506572696f64486f7572733e3333363c2f726574656e74696f6e506572696f64486f7572733e0a2020202020202020202020203c637265617465417263686976653e66616c73653c2f637265617465417263686976653e0a2020202020202020202020203c6578636c756465645265706f7369746f726965732f3e0a2020202020202020202020203c73656e644d61696c4f6e4572726f723e747275653c2f73656e644d61696c4f6e4572726f723e0a2020202020202020202020203c6578636c7564654e65775265706f7369746f726965733e66616c73653c2f6578636c7564654e65775265706f7369746f726965733e0a2020202020202020202020203c70726563616c63756c6174653e66616c73653c2f70726563616c63756c6174653e0a2020202020202020202020203c6578706f72744d697373696f6e436f6e74726f6c3e66616c73653c2f6578706f72744d697373696f6e436f6e74726f6c3e0a20202020202020203c2f6261636b75703e0a202020203c2f6261636b7570733e0a202020203c696e64657865723e0a20202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a20202020202020203c63726f6e4578703e302032332035202a202a203f3c2f63726f6e4578703e0a202020203c2f696e64657865723e0a202020203c6c6f63616c5265706f7369746f726965732f3e0a202020203c72656d6f74655265706f7369746f726965732f3e0a202020203c7669727475616c5265706f7369746f726965732f3e0a202020203c6665646572617465645265706f7369746f726965732f3e0a202020203c72656c6561736542756e646c65735265706f7369746f726965732f3e0a202020203c70726f786965732f3e0a202020203c7265766572736550726f786965732f3e0a202020203c70726f7065727479536574732f3e0a202020203c73797374656d50726f706572746965732f3e0a202020203c7265706f4c61796f7574733e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6d6176656e2d322d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e747275653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c64657363726970746f72506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e706f6d3c2f64657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e534e415053484f543c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e534e415053484f547c283f3a283f3a5b302d395d7b387d2e5b302d395d7b367d292d283f3a5b302d395d2b29293c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6976792d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f72675d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f5b747970655d732f5b6d6f64756c655d282d5b636c61737369666965725d292d5b626173655265765d282d5b66696c65497465675265765d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e747275653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c64657363726970746f72506174685061747465726e3e5b6f72675d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f5b747970655d732f6976792d5b626173655265765d282d5b66696c65497465675265765d292e786d6c3c2f64657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6d6176656e2d312d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f72675d2f5b747970655d732f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e747275653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c64657363726970746f72506174685061747465726e3e5b6f72675d2f5b747970655d732f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d292e706f6d3c2f64657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2b3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2b3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6e756765742d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b6d6f64756c655d2e5b626173655265765d282d5b66696c65497465675265765d292e6e75706b673c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6e706d2d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f2d2f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d292e74677a3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e626f7765722d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7663732d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b72656673266c743b746167737c6272616e636865732667743b5d2f5b626173655265765d2f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e5b612d7a412d5a302d395d7b34307d3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7362742d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f72675d2f5b6d6f64756c655d2f287363616c615f5b7363616c6156657273696f6e266c743b2e2b2667743b5d292f287362745f5b73627456657273696f6e266c743b2e2b2667743b5d292f5b626173655265765d2f5b747970655d732f5b6d6f64756c655d282d5b636c61737369666965725d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e747275653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c64657363726970746f72506174685061747465726e3e5b6f72675d2f5b6d6f64756c655d2f287363616c615f5b7363616c6156657273696f6e266c743b2e2b2667743b5d292f287362745f5b73627456657273696f6e266c743b2e2b2667743b5d292f5b626173655265765d2f5b747970655d732f6976792e786d6c3c2f64657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e73696d706c652d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b6d6f64756c655d2d5b626173655265765d2e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e636172676f2d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e6372617465732f5b6d6f64756c655d2f5b6d6f64756c655d2d5b626173655265765d2e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e636f6d706f7365722d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e636f6e616e2d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f72675d2f5b6d6f64756c655d2f5b626173655265765d2f5b6368616e6e656c266c743b5b5e2f5d2b2667743b5d2f5b666f6c646572497465675265765d2f287061636b6167652f5b7061636b6167655f6964266c743b5b5e2f5d2b2667743b5d2f5b66696c65497465675265765d2f295b72656d61696e646572266c743b283f3a2e2b292667743b5d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e5b5e2f5d2b3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e5b5e2f5d2b3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7075707065742d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b6f7267506174685d2d5b6d6f64756c655d2d5b626173655265765d2e7461722e677a3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e676f2d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f40762f765b626173655265765d282d5b66696c65497465675265765d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e6275696c642d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d282d5b66696c65497465675265765d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7465727261666f726d2d6d6f64756c652d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6e616d6573706163655d2f5b6d6f64756c652d6e616d655d2f5b70726f76696465725d2f5b76657273696f6e5d2e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7465727261666f726d2d70726f76696465722d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e0a202020202020202020202020202020205b6e616d6573706163655d2f5b70726f76696465722d6e616d655d2f5b76657273696f6e5d2f7465727261666f726d2d70726f76696465722d5b70726f76696465722d6e616d655d5f5b76657273696f6e5d5f5b6f735d5f5b617263685d2e5b6578745d0a2020202020202020202020203c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e73776966742d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b73636f70655d2f5b6e616d655d2f5b6e616d655d2d5b76657273696f6e5d2e7a69703c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e616e7369626c652d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e636f6c6c656374696f6e732f5b6e616d6573706163655d2f5b6e616d655d2f5b76657273696f6e5d2f5b6e616d6573706163655d2d5b6e616d655d2d5b76657273696f6e5d2e7461722e677a3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e66616c73653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e2e2a3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a20202020202020203c7265706f4c61796f75743e0a2020202020202020202020203c6e616d653e7362742d6976792d64656661756c743c2f6e616d653e0a2020202020202020202020203c6172746966616374506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f5b6d6f64756c655d2d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e5b6578745d3c2f6172746966616374506174685061747465726e3e0a2020202020202020202020203c64697374696e637469766544657363726970746f72506174685061747465726e3e747275653c2f64697374696e637469766544657363726970746f72506174685061747465726e3e0a2020202020202020202020203c64657363726970746f72506174685061747465726e3e5b6f7267506174685d2f5b6d6f64756c655d2f5b626173655265765d282d5b666f6c646572497465675265765d292f6976792d5b626173655265765d282d5b66696c65497465675265765d29282d5b636c61737369666965725d292e786d6c3c2f64657363726970746f72506174685061747465726e3e0a2020202020202020202020203c666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f666f6c646572496e746567726174696f6e5265766973696f6e5265674578703e0a2020202020202020202020203c66696c65496e746567726174696f6e5265766973696f6e5265674578703e5c647b31347d3c2f66696c65496e746567726174696f6e5265766973696f6e5265674578703e0a20202020202020203c2f7265706f4c61796f75743e0a202020203c2f7265706f4c61796f7574733e0a202020203c72656d6f74655265706c69636174696f6e732f3e0a202020203c6c6f63616c5265706c69636174696f6e732f3e0a202020203c6763436f6e6669673e0a20202020202020203c63726f6e4578703e302030202f34202a202a203f3c2f63726f6e4578703e0a202020203c2f6763436f6e6669673e0a202020203c636c65616e7570436f6e6669673e0a20202020202020203c63726f6e4578703e302031322035202a202a203f3c2f63726f6e4578703e0a202020203c2f636c65616e7570436f6e6669673e0a202020203c7669727475616c4361636865436c65616e7570436f6e6669673e0a20202020202020203c63726f6e4578703e302031322030202a202a203f3c2f63726f6e4578703e0a202020203c2f7669727475616c4361636865436c65616e7570436f6e6669673e0a202020203c666f6c646572446f776e6c6f6164436f6e6669673e0a20202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a20202020202020203c656e61626c6564466f72416e6f6e796d6f75733e66616c73653c2f656e61626c6564466f72416e6f6e796d6f75733e0a20202020202020203c6d6178446f776e6c6f616453697a654d623e313032343c2f6d6178446f776e6c6f616453697a654d623e0a20202020202020203c6d617846696c65733e353030303c2f6d617846696c65733e0a20202020202020203c6d6178436f6e63757272656e7452657175657374733e31303c2f6d6178436f6e63757272656e7452657175657374733e0a20202020202020203c656e61626c6564456d7074794469726563746f726965733e66616c73653c2f656e61626c6564456d7074794469726563746f726965733e0a202020203c2f666f6c646572446f776e6c6f6164436f6e6669673e0a202020203c747261736863616e436f6e6669673e0a20202020202020203c656e61626c65643e747275653c2f656e61626c65643e0a20202020202020203c616c6c6f775065726d44656c657465733e66616c73653c2f616c6c6f775065726d44656c657465733e0a20202020202020203c726574656e74696f6e506572696f64446179733e31343c2f726574656e74696f6e506572696f64446179733e0a202020203c2f747261736863616e436f6e6669673e0a202020203c6974656d7342726f77736572506167696e6753697a653e3530303c2f6974656d7342726f77736572506167696e6753697a653e0a202020203c7265706c69636174696f6e73436f6e6669673e0a20202020202020203c626c6f636b507573685265706c69636174696f6e733e66616c73653c2f626c6f636b507573685265706c69636174696f6e733e0a20202020202020203c626c6f636b50756c6c5265706c69636174696f6e733e66616c73653c2f626c6f636b50756c6c5265706c69636174696f6e733e0a202020203c2f7265706c69636174696f6e73436f6e6669673e0a202020203c73756d6f4c6f676963436f6e6669673e0a20202020202020203c656e61626c65643e66616c73653c2f656e61626c65643e0a202020203c2f73756d6f4c6f676963436f6e6669673e0a202020203c72656c6561736542756e646c6573436f6e6669673e0a20202020202020203c696e636f6d706c657465436c65616e7570506572696f64486f7572733e3732303c2f696e636f6d706c657465436c65616e7570506572696f64486f7572733e0a202020203c2f72656c6561736542756e646c6573436f6e6669673e0a202020203c726c6d436f6e6669672f3e0a202020203c7369676e656455726c436f6e6669673e0a20202020202020203c6d617856616c6964466f725365636f6e64733e33313533363030303c2f6d617856616c6964466f725365636f6e64733e0a202020203c2f7369676e656455726c436f6e6669673e0a202020203c646f776e6c6f61645265646972656374436f6e6669673e0a20202020202020203c66696c654d696e696d756d53697a653e313c2f66696c654d696e696d756d53697a653e0a202020203c2f646f776e6c6f61645265646972656374436f6e6669673e0a202020203c6b657950616972732f3e0a202020203c726574656e74696f6e53657474696e67733e0a20202020202020203c726574656e74696f6e506f6c69636965732f3e0a202020203c2f726574656e74696f6e53657474696e67733e0a202020203c61757468656e7469636174696f6e3e0a20202020202020203c746f6b656e732f3e0a202020203c2f61757468656e7469636174696f6e3e0a3c2f636f6e6669673e0a
\.


--
-- Data for Name: db_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.db_properties (installation_date, artifactory_version, artifactory_revision, artifactory_release, artifactory_product_version) FROM stdin;
1778535794177	7.111.8	81108900	1167040800000	7.111.9
\.


--
-- Data for Name: distributed_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.distributed_locks (category, lock_key, owner, owner_thread, owner_thread_name, acquire_time) FROM stdin;
\.


--
-- Data for Name: file_list_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_list_tasks (repo, path, heartbeat) FROM stdin;
\.


--
-- Data for Name: heavy_query_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.heavy_query_cache (id, cache_key, cache_time, expiry_time, data) FROM stdin;
7	hqc_storage_info	1778535845797	1778557745797	\\x7b227265706f53746f7261676553756d6d6172696573223a7b226578616d706c652d7265706f2d6c6f63616c223a7b227265706f4b6579223a226578616d706c652d7265706f2d6c6f63616c222c2270726f6a6563744b6579223a2264656661756c74222c227265706f54797065223a224c4f43414c222c22666f6c64657273436f756e74223a302c2266696c6573436f756e74223a302c22757365645370616365223a302c2274797065223a2247656e65726963222c226974656d73436f756e74223a307d2c226175746f2d747261736863616e223a7b227265706f4b6579223a226175746f2d747261736863616e222c2270726f6a6563744b6579223a2264656661756c74222c227265706f54797065223a224e41222c22666f6c64657273436f756e74223a302c2266696c6573436f756e74223a302c22757365645370616365223a302c2274797065223a224e41222c226974656d73436f756e74223a307d2c2261727469666163746f72792d6275696c642d696e666f223a7b227265706f4b6579223a2261727469666163746f72792d6275696c642d696e666f222c2270726f6a6563744b6579223a2264656661756c74222c227265706f54797065223a224c4f43414c222c22666f6c64657273436f756e74223a302c2266696c6573436f756e74223a302c22757365645370616365223a302c2274797065223a224275696c64496e666f222c226974656d73436f756e74223a307d7d2c2270726f6a65637473546f74616c53697a6573223a7b2264656661756c74223a307d2c2270726f6a65637473546f74616c46696c6573436f756e74223a7b2264656661756c74223a307d2c2262696e6172696573496e666f223a7b2262696e6172696573436f756e74223a302c2262696e617269657353697a65223a307d2c22746f74616c53697a65223a302c22746f74616c466f6c64657273223a302c22746f74616c46696c6573223a302c226c61737455706461746564223a313737383533353834353735322c22746f74616c4974656d73223a302c226f7074696d697a6174696f6e223a224e614e227d
12	hqc_total_artifact_count	1778536141026	1778536146026	\\x30
\.


--
-- Data for Name: indexed_archives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indexed_archives (archive_sha1, indexed_archives_id) FROM stdin;
\.


--
-- Data for Name: indexed_archives_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indexed_archives_entries (indexed_archives_id, entry_path_id, entry_name_id) FROM stdin;
\.


--
-- Data for Name: jfconfig_platform_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jfconfig_platform_config (config_key, revision, created, modified, configuration, is_secret) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (job_id, job_type, job_status, started, finished, additional_details) FROM stdin;
\.


--
-- Data for Name: master_key_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_key_status (is_unique_key, status, set_by_node_id, kid, expires) FROM stdin;
1	on	3ef7c81c2124	99548acaeff8a5962597351f2b702735627dcfb7612caa57fa7e506503343282	0
\.


--
-- Data for Name: md_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_configs (id, config_name, modified, data) FROM stdin;
2053953997047787520	service_id	1778535768173	\\x6a666d644030316b7263667738336478626668343362667a63373136316473
\.


--
-- Data for Name: md_contributors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_contributors (id, name, type, email, url) FROM stdin;
\.


--
-- Data for Name: md_database_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_database_migrations (id, applied_at, allow_to_rollback, rollbacked) FROM stdin;
v001_packages.sql	1778535767	0	0
v002_versions.sql	1778535767	0	0
v003_package_qualifiers.sql	1778535767	0	0
v004_package_user_properties.sql	1778535767	0	0
v005_package_tags.sql	1778535767	0	0
v006_package_stats.sql	1778535767	0	0
v007_sources.sql	1778535767	0	0
v008_package_info_sources.sql	1778535767	0	0
v009_servers.sql	1778535767	0	0
v010_version_qualifiers.sql	1778535767	0	0
v011_version_user_properties.sql	1778535767	0	0
v012_version_tags.sql	1778535767	0	0
v013_version_stats.sql	1778535767	0	0
v014_licenses.sql	1778535767	0	0
v015_files.sql	1778535767	0	0
v016_file_qualifiers.sql	1778535767	0	0
v017_package_licenses.sql	1778535767	0	0
v018_version_licenses.sql	1778535767	0	0
v019_files_versions.sql	1778535767	0	0
v020_repo.sql	1778535767	0	0
v021_lead_paths.sql	1778535767	0	0
v022_package_descriptions.sql	1778535767	0	0
v023_contributors.sql	1778535767	0	0
v024_version_contributors.sql	1778535767	0	0
v025_sharedconfigs.sql	1778535767	0	0
v026_version_vulns.sql	1778535767	0	0
v027_package_vulns.sql	1778535767	0	0
v028_versions_ordinal_index.sql	1778535767	0	0
v029_qualifier_user_prop_length.sql	1778535767	0	0
v030_version_addcolumn_size.sql	1778535767	0	0
v031_package_add_base_model_complete.sql	1778535767	0	0
v032_rename_stats_columns.sql	1778535767	0	0
v033_rename_size_column.sql	1778535767	0	0
v034_ver_stats_fk_ver_repos_fk.sql	1778535767	0	0
v035_files_unique_name_sha256.sql	1778535767	0	0
v036_version_add_modified.sql	1778535767	0	0
v037_version_add_base_model_complete.sql	1778535767	0	0
v038_file_targets.sql	1778535767	0	0
v039_file_targets_fk.sql	1778535767	0	0
v040_resize_pkg_tags_value_column.sql	1778535767	0	0
v041_resize_ver_tags_value_column.sql	1778535767	0	0
v042_async_data_converter.sql	1778535768	0	0
v043_add_mark_for_deletion.sql	1778535768	0	0
v044_add_dependant_task.sql	1778535768	0	0
v045_delete_reorder_prerelease_version_task.sql	1778535768	0	0
v046_add_cvss3.sql	1778535768	0	0
v047_reorder_task_temp_table.sql	1778535768	0	0
v048_version_operational_risk.sql	1778535768	0	0
v049_package_operational_risk.sql	1778535768	0	0
v050_tasks_drop_index.sql	1778535768	0	0
v051_md_fil_qualifiers_delete_cascade.sql	1778535768	0	0
v052_md_version_repo_stats.sql	1778535768	0	0
v053_md_packages_rename_package_type_column.sql	1778535768	0	0
v054_md_packages_add_stored_package_type_column.sql	1778535768	0	0
v055_md_packages_create_repo_package_type_index.sql	1778535768	1	0
v056_md_packages_create_stored_package_type_index.sql	1778535768	1	0
v057_md_package_version_location.sql	1778535768	1	0
v058_md_package_version_location_stats.sql	1778535768	1	0
\.


--
-- Data for Name: md_fil_qualifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_fil_qualifiers (id, file_id, name, value) FROM stdin;
\.


--
-- Data for Name: md_fil_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_fil_targets (id, arch, dist, compiler, compiler_version) FROM stdin;
\.


--
-- Data for Name: md_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_files (id, name, sha256, sha1, md5, is_lead, length, arch, dist, mime_type, file_target_id) FROM stdin;
\.


--
-- Data for Name: md_files_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_files_versions (id, file_id, version_id) FROM stdin;
\.


--
-- Data for Name: md_licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_licenses (id, name, description, url) FROM stdin;
\.


--
-- Data for Name: md_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_lock (lock_name, lock_owner, acquired_at) FROM stdin;
\.


--
-- Data for Name: md_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_packages (id, pkgid, name, lowercase_name, repo_package_type, website, vcs_url, issues_url, trimmed_description, created, modified, edited, respects_semver, min_write_level, latest_version_name, base_model_complete, stored_package_type) FROM stdin;
\.


--
-- Data for Name: md_pkg_descriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_descriptions (package_id, description) FROM stdin;
\.


--
-- Data for Name: md_pkg_info_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_info_sources (id, package_id, source_id, modified) FROM stdin;
\.


--
-- Data for Name: md_pkg_licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_licenses (id, package_id, name, source, modified) FROM stdin;
\.


--
-- Data for Name: md_pkg_op_risk; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_op_risk (package_id, risk_level, cadence, commits, contributors) FROM stdin;
\.


--
-- Data for Name: md_pkg_qualifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_qualifiers (id, package_id, name, value) FROM stdin;
\.


--
-- Data for Name: md_pkg_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_stats (package_id, follower_count, download_count) FROM stdin;
\.


--
-- Data for Name: md_pkg_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_tags (id, package_id, value) FROM stdin;
\.


--
-- Data for Name: md_pkg_user_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_user_properties (id, package_id, name, value) FROM stdin;
\.


--
-- Data for Name: md_pkg_vulns_sum; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_pkg_vulns_sum (package_id, high, medium, low, info, unknown, skipped, critical) FROM stdin;
\.


--
-- Data for Name: md_repos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_repos (id, name, url, type) FROM stdin;
\.


--
-- Data for Name: md_servers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_servers (id, created, modified, version, last_heartbeat, base_url, node_unique_id) FROM stdin;
3ef7c81c2124	1778535768177	1778535768177	7.155.2	1778536413180	http://localhost:8046	907
\.


--
-- Data for Name: md_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_sources (id, name, url) FROM stdin;
\.


--
-- Data for Name: md_task_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_task_batches (task_key, progress, modified, batch_start_key, batch_end_key) FROM stdin;
\.


--
-- Data for Name: md_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_tasks (task_key, execution_interval_millis, progress, modified, task_start_key, task_end_key, depends_on) FROM stdin;
deleteOrphanVersionMigrationTask	172800000	PENDING_PREREQ	1778535828855	0	0	VersionBaseModelCompleteIndexTaskKey,versionBaseModelCompleteTask
versionsPackageIdOrdinalIndexTask	0	IN_PROGRESS	1778535828855	0	1	
verReposLeadFilePathIndexIndexTask	0	IN_PROGRESS	1778535828855	0	1	
fullTextIndexTask	0	IN_PROGRESS	1778535828855	0	1	
reorderPrereleaseVersionMigrationTask	0	PENDING_PREREQ	1778535828855	0	0	versionsPackageIdOrdinalIndexTask
versionBaseModelCompleteTask	0	PENDING_PREREQ	1778535828855	0	0	VersionBaseModelCompleteIndexTaskKey
deletedVersionsGarbageCollectorTask	86400000	COMPLETE	1778535828855	-1	-1	
valueColumnsToNullableTask	0	IN_PROGRESS	1778535828855	0	1	
VersionBaseModelCompleteIndexTaskKey	0	IN_PROGRESS	1778535828855	0	1	
ginIndexTask	0	IN_PROGRESS	1778535828855	0	1	
reindexPkgidTask	0	COMPLETE	1778535828855	-1	-1	
\.


--
-- Data for Name: md_temp_prerelease_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_temp_prerelease_groups (id, package_id, ordinal_no_prerelease, group_size) FROM stdin;
\.


--
-- Data for Name: md_ver_contributors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_contributors (id, version_id, contributor_id) FROM stdin;
\.


--
-- Data for Name: md_ver_licenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_licenses (id, version_id, name, source, modified) FROM stdin;
\.


--
-- Data for Name: md_ver_op_risk; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_op_risk (version_id, risk_level) FROM stdin;
\.


--
-- Data for Name: md_ver_qualifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_qualifiers (id, version_id, name, value) FROM stdin;
\.


--
-- Data for Name: md_ver_repos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_repos (id, version_id, repo_id, lead_file_path, lead_hash) FROM stdin;
\.


--
-- Data for Name: md_ver_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_stats (version_id, download_count) FROM stdin;
\.


--
-- Data for Name: md_ver_tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_tags (id, version_id, value) FROM stdin;
\.


--
-- Data for Name: md_ver_user_properties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_user_properties (id, version_id, name, value) FROM stdin;
\.


--
-- Data for Name: md_ver_vulns_sum; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_ver_vulns_sum (version_id, high, medium, low, info, unknown, skipped, critical) FROM stdin;
\.


--
-- Data for Name: md_version_repo_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_version_repo_stats (repo_id, version_id, download_count, last_downloaded, remote_last_downloaded) FROM stdin;
\.


--
-- Data for Name: md_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.md_versions (id, package_id, name, lowercase_name, created, ordinal, min_write_level, version_size, modified, base_model_complete, marked_for_deletion, last_edited) FROM stdin;
\.


--
-- Data for Name: migration_status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_status (identifier, started, finished, migration_info_blob) FROM stdin;
metadata-service-migration	1778535845808	1778535845808	\\x7b226d6967726174696f6e5f7461726765745f6e6f64655f6964223a302c2263757272656e745f6576656e745f6c6f675f74696d657374616d70223a307d
event-table-repo-key-migration	1778535875790	1778535880841	\\x7b227365727665725f6964223a22227d
\.


--
-- Data for Name: mirrors_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mirrors_metadata (metadata_type, member_url, cache_time, metadata_blob) FROM stdin;
\.


--
-- Data for Name: module_props; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.module_props (prop_id, module_id, prop_key, prop_value) FROM stdin;
\.


--
-- Data for Name: node_event_cursor; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_event_cursor (operator_id, event_marker, type, status, last_updated) FROM stdin;
jfrog_gc_internal-gc-cursor	-1	GC	\N	1778535844744
metadata-operator-events	1778536080061	METADATA_EVENTS	\N	\N
\.


--
-- Data for Name: node_event_priorities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_event_priorities (priority_id, path, type, operator_id, priority, "timestamp", retry_count) FROM stdin;
\.


--
-- Data for Name: node_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events (event_id, "timestamp", event_type, path, hints, repo) FROM stdin;
1	1778535845558	1	example-repo-local/	["ast.async.thread"]	example-repo-local
2	1778535845598	1	artifactory-build-info/	["ast.async.thread"]	artifactory-build-info
3	1778536079800	1	sec4us/	\N	sec4us
4	1778536080061	3	example-repo-local/	["rmr.5f0b00104c5a61b3","file:false"]	example-repo-local
\.


--
-- Data for Name: node_events_errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events_errors (error_id, operation_key, event_category, first_error_time, last_error_time, error_count, error_message, event_id, event_time, event_type, path) FROM stdin;
\.


--
-- Data for Name: node_events_tmp_p0_5; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events_tmp_p0_5 (tmp_event_id, "timestamp", event_type, path, hints) FROM stdin;
\.


--
-- Data for Name: node_events_tmp_p12_17; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events_tmp_p12_17 (tmp_event_id, "timestamp", event_type, path, hints) FROM stdin;
\.


--
-- Data for Name: node_events_tmp_p18_23; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events_tmp_p18_23 (tmp_event_id, "timestamp", event_type, path, hints) FROM stdin;
\.


--
-- Data for Name: node_events_tmp_p6_11; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_events_tmp_p6_11 (tmp_event_id, "timestamp", event_type, path, hints) FROM stdin;
\.


--
-- Data for Name: node_meta_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_meta_infos (node_id, props_modified, props_modified_by, props_md5) FROM stdin;
\.


--
-- Data for Name: node_props; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.node_props (prop_id, node_id, prop_key, prop_value) FROM stdin;
\.


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodes (node_id, node_type, repo, node_path, node_name, depth, created, created_by, modified, modified_by, updated, bin_length, sha1_actual, sha1_original, md5_actual, md5_original, sha256, repo_path_checksum) FROM stdin;
1	0	auto-trashcan	.	.	0	1778535844583	\N	1778535844583	\N	1778535844583	0	\N	\N	\N	\N	\N	3321383d7f6d80140563c23d3a22d647e20cafb9
2	0	jfrog-support-bundle	.	.	0	1778535844688	\N	1778535844688	\N	1778535844688	0	\N	\N	\N	\N	\N	59c86c2bf5350c9c8961a57057819bfeeba79617
5	0	artifactory-build-info	.	.	0	1778535845596	\N	1778535845596	\N	1778535845596	0	\N	\N	\N	\N	\N	1d06e7fa42f6b62e8e8acf2ca0f0aba4d8b9e7ac
9	0	sec4us	.	.	0	1778536079799	\N	1778536079799	\N	1778536079799	0	\N	\N	\N	\N	\N	c46dc724a9491d4626ad2d4d0b0a93f6142c73fa
\.


--
-- Data for Name: nodes_cleaned; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodes_cleaned (id, policy_key, policy_run_id, repo, node_path, node_name, bin_length, sha1, status, lead_artifact, package_name, package_version, message) FROM stdin;
\.


--
-- Data for Name: policy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policy (policy_key, policy_type, item_type, enabled, created, created_by, config, modified, modified_by, cronexp, description) FROM stdin;
\.


--
-- Data for Name: quartz_task_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quartz_task_history (run_id, external_id, task_type, started_date, finished_date, last_modified_date, status, status_message, deleted, task_id, server_id, manual_trigger, username) FROM stdin;
\.


--
-- Data for Name: repository_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repository_config (repository_key, type, package_type, revision, created, modified, config_blob) FROM stdin;
artifactory-build-info	local	buildinfo	0	1778535845268	1778535845268	\\x7b2274797065223a226c6f63616c222c226b6579223a2261727469666163746f72792d6275696c642d696e666f222c227061636b61676554797065223a226275696c64696e666f222c2262617365436f6e666967223a7b226d6f64656c56657273696f6e223a322c227265706f4c61796f7574526566223a2273696d706c652d64656661756c74222c22696e636c756465735061747465726e223a222a2a2f2a227d2c227265706f54797065436f6e666967223a7b226172636869766542726f7773696e67456e61626c6564223a66616c73652c22626c61636b65644f7574223a66616c73652c22646f776e6c6f61645265646972656374436f6e666967223a7b22656e61626c6564223a66616c73657d2c2270726f706572747953657452656673223a5b5d2c22636865636b73756d506f6c69637954797065223a22636c69656e742d636865636b73756d73222c227072696f726974795265736f6c7574696f6e223a66616c73652c226d6178556e69717565536e617073686f7473223a302c2268616e646c6552656c6561736573223a747275652c2268616e646c65536e617073686f7473223a747275652c22736e617073686f7456657273696f6e4265686176696f72223a22756e69717565227d2c227061636b61676554797065436f6e666967223a7b7d2c227365637572697479436f6e666967223a7b2268696465556e617574686f72697a65645265736f7572636573223a66616c73652c227369676e656455726c54746c223a39307d2c227265706f54797065223a224c4f43414c227d
sec4us	local	generic	0	1778536071165	1778536071165	\\x7b2274797065223a226c6f63616c222c226b6579223a22736563347573222c227061636b61676554797065223a2267656e65726963222c2262617365436f6e666967223a7b226d6f64656c56657273696f6e223a322c226465736372697074696f6e223a22536563345553204465764f7073204578706c6f69746174696f6e222c226e6f746573223a22222c227265706f4c61796f7574526566223a2273696d706c652d64656661756c74222c22696e636c756465735061747465726e223a222a2a2f2a222c226578636c756465735061747465726e223a22227d2c227265706f54797065436f6e666967223a7b226172636869766542726f7773696e67456e61626c6564223a66616c73652c22626c61636b65644f7574223a66616c73652c2270726f706572747953657452656673223a5b5d2c22636865636b73756d506f6c69637954797065223a22636c69656e742d636865636b73756d73222c227072696f726974795265736f6c7574696f6e223a66616c73652c226d6178556e69717565536e617073686f7473223a302c2268616e646c6552656c6561736573223a747275652c2268616e646c65536e617073686f7473223a747275652c22736e617073686f7456657273696f6e4265686176696f72223a22756e69717565227d2c227061636b61676554797065436f6e666967223a7b7d2c227365637572697479436f6e666967223a7b2268696465556e617574686f72697a65645265736f7572636573223a66616c73652c227369676e656455726c54746c223a39307d2c227265706f54797065223a224c4f43414c227d
\.


--
-- Data for Name: retention_run_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retention_run_summary (id, policy_key, run_id, dry_run, started_date, finished_date, retention_type, status, item_type, temp_nodes_cleaned, processed_items_count, failed_items_count, total_items_count, processed_physical_binary_size, processed_virtual_binary_size, total_binary_size, triggered_by, run_config) FROM stdin;
\.


--
-- Data for Name: schema_change_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_change_log (version, description, start_time, update_time, status, exec_type, product_version, initial_version, server_id, error_message) FROM stdin;
v204	v204_metadata_service_rollback_blocker	0	0	COMPLETED	SEQ_SYNC	7.90	\N	dummy_server	\N
v217	v217_metadata_service_rollback_blocker	0	0	COMPLETED	SEQ_SYNC	7.102	\N	dummy_server	\N
v224	v224_metadata_service_rollback_blocker	0	0	COMPLETED	SEQ_SYNC	7.108	\N	dummy_server	\N
v78	v78_change_nodes_node_name_idx	1778535846131	1778535846183	COMPLETED	SEQ_ASYNC	7.111.8	7.11.0-m033	3ef7c81c2124	\N
v79	v79_change_nodes_node_path_idx	1778535846186	1778535846210	SKIPPED	SEQ_ASYNC	7.111.8	7.11.0-m033	3ef7c81c2124	\N
v80	v80_change_nodes_node_repo_path_idx	1778535846213	1778535846282	SKIPPED	SEQ_ASYNC	7.111.8	7.11.0-m033	3ef7c81c2124	\N
v81	Create index `bundle_files_node_id_idx` for `bundle_files` on `node_id` field.	1778535846286	1778535846319	SKIPPED	SEQ_ASYNC	7.111.8	7.11.0-m033	3ef7c81c2124	\N
v95	Create index `node_events_tmp_event_id_idx` for `node_events_tmp` on `tmp_event_id` field.	1778535846322	1778535846344	SKIPPED	SEQ_ASYNC	7.111.8	7.20.1-m001	3ef7c81c2124	\N
v120	v120_prepare_change_node_props_node_prop_value_idx	1778535846347	1778535846413	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v121	v121_alter_node_props_node_prop_value_idx	1778535846417	1778535846457	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v122	v122_prepare_change_node_props_prop_key_value_idx	1778535846460	1778535846515	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v123	v123_alter_node_props_prop_key_value_idx	1778535846522	1778535846552	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v124	v124_prepare_change_node_props_prop_value_key_idx	1778535846557	1778535846601	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v125	v125_alter_node_props_prop_value_key_idx	1778535846607	1778535846633	SKIPPED	SEQ_ASYNC	7.111.8	7.34.0-m001	3ef7c81c2124	\N
v137	skip_version	1778535846636	1778535846646	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v138	skip_version	1778535846648	1778535846652	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v139	skip_version	1778535846656	1778535846662	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v141	skip_version	1778535846665	1778535846669	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v143	skip_version	1778535846670	1778535846678	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v144	v144_update_artifact_bundles_date_distributed	1778535846684	1778535846694	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v146	v146_binaries_tasks_add_index_repo	1778535846697	1778535846717	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v151	Creating index: nodes_repo_path_name_idx concurrently.	1778535846721	1778535846769	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v152	Creating index: nodes_node_name_idx concurrently.	1778535846771	1778535846789	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v153	Creating index: nodes_node_path_idx concurrently.	1778535846791	1778535846809	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v154	Creating index: node_props_prop_value_key_idx concurrently.	1778535846811	1778535846843	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v155	Creating index: node_props_prop_key_value_idx concurrently.	1778535846848	1778535846881	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v156	Creating index: node_props_node_prop_value_idx concurrently.	1778535846885	1778535846931	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v157	v157_create_pg_trgm_extension	1778535846932	1778535846981	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v158	Creating index: nodes_lower_node_name_gin_idx concurrently.	1778535846984	1778535847056	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v159	Drop index `pattern_node_props_node_prop_value_idx` for `node_props`.	1778535847059	1778535847128	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v160	Drop index `pattern_node_props_prop_key_value_idx` for `node_props`.	1778535847131	1778535847171	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v161	Drop index `pattern_node_props_prop_value_key_idx` for `node_props`.	1778535847173	1778535847209	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v162	Creating index: pattern_bundle_files_repo_path_idx concurrently.	1778535847212	1778535847243	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v163	Drop index `repo_path_bundle_files_idx` for `bundle_files`.	1778535847245	1778535847284	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v165	Drop index `node_events_tmp_event_id_idx` for `node_events_tmp`.	1778535847286	1778535847312	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v166	v166_set_repository_created_date	1778535847314	1778535847320	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v167	v167_rename_retention_restore_prefix	1778535847322	1778535847330	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v173	v173_cleanup_tasks_table	1778535847332	1778535847348	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v174	v174_add_new_column_on_tasks_with_pk	1778535847352	1778535847366	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v175	v175_create_primary_key_on_build_promotion	1778535847371	1778535847387	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v176	Drop index `build_promotions_created_idx` for `build_promotions`.	1778535847388	1778535847394	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v177	Creating index: nodes_name_path_idx concurrently.	1778535847397	1778535847430	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v178	Dropping index: nodes_node_name_idx concurrently.	1778535847432	1778535847480	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v179	Create index `nodes_name_path_idx` for `nodes` on `node_name,node_path` field.	1778535847482	1778535847485	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v180	Drop index `nodes_node_name_idx` for `nodes`.	1778535847487	1778535847512	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v181	skip_version	1778535847514	1778535847518	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v182	v182_create_partitions_for_node_events_tmp	1778535847520	1778535847690	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v183	v183_adjust_partitions_for_replications	1778535847692	1778535847724	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v185	v185_alter_prop_value_column	1778535847726	1778535847741	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v186	v186_alter_prop_key_column	1778535847743	1778535847761	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v187	v187_alter_node_events_sequence	1778535847763	1778535847766	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v196	Creating index: node_prop_nuget_partial_idx concurrently.	1778535847767	1778535847785	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v206	v206_nodes_add_index_repo_created	1778535847786	1778535847793	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v207	Creating index: nodes_repo_created_idx concurrently.	1778535847795	1778535847840	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v208	skip_version	1778535847842	1778535847924	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v209	skip_version	1778535847927	1778535847939	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v210	v210_alter_nodes_cleaned_table	1778535847940	1778535848138	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v211	v211_alter_nodes_cleaned_table	1778535848140	1778535848147	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v212	Creating index: nodes_cleaned_policy_key_policy_run_id_idx concurrently.	1778535848148	1778535848186	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v216	skip_version	1778535848187	1778535848194	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v219	Drop index `nodes_repo_path_checksum` for `nodes`.	1778535848197	1778535848223	SKIPPED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
v222	v222_cleanup_archive_index_tables	1778535848225	1778535848425	COMPLETED	SEQ_ASYNC	7.111.8		3ef7c81c2124	\N
\.


--
-- Data for Name: stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stats (node_id, download_count, last_downloaded, last_downloaded_by) FROM stdin;
\.


--
-- Data for Name: stats_remote; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stats_remote (node_id, origin, download_count, last_downloaded, last_downloaded_by, path) FROM stdin;
\.


--
-- Data for Name: storage_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_events (event_id, "timestamp", event_type, sha1, sha256, bin_length, data) FROM stdin;
\.


--
-- Data for Name: storage_multipart_uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storage_multipart_uploads (upload_id, created_date, temp_path, status, modified_date, data) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (task_type, task_context, created, task_id) FROM stdin;
\.


--
-- Data for Name: tpl_configuration; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tpl_configuration (property_key, property_value) FROM stdin;
service.id	jftpl@01krcfwtqhjjbz1pf84re41xhr
\.


--
-- Data for Name: tpl_schema_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tpl_schema_version (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	0	<< Flyway Baseline >>	BASELINE	<< Flyway Baseline >>	\N	artifactory	2026-05-11 18:43:06.776517	0	t
2	1.0	Initial Schema	SQL	V1_0__Initial_Schema.sql	407601942	artifactory	2026-05-11 18:43:07.040078	60	t
3	1.1	Create ServiceId	JDBC	com.jfrog.topology.server.changelogs.flyway.postgresql.V1_1__Create_ServiceId	\N	artifactory	2026-05-11 18:43:07.235298	17	t
4	1.2	Add Availability Zone id	SQL	V1_2__Add_Availability_Zone_id.sql	-278630518	artifactory	2026-05-11 18:43:07.268197	9	t
\.


--
-- Data for Name: tpl_topology; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tpl_topology (id, service_id, node_id, created, ip, port, secure, paths, state, last_updated, router_id, version, revision, availability_zone_id) FROM stdin;
ddbe8dca-6c56-4a02-b834-1274debc2f72	jfevt@01krcfxqjqxd9y1xv3hbse0w26	3ef7c81c2124	1778535836270	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/event/(.*)"},{"path":"/com\\\\.jfrog\\\\.event\\\\..*"}]}	HEALTHY	1778536416683	3ef7c81c2124	7.169.2	84f024f1b1	
18f2d939-3d34-4f5e-9a78-1c8bbe5acb19	jfmd@01krcfw83dxbfh43bfzc7161ds	3ef7c81c2124	1778535836270	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/metadata/(.*)"}]}	HEALTHY	1778536416683	3ef7c81c2124	7.155.2	f08600cb80a	
1e7980ff-c8ab-43a8-8bba-75216337b4ba	jfac@01krcfxqjqxd9y1xv3hbse0w26	3ef7c81c2124	1778535836270	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/com\\\\.jfrog\\\\.access\\\\..*"},{"path":"access/.*"}]}	HEALTHY	1778536416683	3ef7c81c2124	7.141.12	84112900	
20861b46-08c3-4375-97fb-3cb8063a26dd	jfcfg@01krcfxqjqxd9y1xv3hbse0w26	3ef7c81c2124	1778535846462	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/jfconfig/(.*)"},{"path":"/com\\\\.jfrog\\\\.access\\\\.v1\\\\.config\\\\..*"},{"path":"/com\\\\.jfrog\\\\.jfconfig\\\\..*"}]}	HEALTHY	1778536416683	3ef7c81c2124	1.60.4	16004900	
5bb16020-c889-4b35-b151-ac7a78bd1b32	jffe@01krcfxqjqxd9y1xv3hbse0w26	3ef7c81c2124	1778535851683	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/ui/(.*)"},{"path":"/ui"},{"path":"/"}]}	HEALTHY	1778536416683	3ef7c81c2124	1.175.3	10000003	
5fa96f7f-1316-4a30-b412-6c622648893e	jfob@01krcfxc93gbbe0f98tgff036m	3ef7c81c2124	1778535846462	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/observability/(.*)"}]}	HEALTHY	1778536416683	3ef7c81c2124	2.2.5	32a7df0e03	
8dd79f07-84cb-4f7e-84a3-967823153458	jfrt@01krcfxc93gbbe0f98tgff036m	3ef7c81c2124	1778535836467	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"/artifactory"},{"path":"/artifactory/(.*)"},{"path":"/v2/(.*)"},{"path":"/.well-known/terraform.json"},{"path":"/lifecycle/api/v2/release_bundle"},{"path":"/lifecycle/api/v2/release_bundle/(.*)"},{"path":"/lifecycle/api/v2/promotion/(.*)"},{"path":"/lifecycle/api/v2/keys/(.*)"},{"path":"/lifecycle/api/v2/audit"},{"path":"/lifecycle/api/v2/audit/(.*)"},{"path":"/lifecycle/api/v1/evidence/(.*)"}]}	HEALTHY	1778536416683	3ef7c81c2124	7.111.8	81108900	
b3fb5861-9c19-411a-8ce0-d4bd21b2d2ae	jftpl@01krcfwtqhjjbz1pf84re41xhr	3ef7c81c2124	1778535836270	0.0.0.0	8082	0	{"v":1,"paths":[{"path":"topology/.*"},{"path":"/com\\\\.jfrog\\\\.topology\\\\..*"},{"path":"access/api/v1/topology"},{"path":"/com\\\\.jfrog\\\\.access\\\\.v1\\\\.serviceregistry\\\\..*"}]}	HEALTHY	1778536416683	3ef7c81c2124	1.92.3	19203900	
\.


--
-- Data for Name: trusted_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.trusted_keys (kid, trusted_key, fingerprint, key_type, alias, issued, issued_by, expiry) FROM stdin;
\.


--
-- Data for Name: ui_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_session (session_id, creation_time, last_access_time, max_inactive_interval, principal_name) FROM stdin;
\.


--
-- Data for Name: ui_session_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_session_attributes (session_id, attribute_name, attribute_bytes) FROM stdin;
\.


--
-- Data for Name: ui_session_v2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_session_v2 (primary_id, session_id, creation_time, last_access_time, max_inactive_interval, expiry_time, principal_name) FROM stdin;
\.


--
-- Data for Name: ui_session_v2_attributes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_session_v2_attributes (session_primary_id, attribute_name, attribute_bytes) FROM stdin;
\.


--
-- Data for Name: unique_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unique_ids (index_type, current_id) FROM stdin;
general	2000
\.


--
-- Data for Name: version_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version_history (id, version, config_version_id, backward_compatible, active, created) FROM stdin;
\.


--
-- Data for Name: watches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watches (watch_id, node_id, username, since) FROM stdin;
\.


--
-- Name: config_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_history_id_seq', 1, false);


--
-- Name: node_events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.node_events_event_id_seq', 4, true);


--
-- Name: nodes_cleaned_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nodes_cleaned_id_seq', 1, false);


--
-- Name: quartz_task_history_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quartz_task_history_run_id_seq', 1, false);


--
-- Name: retention_run_summary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retention_run_summary_id_seq', 1, false);


--
-- Name: storage_events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storage_events_event_id_seq', 1, false);


--
-- Name: tasks_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_task_id_seq', 1, false);


--
-- Name: version_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.version_history_id_seq', 1, false);


--
-- Name: access_platform_config access_config_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_platform_config
    ADD CONSTRAINT access_config_key_pk PRIMARY KEY (config_key);


--
-- Name: access_configs access_configs_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_configs
    ADD CONSTRAINT access_configs_pk PRIMARY KEY (config_name);


--
-- Name: access_db_check access_db_check_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_db_check
    ADD CONSTRAINT access_db_check_pk PRIMARY KEY (username);


--
-- Name: access_distributed_lock access_distributed_lock_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_distributed_lock
    ADD CONSTRAINT access_distributed_lock_key_pk PRIMARY KEY (lock_name);


--
-- Name: access_emails_log access_emails_log_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_emails_log
    ADD CONSTRAINT access_emails_log_pk PRIMARY KEY (email, last_sent);


--
-- Name: access_environments access_environments_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_environments
    ADD CONSTRAINT access_environments_pk PRIMARY KEY (id);


--
-- Name: access_federation_log access_fed_log_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_federation_log
    ADD CONSTRAINT access_fed_log_pk PRIMARY KEY (log_id);


--
-- Name: access_federation_servers access_fed_ser_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_federation_servers
    ADD CONSTRAINT access_fed_ser_pk PRIMARY KEY (server_name);


--
-- Name: access_groups_custom_data access_groups_data_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_groups_custom_data
    ADD CONSTRAINT access_groups_data_pk PRIMARY KEY (group_id, prop_key);


--
-- Name: access_groups access_groups_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_groups
    ADD CONSTRAINT access_groups_pk PRIMARY KEY (group_id);


--
-- Name: access_master_key_status access_kid_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_master_key_status
    ADD CONSTRAINT access_kid_pk PRIMARY KEY (kid);


--
-- Name: access_master_key_status access_master_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_master_key_status
    ADD CONSTRAINT access_master_key UNIQUE (is_unique_key);


--
-- Name: access_nodes access_nodes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_nodes
    ADD CONSTRAINT access_nodes_pk PRIMARY KEY (node_id, service_id);


--
-- Name: access_permission_action access_perm_action_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permission_action
    ADD CONSTRAINT access_perm_action_pk PRIMARY KEY (action_id);


--
-- Name: access_permissions_custom_data access_perm_data_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_custom_data
    ADD CONSTRAINT access_perm_data_pk PRIMARY KEY (perm_id);


--
-- Name: access_permission_names_mapper access_permission_names_mapper_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permission_names_mapper
    ADD CONSTRAINT access_permission_names_mapper_pk PRIMARY KEY (name_identifier_v1);


--
-- Name: access_permissions_actions_v2 access_permissions_actions_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_actions_v2
    ADD CONSTRAINT access_permissions_actions_pk PRIMARY KEY (action_id);


--
-- Name: access_permissions access_permissions_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions
    ADD CONSTRAINT access_permissions_pk PRIMARY KEY (perm_id);


--
-- Name: access_permissions_targets_v2 access_permissions_targets_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_targets_v2
    ADD CONSTRAINT access_permissions_targets_pk PRIMARY KEY (target_id);


--
-- Name: access_permissions_v2 access_permissions_v2_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_v2
    ADD CONSTRAINT access_permissions_v2_pk PRIMARY KEY (perm_id);


--
-- Name: access_permissions_v2_ref access_permissions_v2_ref_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_v2_ref
    ADD CONSTRAINT access_permissions_v2_ref_pk PRIMARY KEY (v1_id);


--
-- Name: access_project_groups access_project_groups_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_groups
    ADD CONSTRAINT access_project_groups_pk PRIMARY KEY (project_id, group_id, role_id);


--
-- Name: access_project_resource_environments access_project_resource_env_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resource_environments
    ADD CONSTRAINT access_project_resource_env_pk PRIMARY KEY (resource_id, environment_id);


--
-- Name: access_project_resources access_project_resources_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resources
    ADD CONSTRAINT access_project_resources_pk PRIMARY KEY (id);


--
-- Name: access_project_resources access_project_resources_unq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resources
    ADD CONSTRAINT access_project_resources_unq UNIQUE (name, type);


--
-- Name: access_roles access_project_roles_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_roles
    ADD CONSTRAINT access_project_roles_pk PRIMARY KEY (id);


--
-- Name: access_project_shared_resources access_project_shared_resources_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_shared_resources
    ADD CONSTRAINT access_project_shared_resources_pk PRIMARY KEY (resource_id, project_id);


--
-- Name: access_project_users access_project_users_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_users
    ADD CONSTRAINT access_project_users_pk PRIMARY KEY (project_id, user_id, role_id);


--
-- Name: access_projects access_projects_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_projects
    ADD CONSTRAINT access_projects_pk PRIMARY KEY (id);


--
-- Name: access_role_environment_actions access_role_environment_actions_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_role_environment_actions
    ADD CONSTRAINT access_role_environment_actions_pk PRIMARY KEY (role_id, environment_id);


--
-- Name: access_schema_version access_schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_schema_version
    ADD CONSTRAINT access_schema_version_pk PRIMARY KEY (installed_rank);


--
-- Name: access_servers access_servers_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_servers
    ADD CONSTRAINT access_servers_pk PRIMARY KEY (server_id);


--
-- Name: access_tasks access_tasks_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_tasks
    ADD CONSTRAINT access_tasks_pk PRIMARY KEY (task_name, task_instance);


--
-- Name: access_tokens access_tokens_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_tokens
    ADD CONSTRAINT access_tokens_pk PRIMARY KEY (token_id);


--
-- Name: access_topology access_topology_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_topology
    ADD CONSTRAINT access_topology_pk PRIMARY KEY (endpoint_id);


--
-- Name: access_unique_ids access_unique_ids_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_unique_ids
    ADD CONSTRAINT access_unique_ids_pk PRIMARY KEY (index_type);


--
-- Name: access_users_custom_data access_users_data_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users_custom_data
    ADD CONSTRAINT access_users_data_pk PRIMARY KEY (user_id, prop_key);


--
-- Name: access_users_groups access_users_groups_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users_groups
    ADD CONSTRAINT access_users_groups_pk PRIMARY KEY (user_id, group_id);


--
-- Name: access_users access_users_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users
    ADD CONSTRAINT access_users_pk PRIMARY KEY (user_id);


--
-- Name: archive_names archive_names_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archive_names
    ADD CONSTRAINT archive_names_pk PRIMARY KEY (name_id);


--
-- Name: archive_paths archive_paths_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.archive_paths
    ADD CONSTRAINT archive_paths_pk PRIMARY KEY (path_id);


--
-- Name: artifactory_servers artifactory_servers_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifactory_servers
    ADD CONSTRAINT artifactory_servers_pk PRIMARY KEY (server_id);


--
-- Name: binaries binaries_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binaries
    ADD CONSTRAINT binaries_pk PRIMARY KEY (sha1);


--
-- Name: binaries_tasks binaries_tasks_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binaries_tasks
    ADD CONSTRAINT binaries_tasks_pk PRIMARY KEY (id);


--
-- Name: binary_blobs binary_blobs_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.binary_blobs
    ADD CONSTRAINT binary_blobs_pk PRIMARY KEY (sha1);


--
-- Name: build_artifacts build_artifacts_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_artifacts
    ADD CONSTRAINT build_artifacts_pk PRIMARY KEY (artifact_id);


--
-- Name: build_dependencies build_dependencies_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_dependencies
    ADD CONSTRAINT build_dependencies_pk PRIMARY KEY (dependency_id);


--
-- Name: build_modules build_modules_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_modules
    ADD CONSTRAINT build_modules_pk PRIMARY KEY (module_id);


--
-- Name: build_promotions build_promotions_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_promotions
    ADD CONSTRAINT build_promotions_pk PRIMARY KEY (build_id, created);


--
-- Name: build_props build_props_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_props
    ADD CONSTRAINT build_props_pk PRIMARY KEY (prop_id);


--
-- Name: build_release_bundles build_rb_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_release_bundles
    ADD CONSTRAINT build_rb_pk PRIMARY KEY (build_rb_id);


--
-- Name: builds builds_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.builds
    ADD CONSTRAINT builds_pk PRIMARY KEY (build_id);


--
-- Name: bundle_blobs bundle_blobs_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bundle_blobs
    ADD CONSTRAINT bundle_blobs_pk PRIMARY KEY (id);


--
-- Name: bundle_files bundle_node_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bundle_files
    ADD CONSTRAINT bundle_node_pk PRIMARY KEY (id);


--
-- Name: artifact_bundles bundle_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.artifact_bundles
    ADD CONSTRAINT bundle_pk PRIMARY KEY (id);


--
-- Name: cleanup_run_summary cleanup_run_summary_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cleanup_run_summary
    ADD CONSTRAINT cleanup_run_summary_pk PRIMARY KEY (policy_key, policy_run_id);


--
-- Name: config_history config_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_history
    ADD CONSTRAINT config_history_pk PRIMARY KEY (id);


--
-- Name: config_schema_version config_schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_schema_version
    ADD CONSTRAINT config_schema_version_pk PRIMARY KEY (installed_rank);


--
-- Name: configs configs_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configs
    ADD CONSTRAINT configs_pk PRIMARY KEY (config_name);


--
-- Name: db_properties db_properties_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.db_properties
    ADD CONSTRAINT db_properties_pk PRIMARY KEY (installation_date);


--
-- Name: file_list_tasks file_list_tasks_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_list_tasks
    ADD CONSTRAINT file_list_tasks_pk PRIMARY KEY (repo);


--
-- Name: heavy_query_cache hqc_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.heavy_query_cache
    ADD CONSTRAINT hqc_pk PRIMARY KEY (id);


--
-- Name: migration_status identifier_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_status
    ADD CONSTRAINT identifier_pk PRIMARY KEY (identifier);


--
-- Name: indexed_archives_entries indexed_archives_entries_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives_entries
    ADD CONSTRAINT indexed_archives_entries_pk PRIMARY KEY (indexed_archives_id, entry_path_id, entry_name_id);


--
-- Name: indexed_archives indexed_archives_id_uq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives
    ADD CONSTRAINT indexed_archives_id_uq UNIQUE (indexed_archives_id);


--
-- Name: indexed_archives indexed_archives_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives
    ADD CONSTRAINT indexed_archives_pk PRIMARY KEY (archive_sha1);


--
-- Name: jfconfig_platform_config jfconfig_config_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jfconfig_platform_config
    ADD CONSTRAINT jfconfig_config_key_pk PRIMARY KEY (config_key);


--
-- Name: jobs jobs_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pk PRIMARY KEY (job_id);


--
-- Name: master_key_status kid_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_key_status
    ADD CONSTRAINT kid_pk PRIMARY KEY (kid);


--
-- Name: distributed_locks locks_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.distributed_locks
    ADD CONSTRAINT locks_pk PRIMARY KEY (category, lock_key);


--
-- Name: md_configs md_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_configs
    ADD CONSTRAINT md_configs_pkey PRIMARY KEY (id);


--
-- Name: md_contributors md_contributors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_contributors
    ADD CONSTRAINT md_contributors_pkey PRIMARY KEY (id);


--
-- Name: md_database_migrations md_database_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_database_migrations
    ADD CONSTRAINT md_database_migrations_pkey PRIMARY KEY (id);


--
-- Name: md_fil_qualifiers md_fil_qualifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_fil_qualifiers
    ADD CONSTRAINT md_fil_qualifiers_pkey PRIMARY KEY (id);


--
-- Name: md_fil_targets md_fil_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_fil_targets
    ADD CONSTRAINT md_fil_targets_pkey PRIMARY KEY (id);


--
-- Name: md_files md_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_files
    ADD CONSTRAINT md_files_pkey PRIMARY KEY (id);


--
-- Name: md_files_versions md_files_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_files_versions
    ADD CONSTRAINT md_files_versions_pkey PRIMARY KEY (id);


--
-- Name: md_licenses md_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_licenses
    ADD CONSTRAINT md_licenses_pkey PRIMARY KEY (id);


--
-- Name: md_lock md_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_lock
    ADD CONSTRAINT md_lock_pkey PRIMARY KEY (lock_name);


--
-- Name: md_packages md_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_packages
    ADD CONSTRAINT md_packages_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_descriptions md_pkg_descriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_descriptions
    ADD CONSTRAINT md_pkg_descriptions_pkey PRIMARY KEY (package_id);


--
-- Name: md_pkg_info_sources md_pkg_info_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_info_sources
    ADD CONSTRAINT md_pkg_info_sources_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_licenses md_pkg_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_licenses
    ADD CONSTRAINT md_pkg_licenses_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_op_risk md_pkg_op_risk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_op_risk
    ADD CONSTRAINT md_pkg_op_risk_pkey PRIMARY KEY (package_id);


--
-- Name: md_pkg_qualifiers md_pkg_qualifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_qualifiers
    ADD CONSTRAINT md_pkg_qualifiers_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_stats md_pkg_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_stats
    ADD CONSTRAINT md_pkg_stats_pkey PRIMARY KEY (package_id);


--
-- Name: md_pkg_tags md_pkg_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_tags
    ADD CONSTRAINT md_pkg_tags_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_user_properties md_pkg_user_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_user_properties
    ADD CONSTRAINT md_pkg_user_properties_pkey PRIMARY KEY (id);


--
-- Name: md_pkg_vulns_sum md_pkg_vulns_sum_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_vulns_sum
    ADD CONSTRAINT md_pkg_vulns_sum_pkey PRIMARY KEY (package_id);


--
-- Name: md_repos md_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_repos
    ADD CONSTRAINT md_repos_pkey PRIMARY KEY (id);


--
-- Name: md_servers md_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_servers
    ADD CONSTRAINT md_servers_pkey PRIMARY KEY (id);


--
-- Name: md_sources md_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_sources
    ADD CONSTRAINT md_sources_pkey PRIMARY KEY (id);


--
-- Name: md_task_batches md_task_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_task_batches
    ADD CONSTRAINT md_task_batches_pkey PRIMARY KEY (task_key, batch_start_key);


--
-- Name: md_tasks md_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_tasks
    ADD CONSTRAINT md_tasks_pkey PRIMARY KEY (task_key);


--
-- Name: md_temp_prerelease_groups md_temp_prerelease_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_temp_prerelease_groups
    ADD CONSTRAINT md_temp_prerelease_groups_pkey PRIMARY KEY (id);


--
-- Name: md_ver_contributors md_ver_contributors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_contributors
    ADD CONSTRAINT md_ver_contributors_pkey PRIMARY KEY (id);


--
-- Name: md_ver_licenses md_ver_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_licenses
    ADD CONSTRAINT md_ver_licenses_pkey PRIMARY KEY (id);


--
-- Name: md_ver_op_risk md_ver_op_risk_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_op_risk
    ADD CONSTRAINT md_ver_op_risk_pkey PRIMARY KEY (version_id);


--
-- Name: md_ver_qualifiers md_ver_qualifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_qualifiers
    ADD CONSTRAINT md_ver_qualifiers_pkey PRIMARY KEY (id);


--
-- Name: md_ver_repos md_ver_repos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_repos
    ADD CONSTRAINT md_ver_repos_pkey PRIMARY KEY (id);


--
-- Name: md_ver_stats md_ver_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_stats
    ADD CONSTRAINT md_ver_stats_pkey PRIMARY KEY (version_id);


--
-- Name: md_ver_tags md_ver_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_tags
    ADD CONSTRAINT md_ver_tags_pkey PRIMARY KEY (id);


--
-- Name: md_ver_user_properties md_ver_user_properties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_user_properties
    ADD CONSTRAINT md_ver_user_properties_pkey PRIMARY KEY (id);


--
-- Name: md_ver_vulns_sum md_ver_vulns_sum_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_vulns_sum
    ADD CONSTRAINT md_ver_vulns_sum_pkey PRIMARY KEY (version_id);


--
-- Name: md_version_repo_stats md_version_repo_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_version_repo_stats
    ADD CONSTRAINT md_version_repo_stats_pkey PRIMARY KEY (repo_id, version_id);


--
-- Name: md_versions md_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_versions
    ADD CONSTRAINT md_versions_pkey PRIMARY KEY (id);


--
-- Name: mirrors_metadata mirrors_remote_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mirrors_metadata
    ADD CONSTRAINT mirrors_remote_pk PRIMARY KEY (metadata_type, member_url);


--
-- Name: module_props module_props_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_props
    ADD CONSTRAINT module_props_pk PRIMARY KEY (prop_id);


--
-- Name: node_events_errors node_events_errors_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_errors
    ADD CONSTRAINT node_events_errors_pk PRIMARY KEY (error_id);


--
-- Name: node_events node_events_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events
    ADD CONSTRAINT node_events_pk PRIMARY KEY (event_id);


--
-- Name: node_events_tmp_p0_5 node_events_tmp_partition_0_5_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_tmp_p0_5
    ADD CONSTRAINT node_events_tmp_partition_0_5_pk PRIMARY KEY (tmp_event_id);


--
-- Name: node_events_tmp_p12_17 node_events_tmp_partition_12_17_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_tmp_p12_17
    ADD CONSTRAINT node_events_tmp_partition_12_17_pk PRIMARY KEY (tmp_event_id);


--
-- Name: node_events_tmp_p18_23 node_events_tmp_partition_18_23_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_tmp_p18_23
    ADD CONSTRAINT node_events_tmp_partition_18_23_pk PRIMARY KEY (tmp_event_id);


--
-- Name: node_events_tmp_p6_11 node_events_tmp_partition_6_11_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_tmp_p6_11
    ADD CONSTRAINT node_events_tmp_partition_6_11_pk PRIMARY KEY (tmp_event_id);


--
-- Name: node_meta_infos node_meta_infos_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_meta_infos
    ADD CONSTRAINT node_meta_infos_pk PRIMARY KEY (node_id);


--
-- Name: node_props node_props_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_props
    ADD CONSTRAINT node_props_pk PRIMARY KEY (prop_id);


--
-- Name: nodes_cleaned nodes_cleaned_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes_cleaned
    ADD CONSTRAINT nodes_cleaned_pk PRIMARY KEY (id);


--
-- Name: nodes nodes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_pk PRIMARY KEY (node_id);


--
-- Name: node_event_cursor operator_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_event_cursor
    ADD CONSTRAINT operator_id_pk PRIMARY KEY (operator_id);


--
-- Name: policy policy_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policy
    ADD CONSTRAINT policy_pk PRIMARY KEY (policy_key);


--
-- Name: node_event_priorities priority_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_event_priorities
    ADD CONSTRAINT priority_id_pk PRIMARY KEY (priority_id);


--
-- Name: quartz_task_history quartz_task_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quartz_task_history
    ADD CONSTRAINT quartz_task_history_pk PRIMARY KEY (run_id);


--
-- Name: repository_config repo_key_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository_config
    ADD CONSTRAINT repo_key_pk PRIMARY KEY (repository_key);


--
-- Name: retention_run_summary retention_run_summary_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retention_run_summary
    ADD CONSTRAINT retention_run_summary_pk PRIMARY KEY (id);


--
-- Name: schema_change_log schema_change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_change_log
    ADD CONSTRAINT schema_change_log_pkey PRIMARY KEY (version);


--
-- Name: stats stats_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_pk PRIMARY KEY (node_id);


--
-- Name: stats_remote stats_remote_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats_remote
    ADD CONSTRAINT stats_remote_pk PRIMARY KEY (node_id, origin);


--
-- Name: storage_events storage_events_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_events
    ADD CONSTRAINT storage_events_pk PRIMARY KEY (event_id);


--
-- Name: storage_multipart_uploads storage_multipart_uploads_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_multipart_uploads
    ADD CONSTRAINT storage_multipart_uploads_pk PRIMARY KEY (upload_id);


--
-- Name: tasks tasks_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pk PRIMARY KEY (task_id);


--
-- Name: tpl_configuration tpl_configuration_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tpl_configuration
    ADD CONSTRAINT tpl_configuration_pk PRIMARY KEY (property_key);


--
-- Name: tpl_schema_version tpl_schema_version_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tpl_schema_version
    ADD CONSTRAINT tpl_schema_version_pk PRIMARY KEY (installed_rank);


--
-- Name: tpl_topology tpl_topology_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tpl_topology
    ADD CONSTRAINT tpl_topology_pk PRIMARY KEY (id);


--
-- Name: trusted_keys trusted_keys_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.trusted_keys
    ADD CONSTRAINT trusted_keys_pk PRIMARY KEY (kid);


--
-- Name: ui_session_attributes ui_session_attributes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session_attributes
    ADD CONSTRAINT ui_session_attributes_pk PRIMARY KEY (session_id, attribute_name);


--
-- Name: ui_session ui_session_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session
    ADD CONSTRAINT ui_session_pk PRIMARY KEY (session_id);


--
-- Name: ui_session_v2_attributes ui_session_v2_attributes_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session_v2_attributes
    ADD CONSTRAINT ui_session_v2_attributes_pk PRIMARY KEY (session_primary_id, attribute_name);


--
-- Name: ui_session_v2 ui_session_v2_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session_v2
    ADD CONSTRAINT ui_session_v2_pk PRIMARY KEY (primary_id);


--
-- Name: unique_ids unique_ids_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unique_ids
    ADD CONSTRAINT unique_ids_pk PRIMARY KEY (index_type);


--
-- Name: master_key_status unique_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_key_status
    ADD CONSTRAINT unique_key UNIQUE (is_unique_key);


--
-- Name: version_history version_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_history
    ADD CONSTRAINT version_history_pk PRIMARY KEY (id);


--
-- Name: watches watches_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_pk PRIMARY KEY (watch_id);


--
-- Name: access_emails_log_last_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_emails_log_last_sent ON public.access_emails_log USING btree (last_sent);


--
-- Name: access_environments_key_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_environments_key_unique_idx ON public.access_environments USING btree (environment_key);


--
-- Name: access_environments_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_environments_unique_idx ON public.access_environments USING btree (name, project_id);


--
-- Name: access_fed_log_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_fed_log_created_idx ON public.access_federation_log USING btree (created);


--
-- Name: access_group_lower_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_group_lower_name_idx ON public.access_groups USING btree (lowercase_name);


--
-- Name: access_groups_data_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_groups_data_key_idx ON public.access_groups_custom_data USING btree (prop_key);


--
-- Name: access_groups_data_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_groups_data_value_idx ON public.access_groups_custom_data USING btree (prop_value);


--
-- Name: access_groups_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_groups_name_idx ON public.access_groups USING btree (group_name);


--
-- Name: access_perm_act_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_act_group_id_idx ON public.access_permission_action USING btree (group_id);


--
-- Name: access_perm_act_group_rsc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_act_group_rsc_idx ON public.access_permissions_actions_v2 USING btree (group_id, resource_type);


--
-- Name: access_perm_act_permid_rsc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_act_permid_rsc_idx ON public.access_permissions_actions_v2 USING btree (perm_id, resource_type);


--
-- Name: access_perm_act_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_act_user_id_idx ON public.access_permission_action USING btree (user_id);


--
-- Name: access_perm_act_user_rsc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_act_user_rsc_idx ON public.access_permissions_actions_v2 USING btree (user_id, resource_type);


--
-- Name: access_perm_action_perm_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_action_perm_id_idx ON public.access_permission_action USING btree (perm_id);


--
-- Name: access_perm_disp_name_constr; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_perm_disp_name_constr ON public.access_permissions USING btree (display_name, resource_type);


--
-- Name: access_perm_lower_display_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_lower_display_idx ON public.access_permissions USING btree (lower_display_name);


--
-- Name: access_perm_lwr_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_lwr_name_idx ON public.access_permissions_v2 USING btree (lower_name);


--
-- Name: access_perm_map_nmv2_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_perm_map_nmv2_type_idx ON public.access_permission_names_mapper USING btree (name_v2, resource_type_v2);


--
-- Name: access_perm_name_unq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_perm_name_unq_idx ON public.access_permissions_v2 USING btree (name);


--
-- Name: access_perm_perm_id_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_perm_perm_id_unique_idx ON public.access_permissions USING btree (perm_name);


--
-- Name: access_perm_trg_composite_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_perm_trg_composite_idx ON public.access_permissions_targets_v2 USING btree (perm_id, resource_type, target_name);


--
-- Name: access_perm_trg_rsc_antptn_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_trg_rsc_antptn_idx ON public.access_permissions_targets_v2 USING btree (resource_type, is_target_ant_pattern);


--
-- Name: access_perm_trg_trgnme_rsc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_perm_trg_trgnme_rsc_idx ON public.access_permissions_targets_v2 USING btree (target_name, resource_type);


--
-- Name: access_permissions_v2_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_permissions_v2_name ON public.access_permissions_v2_ref USING btree (v2_name);


--
-- Name: access_project_groups_grp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_project_groups_grp_idx ON public.access_project_groups USING btree (group_id);


--
-- Name: access_project_name_project_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_project_name_project_idx ON public.access_roles USING btree (name, project_id);


--
-- Name: access_project_resources_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_project_resources_type_idx ON public.access_project_resources USING btree (type, project_id);


--
-- Name: access_projects_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_projects_name_idx ON public.access_projects USING btree (name);


--
-- Name: access_projects_project_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_projects_project_key_idx ON public.access_projects USING btree (project_key);


--
-- Name: access_schema_version_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_schema_version_s_idx ON public.access_schema_version USING btree (success);


--
-- Name: access_servers_name_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_servers_name_unique_idx ON public.access_servers USING btree (server_name);


--
-- Name: access_tasks_exec_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tasks_exec_time_idx ON public.access_tasks USING btree (execution_time);


--
-- Name: access_tasks_heartbeat_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tasks_heartbeat_idx ON public.access_tasks USING btree (last_heartbeat);


--
-- Name: access_tasks_priority_exec_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tasks_priority_exec_time_idx ON public.access_tasks USING btree (priority DESC, execution_time);


--
-- Name: access_tokens_hashed_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tokens_hashed_ref_idx ON public.access_tokens USING btree (hashed_reference);


--
-- Name: access_tokens_project_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tokens_project_key_idx ON public.access_tokens USING btree (project_key);


--
-- Name: access_tokens_rfrsh_tkn_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tokens_rfrsh_tkn_idx ON public.access_tokens USING btree (refresh_token);


--
-- Name: access_tplgy_router_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_tplgy_router_id_idx ON public.access_topology USING btree (router_id);


--
-- Name: access_username_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_username_type_idx ON public.access_tokens USING btree (username, token_type);


--
-- Name: access_users_data_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_users_data_key_idx ON public.access_users_custom_data USING btree (prop_key);


--
-- Name: access_users_data_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX access_users_data_value_idx ON public.access_users_custom_data USING btree (prop_value);


--
-- Name: access_users_username_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_users_username_idx ON public.access_users USING btree (username);


--
-- Name: access_users_username_varchar_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX access_users_username_varchar_idx ON public.access_users USING btree (username varchar_pattern_ops);


--
-- Name: archive_names_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX archive_names_name_idx ON public.archive_names USING btree (entry_name);


--
-- Name: archive_paths_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX archive_paths_path_idx ON public.archive_paths USING btree (entry_path);


--
-- Name: binaries_md5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX binaries_md5_idx ON public.binaries USING btree (md5);


--
-- Name: binaries_sha256_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_sha256_idx ON public.binaries USING btree (sha256);


--
-- Name: binaries_tasks_count_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_tasks_count_idx ON public.binaries_tasks USING btree (count);


--
-- Name: binaries_tasks_repo_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_tasks_repo_key_idx ON public.binaries_tasks USING btree (local_repo_key);


--
-- Name: binaries_tasks_server_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_tasks_server_id_idx ON public.binaries_tasks USING btree (server_id);


--
-- Name: binaries_tasks_start_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_tasks_start_time_idx ON public.binaries_tasks USING btree (start_time);


--
-- Name: binaries_tasks_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX binaries_tasks_time_idx ON public.binaries_tasks USING btree ("time");


--
-- Name: build_artifacts_md5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_artifacts_md5_idx ON public.build_artifacts USING btree (md5);


--
-- Name: build_artifacts_module_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_artifacts_module_id_idx ON public.build_artifacts USING btree (module_id);


--
-- Name: build_artifacts_sha1_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_artifacts_sha1_idx ON public.build_artifacts USING btree (sha1);


--
-- Name: build_dependencies_md5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_dependencies_md5_idx ON public.build_dependencies USING btree (md5);


--
-- Name: build_dependencies_module_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_dependencies_module_idx ON public.build_dependencies USING btree (module_id);


--
-- Name: build_dependencies_sha1_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_dependencies_sha1_idx ON public.build_dependencies USING btree (sha1);


--
-- Name: build_modules_build_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_modules_build_id_idx ON public.build_modules USING btree (build_id);


--
-- Name: build_promotions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_promotions_status_idx ON public.build_promotions USING btree (status);


--
-- Name: build_props_build_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_props_build_id_idx ON public.build_props USING btree (build_id);


--
-- Name: build_props_prop_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_props_prop_key_idx ON public.build_props USING btree (prop_key);


--
-- Name: build_props_prop_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_props_prop_value_idx ON public.build_props USING btree (prop_value);


--
-- Name: build_rb_build_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_rb_build_id_idx ON public.build_release_bundles USING btree (build_id);


--
-- Name: build_rb_bundle_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_rb_bundle_name_idx ON public.build_release_bundles USING btree (bundle_name);


--
-- Name: build_rb_bundle_repository_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_rb_bundle_repository_idx ON public.build_release_bundles USING btree (bundle_repository);


--
-- Name: build_rb_bundle_version_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX build_rb_bundle_version_idx ON public.build_release_bundles USING btree (bundle_version);


--
-- Name: builds_name_num_date_repo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX builds_name_num_date_repo_idx ON public.builds USING btree (build_name, build_number, build_date, repo);


--
-- Name: bundle_files_node_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bundle_files_node_id_idx ON public.bundle_files USING btree (node_id);


--
-- Name: bundle_id_bundle_files_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bundle_id_bundle_files_idx ON public.bundle_files USING btree (bundle_id);


--
-- Name: bundle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bundle_id_idx ON public.bundle_blobs USING btree (bundle_id);


--
-- Name: cache_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cache_time_idx ON public.mirrors_metadata USING btree (cache_time);


--
-- Name: cleanup_run_summary_estimated_deleted_binary_size_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cleanup_run_summary_estimated_deleted_binary_size_idx ON public.cleanup_run_summary USING btree (estimated_deleted_binary_size);


--
-- Name: cleanup_run_summary_prun_policy_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cleanup_run_summary_prun_policy_run_id_idx ON public.cleanup_run_summary USING btree (policy_run_id);


--
-- Name: cleanup_run_summary_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cleanup_run_summary_status_idx ON public.cleanup_run_summary USING btree (status);


--
-- Name: cleanup_run_summary_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cleanup_run_summary_type_idx ON public.cleanup_run_summary USING btree (type);


--
-- Name: config_schema_version_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX config_schema_version_s_idx ON public.config_schema_version USING btree (success);


--
-- Name: distributed_locks_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distributed_locks_owner ON public.distributed_locks USING btree (owner);


--
-- Name: distributed_locks_owner_thread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX distributed_locks_owner_thread ON public.distributed_locks USING btree (owner_thread);


--
-- Name: external_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX external_id_idx ON public.quartz_task_history USING btree (external_id);


--
-- Name: hqc_expiry_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hqc_expiry_time_idx ON public.heavy_query_cache USING btree (expiry_time);


--
-- Name: hqc_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX hqc_key_idx ON public.heavy_query_cache USING btree (cache_key);


--
-- Name: indexed_entries_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX indexed_entries_name_idx ON public.indexed_archives_entries USING btree (entry_name_id);


--
-- Name: indexed_entries_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX indexed_entries_path_idx ON public.indexed_archives_entries USING btree (entry_path_id);


--
-- Name: jobs_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jobs_index ON public.jobs USING btree (started, finished, job_status, job_type);


--
-- Name: lock_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lock_key_idx ON public.distributed_locks USING btree (lock_key varchar_pattern_ops);


--
-- Name: md_cnt_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_cnt_name_idx ON public.md_contributors USING btree (name);


--
-- Name: md_configs_config_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_configs_config_name_idx ON public.md_configs USING btree (config_name);


--
-- Name: md_fil_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_fil_unique_idx ON public.md_fil_qualifiers USING btree (file_id, name);


--
-- Name: md_file_target_unique_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_file_target_unique_idx ON public.md_fil_targets USING btree (arch, dist, compiler, compiler_version);


--
-- Name: md_files_md5_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_files_md5_idx ON public.md_files USING btree (md5);


--
-- Name: md_files_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_files_name_idx ON public.md_files USING btree (name);


--
-- Name: md_files_sha1_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_files_sha1_idx ON public.md_files USING btree (sha1);


--
-- Name: md_files_sha256_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_files_sha256_idx ON public.md_files USING btree (sha256);


--
-- Name: md_files_sha256_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_files_sha256_name_idx ON public.md_files USING btree (name, sha256);


--
-- Name: md_flv_file_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_flv_file_id_idx ON public.md_files_versions USING btree (file_id);


--
-- Name: md_flv_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_flv_version_id_idx ON public.md_files_versions USING btree (version_id);


--
-- Name: md_licenses_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_licenses_name_idx ON public.md_licenses USING btree (name);


--
-- Name: md_packages_lowercase_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_packages_lowercase_name_idx ON public.md_packages USING btree (lowercase_name);


--
-- Name: md_packages_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_packages_name_idx ON public.md_packages USING btree (name);


--
-- Name: md_packages_pkgid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_packages_pkgid_idx ON public.md_packages USING btree (pkgid);


--
-- Name: md_packages_repo_package_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_packages_repo_package_type_idx ON public.md_packages USING btree (repo_package_type);


--
-- Name: md_packages_stored_package_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_packages_stored_package_type_idx ON public.md_packages USING btree (stored_package_type);


--
-- Name: md_pkg_ins_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_ins_package_id_idx ON public.md_pkg_info_sources USING btree (package_id);


--
-- Name: md_pkg_ins_source_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_ins_source_id_idx ON public.md_pkg_info_sources USING btree (source_id);


--
-- Name: md_pkg_licenses_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_licenses_name_idx ON public.md_pkg_licenses USING btree (name);


--
-- Name: md_pkg_licenses_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_licenses_package_id_idx ON public.md_pkg_licenses USING btree (package_id);


--
-- Name: md_pkg_qlf_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_qlf_package_id_idx ON public.md_pkg_qualifiers USING btree (package_id);


--
-- Name: md_pkg_tags_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_tags_package_id_idx ON public.md_pkg_tags USING btree (package_id);


--
-- Name: md_pkg_usp_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_usp_name_idx ON public.md_pkg_user_properties USING btree (name);


--
-- Name: md_pkg_usp_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_pkg_usp_package_id_idx ON public.md_pkg_user_properties USING btree (package_id);


--
-- Name: md_repos_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_repos_name_idx ON public.md_repos USING btree (name);


--
-- Name: md_servers_node_unique_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_servers_node_unique_id_idx ON public.md_servers USING btree (node_unique_id);


--
-- Name: md_sources_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_sources_name_idx ON public.md_sources USING btree (name);


--
-- Name: md_task_batches_progress_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_task_batches_progress_idx ON public.md_task_batches USING btree (task_key, progress, modified);


--
-- Name: md_ver_cnt_contributor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_cnt_contributor_id_idx ON public.md_ver_contributors USING btree (contributor_id);


--
-- Name: md_ver_cnt_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_cnt_version_id_idx ON public.md_ver_contributors USING btree (version_id);


--
-- Name: md_ver_licenses_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_licenses_name_idx ON public.md_ver_licenses USING btree (name);


--
-- Name: md_ver_licenses_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_licenses_version_id_idx ON public.md_ver_licenses USING btree (version_id);


--
-- Name: md_ver_qlf_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_qlf_name_idx ON public.md_ver_qualifiers USING btree (name);


--
-- Name: md_ver_qlf_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_qlf_version_id_idx ON public.md_ver_qualifiers USING btree (version_id);


--
-- Name: md_ver_repos_lead_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_repos_lead_hash_idx ON public.md_ver_repos USING btree (lead_hash);


--
-- Name: md_ver_repos_repo_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_repos_repo_id_idx ON public.md_ver_repos USING btree (repo_id);


--
-- Name: md_ver_repos_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_repos_version_id_idx ON public.md_ver_repos USING btree (version_id);


--
-- Name: md_ver_tags_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_tags_value_idx ON public.md_ver_tags USING btree (value);


--
-- Name: md_ver_tags_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_tags_version_id_idx ON public.md_ver_tags USING btree (version_id);


--
-- Name: md_ver_usp_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_usp_name_idx ON public.md_ver_user_properties USING btree (name);


--
-- Name: md_ver_usp_version_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_ver_usp_version_id_idx ON public.md_ver_user_properties USING btree (version_id);


--
-- Name: md_versions_id_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_id_created_idx ON public.md_versions USING btree (id, created);


--
-- Name: md_versions_id_deletion_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_id_deletion_idx ON public.md_versions USING btree (marked_for_deletion, id, last_edited);


--
-- Name: md_versions_lowercase_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_lowercase_name_idx ON public.md_versions USING btree (lowercase_name);


--
-- Name: md_versions_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_name_idx ON public.md_versions USING btree (name);


--
-- Name: md_versions_ordinal_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_ordinal_idx ON public.md_versions USING btree (ordinal);


--
-- Name: md_versions_package_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX md_versions_package_id_idx ON public.md_versions USING btree (package_id);


--
-- Name: md_versions_pkg_id_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX md_versions_pkg_id_name_idx ON public.md_versions USING btree (package_id, name);


--
-- Name: member_url_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_url_idx ON public.mirrors_metadata USING btree (member_url);


--
-- Name: module_props_module_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX module_props_module_id_idx ON public.module_props USING btree (module_id);


--
-- Name: module_props_prop_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX module_props_prop_key_idx ON public.module_props USING btree (prop_key);


--
-- Name: module_props_prop_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX module_props_prop_value_idx ON public.module_props USING btree (prop_value);


--
-- Name: name_ver_sta_date_typ_repo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX name_ver_sta_date_typ_repo_idx ON public.artifact_bundles USING btree (name, version, status, date_created, type, storing_repo);


--
-- Name: name_version_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX name_version_idx ON public.artifact_bundles USING btree (name, version, type);


--
-- Name: node_events_errors_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_events_errors_idx ON public.node_events_errors USING btree (operation_key, event_category, event_id, event_time);


--
-- Name: node_events_full_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_events_full_idx ON public.node_events USING btree ("timestamp", event_id, event_type, path varchar_pattern_ops);


--
-- Name: node_events_repo_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_events_repo_event_id ON public.node_events USING btree (repo, event_id);


--
-- Name: node_events_tmp_p0_5_idx_time_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX node_events_tmp_p0_5_idx_time_id ON public.node_events_tmp_p0_5 USING btree ("timestamp", tmp_event_id);


--
-- Name: node_events_tmp_p12_17_idx_time_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX node_events_tmp_p12_17_idx_time_id ON public.node_events_tmp_p12_17 USING btree ("timestamp", tmp_event_id);


--
-- Name: node_events_tmp_p18_23_idx_time_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX node_events_tmp_p18_23_idx_time_id ON public.node_events_tmp_p18_23 USING btree ("timestamp", tmp_event_id);


--
-- Name: node_events_tmp_p6_11_idx_time_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX node_events_tmp_p6_11_idx_time_id ON public.node_events_tmp_p6_11 USING btree ("timestamp", tmp_event_id);


--
-- Name: node_prop_nuget_partial_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_prop_nuget_partial_idx ON public.node_props USING btree (lower((prop_value)::text)) WHERE (lower((prop_key)::text) = 'nuget.id'::text);


--
-- Name: node_props_node_prop_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_props_node_prop_value_idx ON public.node_props USING btree (node_id, prop_key varchar_pattern_ops, prop_value varchar_pattern_ops);


--
-- Name: node_props_prop_key_value_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_props_prop_key_value_idx ON public.node_props USING btree (prop_key varchar_pattern_ops, prop_value varchar_pattern_ops);


--
-- Name: node_props_prop_value_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX node_props_prop_value_key_idx ON public.node_props USING btree (prop_value varchar_pattern_ops, prop_key varchar_pattern_ops);


--
-- Name: nodes_cleaned_pkey_prun_status_sha1_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_cleaned_pkey_prun_status_sha1_idx ON public.nodes_cleaned USING btree (policy_key, policy_run_id, status, sha1);


--
-- Name: nodes_cleaned_policy_key_policy_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_cleaned_policy_key_policy_run_id_idx ON public.nodes_cleaned USING btree (policy_key, policy_run_id);


--
-- Name: nodes_lower_node_name_gin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_lower_node_name_gin_idx ON public.nodes USING gin (lower((node_name)::text) public.gin_trgm_ops) WHERE (node_type = 1);


--
-- Name: nodes_md5_actual_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_md5_actual_idx ON public.nodes USING btree (md5_actual);


--
-- Name: nodes_name_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_name_path_idx ON public.nodes USING btree (node_name varchar_pattern_ops, node_path varchar_pattern_ops);


--
-- Name: nodes_node_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_node_path_idx ON public.nodes USING btree (node_path varchar_pattern_ops);


--
-- Name: nodes_repo_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_repo_created_idx ON public.nodes USING btree (repo, created);


--
-- Name: nodes_repo_path_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nodes_repo_path_name_idx ON public.nodes USING btree (repo varchar_pattern_ops, node_path varchar_pattern_ops, node_name varchar_pattern_ops);


--
-- Name: nodes_sha1_actual_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_sha1_actual_idx ON public.nodes USING btree (sha1_actual);


--
-- Name: nodes_sha256_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodes_sha256_idx ON public.nodes USING btree (sha256);


--
-- Name: pattern_bundle_files_repo_path_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pattern_bundle_files_repo_path_idx ON public.bundle_files USING btree (repo_path varchar_pattern_ops);


--
-- Name: retention_run_summary_processed_virtual_binary_size_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retention_run_summary_processed_virtual_binary_size_idx ON public.retention_run_summary USING btree (processed_virtual_binary_size);


--
-- Name: retention_run_summary_retention_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retention_run_summary_retention_type_idx ON public.retention_run_summary USING btree (retention_type);


--
-- Name: retention_run_summary_rkey_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retention_run_summary_rkey_run_id_idx ON public.retention_run_summary USING btree (policy_key, run_id);


--
-- Name: retention_run_summary_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX retention_run_summary_status_idx ON public.retention_run_summary USING btree (status);


--
-- Name: storage_events_bin_size_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_events_bin_size_idx ON public.storage_events USING btree (bin_length);


--
-- Name: storage_events_sha1_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_events_sha1_type_idx ON public.storage_events USING btree (sha1, event_type);


--
-- Name: storage_mpu_created_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_mpu_created_date_idx ON public.storage_multipart_uploads USING btree (created_date);


--
-- Name: storage_mpu_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX storage_mpu_status_idx ON public.storage_multipart_uploads USING btree (status);


--
-- Name: tasks_type_context_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_type_context_idx ON public.tasks USING btree (task_type, task_context);


--
-- Name: tpl_schema_version_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tpl_schema_version_s_idx ON public.tpl_schema_version USING btree (success);


--
-- Name: tpl_topology_router_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tpl_topology_router_id_idx ON public.tpl_topology USING btree (router_id);


--
-- Name: trusted_keys_alias; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX trusted_keys_alias ON public.trusted_keys USING btree (alias);


--
-- Name: ui_session_attributes_ix1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ui_session_attributes_ix1 ON public.ui_session_attributes USING btree (session_id);


--
-- Name: ui_session_ix1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ui_session_ix1 ON public.ui_session USING btree (last_access_time);


--
-- Name: ui_session_v2_ix1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ui_session_v2_ix1 ON public.ui_session_v2 USING btree (last_access_time);


--
-- Name: uui_session_v2_attributes_ix1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX uui_session_v2_attributes_ix1 ON public.ui_session_v2_attributes USING btree (session_primary_id);


--
-- Name: watches_node_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watches_node_id_idx ON public.watches USING btree (node_id);


--
-- Name: access_permission_action access_trg_perm_actions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER access_trg_perm_actions BEFORE INSERT OR UPDATE ON public.access_permission_action FOR EACH STATEMENT EXECUTE FUNCTION public.access_fnc_allow_read_only();


--
-- Name: access_permissions access_trg_perm_table; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER access_trg_perm_table BEFORE INSERT OR DELETE OR UPDATE ON public.access_permissions FOR EACH STATEMENT EXECUTE FUNCTION public.access_fnc_allow_read_only();


--
-- Name: access_permissions_v2_ref access_trg_perm_v2_ref; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER access_trg_perm_v2_ref BEFORE INSERT OR DELETE OR UPDATE ON public.access_permissions_v2_ref FOR EACH STATEMENT EXECUTE FUNCTION public.access_fnc_allow_read_only();


--
-- Name: access_permissions_custom_data access_trg_perms_custom_data; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER access_trg_perms_custom_data BEFORE INSERT OR DELETE OR UPDATE ON public.access_permissions_custom_data FOR EACH STATEMENT EXECUTE FUNCTION public.access_fnc_allow_read_only();


--
-- Name: access_groups_custom_data access_groups_data_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_groups_custom_data
    ADD CONSTRAINT access_groups_data_users_fk FOREIGN KEY (group_id) REFERENCES public.access_groups(group_id);


--
-- Name: access_permissions_actions_v2 access_perm_act_v2_groups_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_actions_v2
    ADD CONSTRAINT access_perm_act_v2_groups_fk FOREIGN KEY (group_id) REFERENCES public.access_groups(group_id);


--
-- Name: access_permission_action access_perm_action_groups_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permission_action
    ADD CONSTRAINT access_perm_action_groups_fk FOREIGN KEY (group_id) REFERENCES public.access_groups(group_id) ON DELETE CASCADE;


--
-- Name: access_permission_action access_perm_action_perms_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permission_action
    ADD CONSTRAINT access_perm_action_perms_fk FOREIGN KEY (perm_id) REFERENCES public.access_permissions(perm_id);


--
-- Name: access_permission_action access_perm_action_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permission_action
    ADD CONSTRAINT access_perm_action_users_fk FOREIGN KEY (user_id) REFERENCES public.access_users(user_id) ON DELETE CASCADE;


--
-- Name: access_permissions_actions_v2 access_perm_action_v2_perms_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_actions_v2
    ADD CONSTRAINT access_perm_action_v2_perms_fk FOREIGN KEY (perm_id) REFERENCES public.access_permissions_v2(perm_id);


--
-- Name: access_permissions_actions_v2 access_perm_action_v2_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_actions_v2
    ADD CONSTRAINT access_perm_action_v2_users_fk FOREIGN KEY (user_id) REFERENCES public.access_users(user_id);


--
-- Name: access_permissions_custom_data access_perm_data_perms_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_custom_data
    ADD CONSTRAINT access_perm_data_perms_fk FOREIGN KEY (perm_id) REFERENCES public.access_permissions(perm_id);


--
-- Name: access_permissions_targets_v2 access_permissions_trg_prms_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_targets_v2
    ADD CONSTRAINT access_permissions_trg_prms_fk FOREIGN KEY (perm_id) REFERENCES public.access_permissions_v2(perm_id);


--
-- Name: access_permissions_v2_ref access_permissions_v2_ref_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_permissions_v2_ref
    ADD CONSTRAINT access_permissions_v2_ref_fk FOREIGN KEY (v1_id) REFERENCES public.access_permissions(perm_id);


--
-- Name: access_environments access_project_environments_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_environments
    ADD CONSTRAINT access_project_environments_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id);


--
-- Name: access_project_groups access_project_groups_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_groups
    ADD CONSTRAINT access_project_groups_group_fk FOREIGN KEY (group_id) REFERENCES public.access_groups(group_id);


--
-- Name: access_project_groups access_project_groups_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_groups
    ADD CONSTRAINT access_project_groups_project_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id);


--
-- Name: access_project_groups access_project_groups_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_groups
    ADD CONSTRAINT access_project_groups_role_fk FOREIGN KEY (role_id) REFERENCES public.access_roles(id);


--
-- Name: access_project_resource_environments access_project_resource_env_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resource_environments
    ADD CONSTRAINT access_project_resource_env_fk FOREIGN KEY (environment_id) REFERENCES public.access_environments(id) ON DELETE CASCADE;


--
-- Name: access_project_resource_environments access_project_resource_env_rsc_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resource_environments
    ADD CONSTRAINT access_project_resource_env_rsc_fk FOREIGN KEY (resource_id) REFERENCES public.access_project_resources(id);


--
-- Name: access_project_resources access_project_resources_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_resources
    ADD CONSTRAINT access_project_resources_project_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id) ON DELETE CASCADE;


--
-- Name: access_roles access_project_roles_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_roles
    ADD CONSTRAINT access_project_roles_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id);


--
-- Name: access_project_shared_resources access_project_shared_resources_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_shared_resources
    ADD CONSTRAINT access_project_shared_resources_project_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id);


--
-- Name: access_project_shared_resources access_project_shared_resources_rsc_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_shared_resources
    ADD CONSTRAINT access_project_shared_resources_rsc_fk FOREIGN KEY (resource_id) REFERENCES public.access_project_resources(id);


--
-- Name: access_project_users access_project_users_project_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_users
    ADD CONSTRAINT access_project_users_project_fk FOREIGN KEY (project_id) REFERENCES public.access_projects(id);


--
-- Name: access_project_users access_project_users_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_users
    ADD CONSTRAINT access_project_users_role_fk FOREIGN KEY (role_id) REFERENCES public.access_roles(id);


--
-- Name: access_project_users access_project_users_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_project_users
    ADD CONSTRAINT access_project_users_user_fk FOREIGN KEY (user_id) REFERENCES public.access_users(user_id);


--
-- Name: access_role_environment_actions access_role_environment_actions_env_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_role_environment_actions
    ADD CONSTRAINT access_role_environment_actions_env_fk FOREIGN KEY (environment_id) REFERENCES public.access_environments(id);


--
-- Name: access_role_environment_actions access_role_environment_actions_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_role_environment_actions
    ADD CONSTRAINT access_role_environment_actions_role_fk FOREIGN KEY (role_id) REFERENCES public.access_roles(id);


--
-- Name: access_users_custom_data access_users_data_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users_custom_data
    ADD CONSTRAINT access_users_data_users_fk FOREIGN KEY (user_id) REFERENCES public.access_users(user_id);


--
-- Name: access_users_groups access_users_groups_groups_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users_groups
    ADD CONSTRAINT access_users_groups_groups_fk FOREIGN KEY (group_id) REFERENCES public.access_groups(group_id);


--
-- Name: access_users_groups access_users_groups_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_users_groups
    ADD CONSTRAINT access_users_groups_users_fk FOREIGN KEY (user_id) REFERENCES public.access_users(user_id);


--
-- Name: build_artifacts build_artifacts_modules_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_artifacts
    ADD CONSTRAINT build_artifacts_modules_fk FOREIGN KEY (module_id) REFERENCES public.build_modules(module_id);


--
-- Name: build_dependencies build_dependencies_modules_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_dependencies
    ADD CONSTRAINT build_dependencies_modules_fk FOREIGN KEY (module_id) REFERENCES public.build_modules(module_id);


--
-- Name: build_modules build_modules_builds_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_modules
    ADD CONSTRAINT build_modules_builds_fk FOREIGN KEY (build_id) REFERENCES public.builds(build_id);


--
-- Name: build_promotions build_promotions_builds_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_promotions
    ADD CONSTRAINT build_promotions_builds_fk FOREIGN KEY (build_id) REFERENCES public.builds(build_id);


--
-- Name: build_props build_props_builds_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_props
    ADD CONSTRAINT build_props_builds_fk FOREIGN KEY (build_id) REFERENCES public.builds(build_id);


--
-- Name: build_release_bundles build_rb_build_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.build_release_bundles
    ADD CONSTRAINT build_rb_build_id_fk FOREIGN KEY (build_id) REFERENCES public.builds(build_id) ON DELETE CASCADE;


--
-- Name: bundle_blobs bundle_id_bundle_blobs_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bundle_blobs
    ADD CONSTRAINT bundle_id_bundle_blobs_fk FOREIGN KEY (bundle_id) REFERENCES public.artifact_bundles(id);


--
-- Name: bundle_files bundle_id_bundle_files_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bundle_files
    ADD CONSTRAINT bundle_id_bundle_files_fk FOREIGN KEY (bundle_id) REFERENCES public.artifact_bundles(id);


--
-- Name: indexed_archives_entries entry_name_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives_entries
    ADD CONSTRAINT entry_name_id_fk FOREIGN KEY (entry_name_id) REFERENCES public.archive_names(name_id);


--
-- Name: indexed_archives_entries entry_path_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives_entries
    ADD CONSTRAINT entry_path_id_fk FOREIGN KEY (entry_path_id) REFERENCES public.archive_paths(path_id);


--
-- Name: md_files fk_file_targets; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_files
    ADD CONSTRAINT fk_file_targets FOREIGN KEY (file_target_id) REFERENCES public.md_fil_targets(id);


--
-- Name: indexed_archives indexed_archives_binaries_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives
    ADD CONSTRAINT indexed_archives_binaries_fk FOREIGN KEY (archive_sha1) REFERENCES public.binaries(sha1);


--
-- Name: indexed_archives_entries indexed_archives_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indexed_archives_entries
    ADD CONSTRAINT indexed_archives_id_fk FOREIGN KEY (indexed_archives_id) REFERENCES public.indexed_archives(indexed_archives_id);


--
-- Name: md_pkg_descriptions md_descriptions_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_descriptions
    ADD CONSTRAINT md_descriptions_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_fil_qualifiers md_fil_qlf_files_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_fil_qualifiers
    ADD CONSTRAINT md_fil_qlf_files_fk FOREIGN KEY (file_id) REFERENCES public.md_files(id) ON DELETE CASCADE NOT VALID;


--
-- Name: md_files_versions md_flv_files_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_files_versions
    ADD CONSTRAINT md_flv_files_fk FOREIGN KEY (file_id) REFERENCES public.md_files(id);


--
-- Name: md_files_versions md_flv_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_files_versions
    ADD CONSTRAINT md_flv_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_pkg_info_sources md_ins_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_info_sources
    ADD CONSTRAINT md_ins_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_info_sources md_ins_sources_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_info_sources
    ADD CONSTRAINT md_ins_sources_fk FOREIGN KEY (source_id) REFERENCES public.md_sources(id);


--
-- Name: md_pkg_licenses md_licenses_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_licenses
    ADD CONSTRAINT md_licenses_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_op_risk md_pgk_op_risk_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_op_risk
    ADD CONSTRAINT md_pgk_op_risk_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_qualifiers md_qlf_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_qualifiers
    ADD CONSTRAINT md_qlf_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_stats md_stats_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_stats
    ADD CONSTRAINT md_stats_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_tags md_tags_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_tags
    ADD CONSTRAINT md_tags_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_user_properties md_usp_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_user_properties
    ADD CONSTRAINT md_usp_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_ver_contributors md_ver_cnt_cnt_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_contributors
    ADD CONSTRAINT md_ver_cnt_cnt_fk FOREIGN KEY (contributor_id) REFERENCES public.md_contributors(id);


--
-- Name: md_ver_contributors md_ver_cnt_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_contributors
    ADD CONSTRAINT md_ver_cnt_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_licenses md_ver_licenses_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_licenses
    ADD CONSTRAINT md_ver_licenses_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_op_risk md_ver_op_risk_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_op_risk
    ADD CONSTRAINT md_ver_op_risk_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_qualifiers md_ver_qlf_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_qualifiers
    ADD CONSTRAINT md_ver_qlf_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_repos md_ver_repos_repos_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_repos
    ADD CONSTRAINT md_ver_repos_repos_fk FOREIGN KEY (repo_id) REFERENCES public.md_repos(id);


--
-- Name: md_ver_repos md_ver_repos_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_repos
    ADD CONSTRAINT md_ver_repos_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_stats md_ver_stats_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_stats
    ADD CONSTRAINT md_ver_stats_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_tags md_ver_tags_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_tags
    ADD CONSTRAINT md_ver_tags_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_user_properties md_ver_usp_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_user_properties
    ADD CONSTRAINT md_ver_usp_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_ver_vulns_sum md_ver_vulns_sum_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_ver_vulns_sum
    ADD CONSTRAINT md_ver_vulns_sum_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_version_repo_stats md_version_repo_stats_repos_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_version_repo_stats
    ADD CONSTRAINT md_version_repo_stats_repos_fk FOREIGN KEY (repo_id) REFERENCES public.md_repos(id);


--
-- Name: md_version_repo_stats md_version_repo_stats_versions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_version_repo_stats
    ADD CONSTRAINT md_version_repo_stats_versions_fk FOREIGN KEY (version_id) REFERENCES public.md_versions(id);


--
-- Name: md_versions md_versions_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_versions
    ADD CONSTRAINT md_versions_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: md_pkg_vulns_sum md_vulns_sum_packages_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.md_pkg_vulns_sum
    ADD CONSTRAINT md_vulns_sum_packages_fk FOREIGN KEY (package_id) REFERENCES public.md_packages(id);


--
-- Name: module_props module_props_modules_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.module_props
    ADD CONSTRAINT module_props_modules_fk FOREIGN KEY (module_id) REFERENCES public.build_modules(module_id);


--
-- Name: node_events_errors node_events_errors_event_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_events_errors
    ADD CONSTRAINT node_events_errors_event_id_fk FOREIGN KEY (event_id) REFERENCES public.node_events(event_id);


--
-- Name: bundle_files node_id_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bundle_files
    ADD CONSTRAINT node_id_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- Name: node_meta_infos node_meta_infos_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_meta_infos
    ADD CONSTRAINT node_meta_infos_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- Name: node_props node_props_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.node_props
    ADD CONSTRAINT node_props_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- Name: nodes nodes_binaries_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodes
    ADD CONSTRAINT nodes_binaries_fk FOREIGN KEY (sha1_actual) REFERENCES public.binaries(sha1);


--
-- Name: stats stats_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- Name: stats_remote stats_remote_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stats_remote
    ADD CONSTRAINT stats_remote_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- Name: ui_session_attributes ui_session_attributes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session_attributes
    ADD CONSTRAINT ui_session_attributes_fk FOREIGN KEY (session_id) REFERENCES public.ui_session(session_id) ON DELETE CASCADE;


--
-- Name: ui_session_v2_attributes ui_session_v2_attributes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ui_session_v2_attributes
    ADD CONSTRAINT ui_session_v2_attributes_fk FOREIGN KEY (session_primary_id) REFERENCES public.ui_session_v2(primary_id) ON DELETE CASCADE;


--
-- Name: version_history version_history_config_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_history
    ADD CONSTRAINT version_history_config_fk FOREIGN KEY (config_version_id) REFERENCES public.config_history(id);


--
-- Name: watches watches_nodes_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watches
    ADD CONSTRAINT watches_nodes_fk FOREIGN KEY (node_id) REFERENCES public.nodes(node_id);


--
-- PostgreSQL database dump complete
--

\unrestrict Xs70qUqBIjTqQA0MuV17khofhAFea3OApykDlTJ4Ykm3OBSrmNrYZZwg8xl6JoA

